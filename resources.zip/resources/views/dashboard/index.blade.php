@extends('layouts.app')

@section('title', 'Gestor de Proyectos & Kanban - ' . ($activeProject ? $activeProject->name : 'Inicio'))

@section('content')
@php
    $todayBolivia = \Carbon\Carbon::today('America/La_Paz')->toDateString();
    $todayTasks = $todayTasks ?? collect();
    $overdueTasks = $overdueTasks ?? ($tasks ? $tasks->filter(fn($t) => $t->isOverdue()) : collect());
    $overdueCount = $overdueCount ?? $overdueTasks->count();
    $estadoColores = $estadoColores ?? [
        'no_iniciado' => '#64748b',
        'en_proceso'  => '#3b82f6',
        'en_revision' => '#f59e0b',
        'rechazado'   => '#ef4444',
        'finalizado'  => '#10b981',
    ];
    $estadoIconos = $estadoIconos ?? [];
    if (isset($estadosConfig) && $estadosConfig->count() > 0) {
        $quickStatusList = $estadosConfig->map(function($item) {
            $key = $item->clave ?: \Illuminate\Support\Str::slug($item->nombre, '_');
            return [
                'id' => $key,
                'title' => $item->nombre,
                'ruta_icono' => $item->ruta_icono,
                'color' => $item->color,
            ];
        })->toArray();
    } else {
        $quickStatusList = [
            ['id' => 'no_iniciado', 'title' => 'No Iniciado', 'ruta_icono' => $estadoIconos['no_iniciado'] ?? null, 'color' => $estadoColores['no_iniciado'] ?? '#64748b'],
            ['id' => 'en_proceso',  'title' => 'En Proceso',  'ruta_icono' => $estadoIconos['en_proceso'] ?? null,  'color' => $estadoColores['en_proceso'] ?? '#3b82f6'],
            ['id' => 'en_revision', 'title' => 'En Revisión', 'ruta_icono' => $estadoIconos['en_revision'] ?? null, 'color' => $estadoColores['en_revision'] ?? '#f59e0b'],
            ['id' => 'rechazado',   'title' => 'Rechazado',   'ruta_icono' => $estadoIconos['rechazado'] ?? null,   'color' => $estadoColores['rechazado'] ?? '#ef4444'],
            ['id' => 'finalizado',  'title' => 'Finalizado',  'ruta_icono' => $estadoIconos['finalizado'] ?? null,  'color' => $estadoColores['finalizado'] ?? '#10b981'],
        ];
    }

    $prioridadColores = $prioridadColores ?? [
        'baja'  => '#64748b',
        'media' => '#f59e0b',
        'alta'  => '#ef4444',
    ];
    $prioridadNombres = $prioridadNombres ?? [
        'baja'  => 'Baja',
        'media' => 'Media',
        'alta'  => 'Alta',
    ];

    if (isset($prioridadesConfig) && $prioridadesConfig->count() > 0) {
        $prioridadesList = $prioridadesConfig->map(function($item) {
            $key = $item->clave ?: \Illuminate\Support\Str::slug($item->nombre, '_');
            return [
                'id' => $key,
                'title' => $item->nombre,
                'color' => $item->color,
            ];
        })->toArray();
    } else {
        $prioridadesList = [
            ['id' => 'baja',  'title' => $prioridadNombres['baja'] ?? 'Baja',  'color' => $prioridadColores['baja'] ?? '#64748b'],
            ['id' => 'media', 'title' => $prioridadNombres['media'] ?? 'Media', 'color' => $prioridadColores['media'] ?? '#f59e0b'],
            ['id' => 'alta',  'title' => $prioridadNombres['alta'] ?? 'Alta',  'color' => $prioridadColores['alta'] ?? '#ef4444'],
        ];
    }
    $taskFilterOption = $taskFilterOption ?? '';
    $taskSearch = $taskSearch ?? '';
    $periodicidadColores = $periodicidadColores ?? [
        'diaria'  => '#06b6d4',
        'semanal' => '#3b82f6',
        'mensual' => '#8b5cf6',
        'anual'   => '#10b981',
    ];
    $periodicidadNombres = $periodicidadNombres ?? [
        'diaria'  => 'Diaria',
        'semanal' => 'Semanal',
        'mensual' => 'Mensual',
        'anual'   => 'Anual',
    ];
@endphp

<!-- Mobile Sidebar Backdrop -->
<div id="sidebar-backdrop" onclick="toggleSidebar()" class="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-[45] hidden md:hidden transition-opacity"></div>

<!-- Sidebar Navigation -->
<aside id="sidebar" class="sidebar-collapsed fixed md:static inset-y-0 left-0 z-50 md:z-40 w-72 max-w-[85vw] bg-[#0b0f19] text-slate-300 border-r border-slate-800/80 flex flex-col transition-all duration-300 transform -translate-x-full md:translate-x-0 shrink-0 h-full max-h-[100dvh] overflow-y-auto md:overflow-hidden overscroll-contain">
    <!-- Inicialización inmediata para evitar parpadeo (Flicker) -->
    <script>
        (function() {
            try {
                var saved = localStorage.getItem('sidebar_collapsed') ?? localStorage.getItem('sidebarCollapsed');
                // Estado por defecto: CERRADO (sidebar-collapsed ya está aplicado por defecto en el HTML).
                // Solo si el usuario lo abrió explícitamente y está en escritorio, removemos la clase de colapso:
                if (saved === 'false' && window.innerWidth >= 768) {
                    var sb = document.getElementById('sidebar');
                    if (sb) sb.classList.remove('sidebar-collapsed');
                }
            } catch (e) {}
        })();
    </script>
    <!-- Header App Logo -->
    <div class="p-4 sm:p-5 border-b border-slate-800/90 flex items-center justify-between">
        <div class="flex items-center space-x-3">
            <img src="{{ asset('icons/iconoround.png') }}" alt="NegocioManager" class="w-10 h-10 rounded-xl object-contain shrink-0" style="border-radius: 0.75rem; overflow: hidden;">
            <div>
                <h1 class="font-bold text-base sm:text-lg text-white tracking-tight leading-tight">NegocioManager</h1>
                <!--<span class="text-[10px] font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">Panel Central</span> -->
            </div>
        </div>
        <button onclick="toggleSidebar()" class="md:hidden text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition" aria-label="Cerrar menú">
            <i data-lucide="x" class="w-5 h-5"></i>
        </button>
    </div>

    <!-- Quick Theme Toggle in Sidebar (Moved below NegocioManager / Panel Central) -->
    <div class="px-3 sm:px-4 py-2.5 border-b border-slate-800/80">
        <button type="button" onclick="toggleTheme()" class="w-full py-2 px-3 rounded-xl bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 text-slate-400 hover:text-amber-400 transition text-xs flex items-center justify-between shadow-2xs">
            <span class="font-medium">Cambiar Tema</span>
            <div class="flex items-center">
                <span class="theme-icon-moon"><i data-lucide="moon" class="w-4 h-4 text-blue-400"></i></span>
                <span class="theme-icon-sun hidden"><i data-lucide="sun" class="w-4 h-4 text-amber-400"></i></span>
            </div>
            <!-- Texto 'Claro / Oscuro' ocultado para evitar redundancia -->
            <!-- <span class="text-[10px] font-semibold text-slate-500 dark:text-slate-400">Claro / Oscuro</span> -->
        </button>
    </div>

    <!-- New Project Button -->
    @if($user->hasFullAccess())
    <div class="p-3 sm:p-4 pb-2">
        <button onclick="openProjectModal()"
            class="w-full py-2.5 px-4 bg-[#5446FB] hover:bg-[#4335e6] text-white font-medium rounded-xl flex items-center justify-center space-x-2 transition-all shadow-md shadow-indigo-900/20 active:scale-95 text-xs sm:text-sm">
            <i data-lucide="plus-circle" class="w-4 h-4"></i>
            <span>Nuevo Proyecto</span>
        </button>
    </div>
    @endif

    <!-- Section Buttons: Proyectos / Todo (Global) -->
    <div class="px-3 sm:px-4 py-2 grid grid-cols-2 gap-2">
        <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'view' => $activeView]) }}"
            class="py-2 px-2.5 rounded-xl text-xs font-medium flex items-center justify-center space-x-1.5 transition
            {{ request()->has('project_id') ? 'bg-[#0f172a] text-white shadow-sm border border-slate-700/60' : 'bg-slate-800/70 text-slate-400 hover:text-slate-200 hover:bg-slate-700/80 border border-transparent' }}">
            <i data-lucide="folder-kanban" class="w-3.5 h-3.5"></i>
            <span>Proyectos</span>
        </a>
        <a href="{{ route('dashboard', ['view' => 'resumen']) }}"
            class="py-2 px-2.5 rounded-xl text-xs font-medium flex items-center justify-center space-x-1.5 transition
            {{ !request()->has('project_id') ? 'bg-[#0f172a] text-white shadow-sm border border-slate-700/60' : 'bg-slate-800/70 text-slate-400 hover:text-slate-200 hover:bg-slate-700/80 border border-transparent' }}">
            <i data-lucide="layers" class="w-3.5 h-3.5"></i>
            <span>General</span>
        </a>
    </div>

    <!-- Projects List -->
    <div class="flex-none md:flex-1 overflow-visible md:overflow-y-auto px-3 py-2 space-y-1.5 no-scrollbar">
        <div class="px-3 py-1 text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
            <span>{{ $user->isHelper() ? 'Proyectos Asignados' : 'Tus Proyectos' }}</span>
            <span class="px-1.5 py-0.5 rounded-full bg-slate-800 text-[10px] text-slate-400 font-semibold">{{ $visibleProjects->count() }}</span>
        </div>

        @if($visibleProjects->isEmpty())
            <div class="text-center py-8 px-4 text-slate-500 text-xs">
                {{ $user->isHelper() ? 'No tienes tareas asignadas en ningún proyecto todavía.' : 'No tienes proyectos guardados. ¡Crea uno para empezar!' }}
            </div>
        @else
            @foreach($visibleProjects as $proj)
                @php $isActive = $activeProject && $activeProject->id == $proj->id; @endphp
                <div class="rounded-xl {{ $isActive ? 'bg-slate-800/90 border border-blue-700/50 shadow-xs' : 'bg-slate-800/40 border border-slate-800/70 hover:bg-slate-800/60' }} overflow-hidden transition">
                    <div class="group flex items-center justify-between px-3 py-2.5 text-xs sm:text-sm font-medium
                        {{ $isActive ? 'text-blue-300 font-semibold border-l-4 border-blue-500 pl-2' : 'text-slate-300' }}">
                        <a href="{{ route('dashboard', ['project_id' => $proj->id, 'view' => $activeView]) }}" class="flex items-center space-x-2.5 truncate flex-1 min-w-0">
                            <i data-lucide="folder" class="w-4 h-4 shrink-0 {{ $isActive ? 'text-blue-400' : 'text-slate-400' }}"></i>
                            <span class="truncate">{{ $proj->name }}</span>
                        </a>
                        <div class="flex items-center space-x-1 shrink-0">
                            @if($user->hasFullAccess())
                                <button title="Agregar Módulo" onclick="openModuleModal({{ $proj->id }})" class="p-1 text-slate-400 hover:text-blue-300 hover:bg-slate-700 rounded-lg transition">
                                    <i data-lucide="plus-circle" class="w-3.5 h-3.5"></i>
                                </button>
                                <button title="Editar proyecto" onclick='openProjectModal(@json($proj))' class="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition">
                                    <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                </button>
                            @endif
                            <button onclick="toggleProjectAccordion({{ $proj->id }})" class="p-1 text-slate-400 hover:text-white rounded-lg transition" aria-label="Expandir módulos">
                                <i data-lucide="chevron-down" id="acc-icon-{{ $proj->id }}" class="w-4 h-4 transition-transform duration-200 {{ $isActive ? '' : '-rotate-90' }}"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Modules Accordion -->
                    <div id="acc-content-{{ $proj->id }}" class="{{ $isActive ? '' : 'hidden' }} pl-5 pr-2 py-1.5 space-y-1 bg-slate-950/40 border-t border-slate-800/70 text-xs">
                        <a href="{{ route('dashboard', ['project_id' => $proj->id, 'module_id' => 'all', 'view' => $activeView]) }}"
                            class="flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer transition
                            {{ $isActive && $activeModuleId === 'all' ? 'bg-blue-500/20 text-blue-300 font-semibold' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60' }}">
                            <div class="flex items-center space-x-2">
                                <i data-lucide="boxes" class="w-3.5 h-3.5 text-slate-400"></i>
                                <span>Todos los módulos</span>
                            </div>
                            <span class="text-[10px] bg-slate-800/80 text-slate-400 px-1.5 py-0.5 rounded-full font-medium">{{ $proj->tasks->count() }}</span>
                        </a>

                        @foreach($proj->modules as $mod)
                            <div class="group flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer transition
                                {{ $isActive && $activeModuleId == $mod->id ? 'bg-blue-500/20 text-blue-300 font-semibold' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60' }}">
                                <a href="{{ route('dashboard', ['project_id' => $proj->id, 'module_id' => $mod->id, 'view' => $activeView]) }}" class="flex items-center space-x-2 truncate flex-1">
                                    <i data-lucide="box" class="w-3.5 h-3.5 text-slate-400 shrink-0"></i>
                                    <span class="truncate">{{ $mod->name }}</span>
                                </a>
                                <div class="flex items-center space-x-1 shrink-0">
                                    <span class="text-[10px] bg-slate-800/80 text-slate-400 px-1.5 py-0.5 rounded-full font-medium">{{ $mod->tasks->count() }}</span>
                                    @if($user->hasFullAccess())
                                        <button title="Editar módulo" onclick="openModuleModal({{ $proj->id }}, {{ json_encode($mod) }})" class="p-1 opacity-0 group-hover:opacity-100 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition">
                                            <i data-lucide="pencil" class="w-3 h-3"></i>
                                        </button>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endforeach
        @endif
    </div>

    <!-- Sidebar Footer -->
    <div class="p-3.5 border-t border-slate-800/90 text-xs text-slate-400 flex flex-col items-center space-y-2 shrink-0 pb-safe pb-8 md:pb-3.5">
        <!-- PWA Install Button -->
        <!-- <button id="pwa-install-btn" onclick="triggerPWAInstall()" class="hidden text-indigo-600 dark:text-indigo-300 hover:text-indigo-800 dark:hover:text-white transition text-xs font-semibold flex items-center space-x-2 py-2 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 hover:bg-indigo-100 dark:hover:bg-indigo-900/80 border border-indigo-200 dark:border-indigo-500/40 w-full justify-center shadow-xs">
            <i data-lucide="download" class="w-4 h-4 text-indigo-500 dark:text-indigo-400"></i>
            <span>Instalar Aplicación PWA</span>
        </button> -->

        @if($user->isAdmin())
        <a href="{{ route('config.index') }}" onclick="saveSettingsReturnView()" class="w-full py-1.5 px-3 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-indigo-300 transition text-xs flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <i data-lucide="settings" class="w-4 h-4 text-slate-400"></i>
                <span>Configuración</span>
            </div>
            <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-400"></i>
        </a>

        <button onclick="openUsersListModal()" class="w-full py-1.5 px-3 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-indigo-300 transition text-xs flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <i data-lucide="users" class="w-4 h-4 text-slate-400"></i>
                <span>Gestión de Usuarios</span>
            </div>
            <span class="text-[10px] px-1.5 py-0.5 rounded-full tab-counter-badge font-bold">{{ $allUsers->count() }}</span>
        </button>
        @endif
    </div>
</aside>

<!-- Main Content Workspace -->
<main class="flex-1 flex flex-col h-full overflow-hidden bg-[#B3B3B3] dark:bg-[#0b0f19] transition-colors duration-200">

    <!-- Top Workspace Navbar (2 Rows as in modoclaro.png & modooscuro.jpeg) -->
    <header class="bg-[#0f172a] lg:bg-[#B3B3B3] lg:dark:bg-[#0b0f19] px-3 sm:px-6 flex flex-col shadow-md lg:shadow-none shrink-0 z-20 transition-colors duration-200">

        <!-- FILA 1: Proyecto + Acciones + Información del Usuario + Cerrar Sesión -->
        <div class="flex items-center justify-between py-3 lg:py-3.5 gap-2 sm:gap-4 min-w-0">
            <!-- Left: Toggle Sidebar + Nombre del proyecto y subtítulo resumen -->
            <div class="flex items-center space-x-2.5 sm:space-x-3.5 min-w-0">
                <button id="sidebar-toggle-btn" onclick="toggleSidebar()" class="text-white hover:text-slate-200 lg:text-black lg:dark:text-slate-300 lg:hover:text-black lg:dark:hover:text-white p-1.5 -ml-1 rounded-xl hover:bg-white/10 lg:hover:bg-black/10 lg:dark:hover:bg-slate-800 focus:outline-none transition shrink-0" aria-label="Alternar menú lateral" title="Alternar menú lateral">
                    <i data-lucide="menu" class="w-5 h-5 sm:w-6 sm:h-6"></i>
                </button>
                <div class="min-w-0 flex flex-col justify-center">
                    <div class="flex items-center space-x-2 flex-wrap sm:flex-nowrap gap-y-1">
                        <h2 class="text-base sm:text-xl font-extrabold text-white lg:text-black lg:dark:text-white truncate max-w-[170px] sm:max-w-xs md:max-w-md lg:max-w-lg tracking-tight">
                            {{ $activeProject ? $activeProject->name : 'Selecciona un Proyecto' }}
                        </h2>
                        @if($activeProject && $activeModuleId && $activeModuleId !== 'all')
                            @php $activeMod = $activeProject->modules->firstWhere('id', $activeModuleId); @endphp
                            @if($activeMod)
                                <span class="hidden sm:inline-flex text-[11px] bg-white/70 dark:bg-slate-800 text-black dark:text-slate-200 border border-black/15 dark:border-slate-700 font-semibold px-2.5 py-0.5 rounded-full items-center space-x-1 shrink-0">
                                    <i data-lucide="box" class="w-3 h-3 text-indigo-700 dark:text-blue-400"></i>
                                    <span class="truncate max-w-[120px]">{{ $activeMod->name }}</span>
                                </span>
                            @endif
                        @endif
                    </div>
                    {{-- Resumen de tareas (oculto temporalmente a petición del usuario)
                    @if($activeProject)
                        <p class="hidden sm:block text-[11px] text-slate-300 lg:text-slate-600 lg:dark:text-slate-400 font-medium truncate mt-0.5">
                            {{ $tasks->count() }} tareas · {{ $todayTasks->where('status', '!=', 'finalizado')->count() }} pendientes hoy · {{ $recurringTasks->count() }} periódicas
                        </p>
                    @endif
                    --}}
                </div>
            </div>

            <!-- Right: Botones de Acción + Selector de Tema + Info Usuario + Cerrar Sesión -->
            <div class="flex items-center space-x-2 sm:space-x-3 shrink-0">
                <!-- Botón de acción contextual según la vista activa -->
                @if($activeProject)
                    @if($activeView === 'resumen' || $activeView === 'kanban' || $activeView === 'calendario')
                        @if(!$user->isHelper())
                            <button onclick="openTaskModal()"
                                class="py-1.5 px-2.5 sm:py-2 sm:px-3.5 bg-[#5446FB] hover:bg-[#4335e6] text-white font-medium rounded-xl text-xs sm:text-sm flex items-center space-x-1.5 transition shadow-xs active:scale-95 border border-slate-700/80 dark:border-slate-600/80 shrink-0" title="Agregar Tarea">
                                <i data-lucide="plus-circle" class="w-4 h-4"></i>
                                <span class="hidden md:inline">Agregar Tarea</span>
                                <span class="hidden sm:inline md:hidden">Tarea</span>
                            </button>
                        @endif
                    @elseif($activeView === 'incidencias')
                        <button onclick="openIncidentModal()"
                            class="py-1.5 px-2.5 sm:py-2 sm:px-3.5 bg-[#5446FB] hover:bg-[#4335e6] text-white font-medium rounded-xl text-xs sm:text-sm flex items-center space-x-1.5 transition shadow-xs active:scale-95 border border-slate-700/80 dark:border-slate-600/80 shrink-0" title="Reportar Incidencia">
                            <i data-lucide="alert-circle" class="w-4 h-4"></i>
                            <span class="hidden md:inline">Reportar Incidencia</span>
                            <span class="hidden sm:inline md:hidden">Reportar</span>
                        </button>
                    @elseif($activeView === 'periodicas')
                        @if(!$user->isHelper())
                            <button onclick="openRecurringTaskModal()"
                                class="py-1.5 px-2.5 sm:py-2 sm:px-3.5 bg-[#5446FB] hover:bg-[#4335e6] text-white font-medium rounded-xl text-xs sm:text-sm flex items-center space-x-1.5 transition shadow-xs active:scale-95 border border-slate-700/80 dark:border-slate-600/80 shrink-0" title="Nueva Tarea Periódica">
                                <i data-lucide="plus-circle" class="w-4 h-4"></i>
                                <span class="hidden md:inline">Nueva Tarea Periódica</span>
                                <span class="hidden sm:inline md:hidden">Nueva</span>
                            </button>
                        @endif
                    @elseif($activeView === 'enlaces' && !$user->isHelper())
                        <button onclick='openProjectModal(@json($activeProject->load("links.assignedUsers")))'
                            class="py-1.5 px-2.5 sm:py-2 sm:px-3.5 bg-[#5446FB] hover:bg-[#4335e6] text-white font-medium rounded-xl text-xs sm:text-sm flex items-center space-x-1.5 transition shadow-xs active:scale-95 border border-slate-700/80 dark:border-slate-600/80 shrink-0" title="Gestionar Enlaces">
                            <i data-lucide="link" class="w-4 h-4"></i>
                            <span class="hidden md:inline">Gestionar Enlaces</span>
                            <span class="hidden sm:inline md:hidden">Enlaces</span>
                        </button>
                    @endif
                @endif

                <!-- Selector de Tema (Claro / Oscuro) -->
                <button type="button" onclick="toggleTheme()" class="p-2 rounded-xl bg-white/10 lg:bg-white/70 hover:bg-white/20 lg:hover:bg-white dark:bg-slate-800/80 dark:hover:bg-slate-700 text-white lg:text-black dark:text-amber-300 border border-white/10 lg:border-black/15 dark:border-slate-700/70 transition shrink-0" title="Cambiar modo claro / oscuro">
                    <span class="theme-icon-moon"><i data-lucide="moon" class="w-4 h-4"></i></span>
                    <span class="theme-icon-sun hidden"><i data-lucide="sun" class="w-4 h-4 text-amber-400"></i></span>
                </button>

                <!-- 1. Botón de Cerrar Sesión (A la izquierda del usuario) -->
                <form method="POST" action="{{ route('logout') }}" class="inline m-0 shrink-0">
                    @csrf
                    <button type="submit" title="Cerrar Sesión" class="flex items-center gap-1.5 p-2 sm:py-2 sm:px-2.5 rounded-xl bg-white/10 lg:bg-white/70 hover:bg-red-500/20 lg:hover:bg-red-50 dark:bg-slate-800/80 dark:hover:bg-red-950/60 text-red-300 lg:text-slate-800 lg:hover:text-red-600 dark:text-slate-300 dark:hover:text-red-300 text-xs font-bold transition border border-white/10 lg:border-black/15 dark:border-slate-700/70 hover:border-red-200 dark:hover:border-red-900/60 shrink-0">
                        <i data-lucide="log-out" class="w-4 h-4"></i>
                        <span class="hidden md:inline">Salir</span>
                    </button>
                </form>

                <!-- 2. Información del Usuario (Inmediatamente a la derecha del icono de salir) -->
                <div class="flex items-center gap-2 sm:gap-2.5 shrink-0 pl-1 sm:pl-2.5 sm:border-l sm:border-slate-700/60 lg:sm:border-black/15 lg:dark:sm:border-slate-800/80">
                    <div class="relative shrink-0">
                        <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-[#6366f1] text-white font-bold text-xs sm:text-sm flex items-center justify-center shadow-xs ring-2 ring-indigo-400/30">
                            @if(!empty($user->avatar))
                                <img src="{{ asset($user->avatar) }}" alt="{{ $user->name }}" class="w-full h-full rounded-full object-cover">
                            @elseif(!empty($user->profile_photo_url))
                                <img src="{{ $user->profile_photo_url }}" alt="{{ $user->name }}" class="w-full h-full rounded-full object-cover">
                            @else
                                {{ $user->initials }}
                            @endif
                        </div>
                        <span class="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#0f172a] lg:ring-[#B3B3B3] lg:dark:ring-[#0b0f19]" title="En línea"></span>
                    </div>
                    <div class="min-w-0 hidden sm:block text-left">
                        <p class="text-xs sm:text-sm font-bold text-white lg:text-slate-900 lg:dark:text-white truncate leading-tight">{{ $user->name }}</p>
                        <span class="text-[10px] sm:text-[11px] font-medium text-slate-300 lg:text-slate-600 lg:dark:text-slate-400 block truncate capitalize">{{ $user->role }}</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- FILA 2: Navegación de Vistas Disponibles (Debajo del Título del Proyecto) -->
        @if($activeProject)
        <div class="flex items-center justify-between -mx-3 sm:-mx-6 px-3 sm:px-6 overflow-hidden">
            <nav class="flex items-stretch overflow-x-auto no-scrollbar py-0 min-h-[46px] lg:min-h-[48px] gap-1 sm:gap-2 flex-nowrap scroll-smooth">
                <!-- 1. Tab Resumen -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'resumen']) }}"
                    class="flex items-center space-x-1.5 px-3 py-2.5 lg:py-2 text-xs sm:text-sm lg:text-[14px] font-bold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $activeView === 'resumen' 
                        ? 'border-indigo-500 text-indigo-400 lg:border-indigo-600 lg:text-indigo-900 dark:border-indigo-400 dark:text-white' 
                        : 'border-transparent text-slate-300 hover:text-white lg:text-black lg:hover:text-indigo-900 dark:text-slate-400 dark:hover:text-white' }}">
                    <span>Resumen</span>
                </a>

                <!-- 2. Tab Calendario -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'calendario']) }}"
                    class="flex items-center space-x-1.5 px-3 py-2.5 lg:py-2 text-xs sm:text-sm lg:text-[14px] font-bold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $activeView === 'calendario' 
                        ? 'border-indigo-500 text-indigo-400 lg:border-indigo-600 lg:text-indigo-900 dark:border-indigo-400 dark:text-white' 
                        : 'border-transparent text-slate-300 hover:text-white lg:text-black lg:hover:text-indigo-900 dark:text-slate-400 dark:hover:text-white' }}">
                    <span>Calendario</span>
                </a>

                <!-- 3. Tab Tablero Kanban -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'kanban']) }}"
                    class="flex items-center space-x-1.5 px-3 py-2.5 lg:py-2 text-xs sm:text-sm lg:text-[14px] font-bold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $activeView === 'kanban' 
                        ? 'border-indigo-500 text-indigo-400 lg:border-indigo-600 lg:text-indigo-900 dark:border-indigo-400 dark:text-white' 
                        : 'border-transparent text-slate-300 hover:text-white lg:text-black lg:hover:text-indigo-900 dark:text-slate-400 dark:hover:text-white' }}">
                    <span>Tablero Kanban</span>
                </a>

                <!-- 4. Tab Enlaces -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'enlaces']) }}"
                    class="flex items-center space-x-1.5 px-3 py-2.5 lg:py-2 text-xs sm:text-sm lg:text-[14px] font-bold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $activeView === 'enlaces' 
                        ? 'border-indigo-500 text-indigo-400 lg:border-indigo-600 lg:text-indigo-900 dark:border-indigo-400 dark:text-white' 
                        : 'border-transparent text-slate-300 hover:text-white lg:text-black lg:hover:text-indigo-900 dark:text-slate-400 dark:hover:text-white' }}">
                    <span>Enlaces</span>
                    @php
                        $userLinkCount = $user->isHelper()
                            ? $activeProject->links->filter(fn($l) => $l->assignedUsers->contains('id', $user->id))->count()
                            : $activeProject->links->count();
                    @endphp
                    @if($userLinkCount > 0)
                        <span class="text-[10px] tab-counter-badge px-1.5 py-0.5 rounded-full font-bold">
                            {{ $userLinkCount }}
                        </span>
                    @endif
                </a>

                <!-- 5. Tab Incidencias -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'incidencias']) }}"
                    class="flex items-center space-x-1.5 px-3 py-2.5 lg:py-2 text-xs sm:text-sm lg:text-[14px] font-bold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $activeView === 'incidencias' 
                        ? 'border-red-500 text-red-400 lg:border-red-600 lg:text-red-700 dark:border-red-400 dark:text-red-300' 
                        : 'border-transparent text-slate-300 hover:text-red-400 lg:text-black lg:hover:text-red-700 dark:text-slate-400 dark:hover:text-white' }}">
                    <span>Incidencias</span>
                    <span id="incidents-tab-badge" class="text-[10px] tab-counter-badge px-1.5 py-0.5 rounded-full font-bold {{ $incidents->count() > 0 ? '' : 'hidden' }}">
                        {{ $incidents->count() }}
                    </span>
                </a>

                <!-- 6. Tab Tareas Periódicas (Admin/Dev) -->
                @if($user->isAdmin())
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'periodicas']) }}"
                    class="flex items-center space-x-1.5 px-3 py-2.5 lg:py-2 text-xs sm:text-sm lg:text-[14px] font-bold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $activeView === 'periodicas' 
                        ? 'border-indigo-500 text-indigo-400 lg:border-indigo-600 lg:text-indigo-900 dark:border-indigo-400 dark:text-white' 
                        : 'border-transparent text-slate-300 hover:text-white lg:text-black lg:hover:text-indigo-900 dark:text-slate-400 dark:hover:text-white' }}">
                    <span>Periódicas</span>
                    @if($recurringTasks->count() > 0)
                        <span class="text-[10px] tab-counter-badge px-1.5 py-0.5 rounded-full font-bold">
                            {{ $recurringTasks->count() }}
                        </span>
                    @endif
                </a>
                @endif

                <!-- 7. Tab Checklist (Directo, sin selector «Más») -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'checklist']) }}"
                    class="flex items-center space-x-1.5 px-3 py-2.5 lg:py-2 text-xs sm:text-sm lg:text-[14px] font-bold border-b-2 whitespace-nowrap transition shrink-0
                    {{ in_array($activeView, ['checklist', 'lista_tareas']) 
                        ? 'border-indigo-500 text-indigo-400 lg:border-indigo-600 lg:text-indigo-900 dark:border-indigo-400 dark:text-white' 
                        : 'border-transparent text-slate-300 hover:text-white lg:text-black lg:hover:text-indigo-900 dark:text-slate-400 dark:hover:text-white' }}">
                    <span>Checklist</span>
                </a>

                <!-- 8. Tab Papelera -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'papelera']) }}"
                    class="flex items-center space-x-1.5 px-3 py-2.5 lg:py-2 text-xs sm:text-sm lg:text-[14px] font-bold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $activeView === 'papelera' 
                        ? 'border-red-500 text-red-400 lg:border-red-600 lg:text-red-700 dark:border-red-400 dark:text-red-300' 
                        : 'border-transparent text-slate-300 hover:text-red-400 lg:text-black lg:hover:text-red-700 dark:text-slate-400 dark:hover:text-white' }}">
                    <span>Papelera</span>
                </a>
            </nav>

            <!-- Indicador de Fecha y Filtro por Usuario en el extremo derecho (modo escritorio como en modoclaro.png & modooscuro.jpeg) -->
            <div class="hidden lg:flex flex-col items-end shrink-0 pl-4 py-1 select-none">
                <div class="flex items-center space-x-1.5 text-xs sm:text-sm font-bold text-black dark:text-slate-100">
                    <i data-lucide="calendar" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                    <span>Hoy · {{ ucfirst(\Carbon\Carbon::now()->locale('es')->isoFormat('D [de] MMMM [de] YYYY')) }}</span>
                </div>
                @if(!$user->isHelper() && $activeView === 'resumen')
                    <div class="mt-4 relative flex items-center">
                        <i data-lucide="user" class="w-4 h-4 absolute left-3 text-slate-400 pointer-events-none"></i>
                        <select id="resumen-user-filter" onchange="onResumenUserFilterChange(this.value)"
                            class="pl-9 pr-9 py-1.5 rounded-xl bg-white hover:bg-slate-50 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 text-xs sm:text-sm font-semibold appearance-none cursor-pointer outline-none focus:ring-2 focus:ring-indigo-500/20 transition min-w-[200px] max-w-[250px] truncate shadow-2xs"
                            title="Filtrar por usuario">
                            <option value="all" {{ $selectedUserId === 'all' ? 'selected' : '' }}>Todos los usuarios</option>
                            @foreach($projectUsers as $pUser)
                                <option value="{{ $pUser->id }}" {{ (string)$selectedUserId === (string)$pUser->id ? 'selected' : '' }}>
                                    {{ $pUser->name }}
                                </option>
                            @endforeach
                        </select>
                        <i data-lucide="chevron-down" class="w-4 h-4 absolute right-3 text-slate-400 pointer-events-none"></i>
                    </div>
                @endif
            </div>
        </div>

        <!-- Mobile Contextual Sub-navigation (Reemplaza accesos repetidos por subapartados de la sección activa) -->
        <nav class="lg:hidden flex items-stretch overflow-x-auto no-scrollbar -mx-3 px-3 sm:-mx-6 sm:px-6 flex-nowrap shrink-0 gap-1 sm:gap-2 py-1 bg-[#0f172a] text-slate-300">
            @if($activeView === 'resumen')
                <!-- Subnavegación Contextual: Resumen móvil -->
                <button type="button" onclick="document.getElementById('contenedor-todas-tareas')?.scrollIntoView({behavior: 'smooth'})"
                    class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 border-indigo-400 text-white whitespace-nowrap transition shrink-0">
                    <span>Todas las tareas</span>
                    <span class="text-[10px] px-1.5 py-0.2 rounded-full font-bold tab-counter-badge">{{ ($generalTasks ?? $tasks->filter(fn($t) => is_null($t->recurring_task_id)))->count() }}</span>
                </button>

                <button type="button" onclick="document.getElementById('contenedor-periodicas')?.scrollIntoView({behavior: 'smooth'})"
                    class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 border-transparent text-slate-300 hover:text-white whitespace-nowrap transition shrink-0">
                    <span>Periódicas</span>
                    <span id="subnav-periodicas-counter" class="text-[10px] px-1.5 py-0.2 rounded-full font-bold tab-counter-badge">{{ ($todayRecurringTasks ?? collect())->count() }}</span>
                </button>

                <button type="button" onclick="document.getElementById('contenedor-tareas-vencidas')?.scrollIntoView({behavior: 'smooth'})"
                    class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 border-transparent text-slate-300 hover:text-white whitespace-nowrap transition shrink-0">
                    <span>Vencidas</span>
                    <span class="text-[10px] px-1.5 py-0.2 rounded-full font-bold tab-counter-badge {{ $overdueCount > 0 ? 'bg-red-500/80 text-white' : '' }}">{{ $overdueCount }}</span>
                </button>
            @elseif($activeView === 'calendario')
                <!-- Subnavegación Contextual: Calendario -->
                <button type="button" id="subnav-cal-btn-calendar" onclick="selectMobileCalView('calendar')"
                    class="cal-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-indigo-400 text-white font-bold">
                    <span>Calendario</span>
                </button>

                <button type="button" id="subnav-cal-btn-list" onclick="selectMobileCalView('list')"
                    class="cal-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-transparent text-slate-300 hover:text-white">
                    <span>Lista de tareas del proyecto</span>
                </button>

                <a href="{{ route('dashboard', array_filter(['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'calendario', 'task_filter' => 'hoy', 'cal_subview' => 'list', 'user_id' => $selectedUserId, 'task_filter_option' => $taskFilterOption, 'task_search' => $taskSearch])) }}"
                    id="subnav-cal-btn-hoy"
                    class="cal-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-transparent text-slate-300 hover:text-white">
                    <span>Tareas de hoy</span>
                    <span class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $todayTasks->count() }}</span>
                </a>

                <a href="{{ route('dashboard', array_filter(['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'calendario', 'task_filter' => 'mes', 'cal_subview' => 'list', 'user_id' => $selectedUserId, 'task_filter_option' => $taskFilterOption, 'task_search' => $taskSearch])) }}"
                    id="subnav-cal-btn-mes"
                    class="cal-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-transparent text-slate-300 hover:text-white">
                    <span>Tareas del mes</span>
                    <span class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $monthTasks->count() }}</span>
                </a>

            @elseif($activeView === 'kanban')
                <!-- Subnavegación Contextual: Tablero Kanban (Estados reales) -->
                @php
                    $mobileKanbanCols = [
                        ['id' => 'no_iniciado', 'title' => 'No Iniciado', 'icon' => 'circle'],
                        ['id' => 'en_proceso', 'title' => 'En Proceso', 'icon' => 'clock'],
                        ['id' => 'en_revision', 'title' => 'En Revisión', 'icon' => 'search'],
                        ['id' => 'rechazado', 'title' => 'Rechazado', 'icon' => 'x-circle'],
                        ['id' => 'finalizado', 'title' => 'Finalizado', 'icon' => 'check-circle'],
                    ];
                @endphp

                <button type="button" id="subnav-kanban-btn-todos" onclick="filterMobileKanban('todos')"
                    class="kanban-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-indigo-400 text-white font-bold">
                    <span>Todos</span>
                    <span class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $filteredTasks->count() }}</span>
                </button>

                @foreach($mobileKanbanCols as $col)
                    @php $colTasksCount = $filteredTasks->where('status', $col['id'])->count(); @endphp
                    <button type="button" id="subnav-kanban-btn-{{ $col['id'] }}" onclick="filterMobileKanban('{{ $col['id'] }}')"
                        class="kanban-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-transparent text-slate-300 hover:text-white">
                        <span>{{ $col['title'] }}</span>
                        <span class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $colTasksCount }}</span>
                    </button>
                @endforeach

            @elseif($activeView === 'incidencias')
                <!-- Subnavegación Contextual: Incidencias -->
                <button type="button" id="subnav-inc-btn-todas" onclick="filterMobileIncidents('todas')"
                    class="inc-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-red-400 text-red-300 font-bold">
                    <span>Todas</span>
                    <span id="subnav-inc-count-todas" class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $incidents->count() }}</span>
                </button>
                <button type="button" id="subnav-inc-btn-abierta" onclick="filterMobileIncidents('abierta')"
                    class="inc-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-transparent text-slate-300 hover:text-white">
                    <span>Abiertas</span>
                    <span id="subnav-inc-count-abierta" class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $incidents->where('estado', 'abierta')->count() }}</span>
                </button>
                <button type="button" id="subnav-inc-btn-en_proceso" onclick="filterMobileIncidents('en_proceso')"
                    class="inc-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-transparent text-slate-300 hover:text-white">
                    <span>En Proceso</span>
                    <span id="subnav-inc-count-en_proceso" class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $incidents->where('estado', 'en_proceso')->count() }}</span>
                </button>
                <button type="button" id="subnav-inc-btn-resuelta" onclick="filterMobileIncidents('resuelta')"
                    class="inc-subnav-btn flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0 border-transparent text-slate-300 hover:text-white">
                    <span>Resueltas</span>
                    <span id="subnav-inc-count-resuelta" class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $incidents->where('estado', 'resuelta')->count() }}</span>
                </button>

            @elseif($activeView === 'enlaces')
                <!-- Subnavegación Contextual: Enlaces -->
                @php
                    $mUserLinkCount = $user->isHelper()
                        ? $activeProject->links->filter(fn($l) => $l->assignedUsers->contains('id', $user->id))->count()
                        : $activeProject->links->count();
                @endphp
                <div class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 border-indigo-400 text-white whitespace-nowrap font-bold">
                    <span>Todos los Enlaces</span>
                    <span class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $mUserLinkCount }}</span>
                </div>

            @elseif($activeView === 'periodicas')
                <!-- Subnavegación Contextual: Tareas Periódicas -->
                <div class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 border-indigo-400 text-white whitespace-nowrap font-bold">
                    <span>Todas las Reglas</span>
                    <span class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $recurringTasks->count() }}</span>
                </div>
                <div class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 border-transparent text-slate-300 whitespace-nowrap">
                    <span>Activas: {{ $recurringTasks->where('active', true)->count() }}</span>
                </div>

            @elseif($activeView === 'papelera')
                <!-- Subnavegación Contextual: Papelera -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'papelera', 'trash_filter' => 'todas']) }}"
                    class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $trashFilter === 'todas' ? 'border-red-400 text-red-300 font-bold' : 'border-transparent text-slate-300 hover:text-white' }}">
                    <span>Todas</span>
                    <span class="text-[10px] tab-counter-badge px-1.5 py-0.2 rounded-full font-bold">{{ $allTrashCount }}</span>
                </a>

                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'papelera', 'trash_filter' => 'dia']) }}"
                    class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $trashFilter === 'dia' ? 'border-red-400 text-red-300 font-bold' : 'border-transparent text-slate-300 hover:text-white' }}">
                    <span>Hoy</span>
                </a>

                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'papelera', 'trash_filter' => 'semana']) }}"
                    class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $trashFilter === 'semana' ? 'border-red-400 text-red-300 font-bold' : 'border-transparent text-slate-300 hover:text-white' }}">
                    <span>Esta Semana</span>
                </a>

                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'papelera', 'trash_filter' => 'mes']) }}"
                    class="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-semibold border-b-2 whitespace-nowrap transition shrink-0
                    {{ $trashFilter === 'mes' ? 'border-red-400 text-red-300 font-bold' : 'border-transparent text-slate-300 hover:text-white' }}">
                    <span>Este Mes</span>
                </a>
            @elseif($activeView === 'checklist' || $activeView === 'lista_tareas')
                <!-- Subnavegación Contextual: CheckList -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject->id, 'module_id' => $activeModuleId, 'view' => 'checklist']) }}"
                    class="flex items-center px-2.5 py-1.5 text-xs font-bold border-b-2 border-indigo-400 whitespace-nowrap shrink-0"
                    style="color: #FFFFFF !important; font-weight: 700 !important;">
                    <span>CheckList</span>
                </a>
            @endif
        </nav>
        @endif

    </header>

    <!-- Workspace Body Area -->
    <div class="flex-1 overflow-y-auto p-3.5 sm:p-5 md:p-6 pb-24 md:pb-8">
        @if(!$activeProject)
            <div class="h-full flex flex-col items-center justify-center text-center py-16 px-4">
                <div class="w-20 h-20 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-3xl flex items-center justify-center text-[#0f172a] dark:text-slate-200 mb-4 shadow-soft">
                    <i data-lucide="folder-open" class="w-10 h-10"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-800 dark:text-white tracking-tight">Sin Proyecto Seleccionado</h3>
                <p class="text-sm text-slate-500 dark:text-slate-400 max-w-sm mt-1.5 leading-relaxed">Selecciona un proyecto en la barra lateral para ver su tablero y tareas, o crea uno nuevo para comenzar.</p>
                @if($user->hasFullAccess())
                    <button onclick="openProjectModal()" class="mt-5 py-2.5 px-5 bg-[#5446FB] hover:bg-[#4335e6] text-white font-medium rounded-xl text-sm flex items-center space-x-2 shadow-soft transition active:scale-95">
                        <i data-lucide="plus" class="w-4 h-4"></i>
                        <span>Crear Primer Proyecto</span>
                    </button>
                @endif
            </div>
        @else

            <!-- ========================================================================= -->
            <!-- VIEW 0: RESUMEN / DASHBOARD GENERAL (NEW MODERN EXECUTIVE VIEW)           -->
            <!-- ========================================================================= -->
            @if($activeView === 'resumen')
                @php
                    $totalTasksCount = $tasks->count();
                    $completedTasksCount = $tasks->where('status', 'finalizado')->count();
                    $inProgressTasksCount = $tasks->where('status', 'en_proceso')->count();
                    $notStartedTasksCount = $tasks->where('status', 'no_iniciado')->count();
                    $inReviewTasksCount = $tasks->where('status', 'en_revision')->count();
                    $rejectedTasksCount = $tasks->where('status', 'rechazado')->count();
                    $overdueTasks = $overdueTasks ?? $tasks->filter(fn($t) => $t->isOverdue());
                    $overdueCount = $overdueCount ?? $overdueTasks->count();
                    $completionRate = $totalTasksCount > 0 ? round(($completedTasksCount / $totalTasksCount) * 100) : 0;
                    $openIncidentsCount = $incidents->where('estado', '!=', 'resuelta')->count();
                @endphp

                <div class="space-y-5 sm:space-y-6 max-w-[1600px] mx-auto">
                    <!-- Top Welcome & Status Banner -->
                    <!-- <div class="rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white p-4 sm:p-6 shadow-card relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
                       <div class="relative z-10 space-y-1">
                            <div class="flex items-center gap-2">
                                <span class="px-2.5 py-0.5 rounded-full bg-indigo-500/30 border border-indigo-400/30 text-indigo-200 text-[10px] font-bold uppercase tracking-wider">
                                    Panel Administrativo
                                </span>
                                <span class="text-xs text-indigo-200 flex items-center gap-1">
                                    <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                                    <span>Activo</span>
                                </span>
                            </div>
                            <h2 class="text-xl sm:text-2xl font-extrabold tracking-tight text-white flex items-center gap-2">
                                <span>{{ $activeProject->name }}</span>
                                @if($activeModuleId && $activeModuleId !== 'all')
                                    @php $activeModName = $activeProject->modules->firstWhere('id', $activeModuleId)?->name; @endphp
                                    @if($activeModName)
                                        <span class="text-xs font-normal text-indigo-200 bg-white/10 px-2 py-0.5 rounded-lg border border-white/10">
                                            Módulo: {{ $activeModName }}
                                        </span>
                                    @endif
                                @endif
                            </h2>
                            
                            <p class="text-xs sm:text-sm text-indigo-200/90 max-w-xl">
                             Monitoreo y administración visual en tiempo real de tareas, avances, equipo e incidencias del proyecto.
                            </p>
                            
                        </div>-->

                        <!-- Right Quick Action Shortcuts 
                        <div class="relative z-10 flex items-center gap-2 shrink-0 flex-wrap">
                            @if(!$user->isHelper())
                                <button onclick="openTaskModal()" class="py-2 px-3.5 rounded-xl bg-white text-indigo-900 hover:bg-indigo-50 font-bold text-xs flex items-center gap-1.5 shadow-sm transition active:scale-95">
                                    <i data-lucide="plus" class="w-4 h-4 text-indigo-600"></i>
                                    <span>Nueva Tarea</span>
                                </button>
                            @endif
                            <button onclick="openIncidentModal()" class="py-2 px-3 rounded-xl bg-red-500/20 hover:bg-red-500/30 border border-red-400/40 text-red-100 font-semibold text-xs flex items-center gap-1.5 transition">
                                <i data-lucide="alert-triangle" class="w-4 h-4 text-red-300"></i>
                                <span>Reportar Incidencia</span>
                            </button>
                        </div>-->

                        <!-- Subtle background visual ornament -->
                        <!-- <div class="absolute -right-8 -bottom-8 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
                        <div class="absolute right-1/3 -top-10 w-40 h-40 bg-violet-500/10 rounded-full blur-2xl pointer-events-none"></div>
                        -->
                    <!--</div>-->

                    <!-- Mobile Date & User Filter Bar (Visible only on mobile/tablet) -->
                    <div class="lg:hidden flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 mb-1">
                        <div class="flex items-center space-x-1.5 text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                            <i data-lucide="calendar" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                            <span>Hoy · {{ ucfirst(\Carbon\Carbon::now()->locale('es')->isoFormat('D [de] MMMM [de] YYYY')) }}</span>
                        </div>
                        @if(!$user->isHelper())
                            <div class="relative flex items-center w-full sm:w-auto mt-2.5 sm:mt-0">
                                <i data-lucide="user" class="w-4 h-4 absolute left-3 text-slate-400 pointer-events-none"></i>
                                <select onchange="onResumenUserFilterChange(this.value)"
                                    class="w-full sm:w-auto pl-9 pr-9 py-2 rounded-xl bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 text-xs sm:text-sm font-semibold appearance-none cursor-pointer outline-none focus:ring-2 focus:ring-indigo-500/20 shadow-2xs"
                                    title="Filtrar por usuario">
                                    <option value="all" {{ $selectedUserId === 'all' ? 'selected' : '' }}>Todos los usuarios</option>
                                    @foreach($projectUsers as $pUser)
                                        <option value="{{ $pUser->id }}" {{ (string)$selectedUserId === (string)$pUser->id ? 'selected' : '' }}>
                                            {{ $pUser->name }}
                                        </option>
                                    @endforeach
                                </select>
                                <i data-lucide="chevron-down" class="w-4 h-4 absolute right-3 text-slate-400 pointer-events-none"></i>
                            </div>
                        @endif
                    </div>

                    <!-- 5 Core Metric KPI Cards (Inspired by diseñosreferencia) -->
                    <div id="kpi-stats-grid" class="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3 sm:gap-4">
                        <!-- KPI 1: Tareas vencidas (Conserva «Ver todas» sin línea divisoria) -->
                        <div class="p-3.5 sm:p-4 lg:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-soft hover:shadow-card dark:hover:shadow-card-dark transition relative overflow-hidden flex flex-col justify-between">
                            <div class="flex items-center gap-3.5">
                                <div class="w-10 h-10 sm:w-11 sm:h-11 lg:w-12 lg:h-12 rounded-xl bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
                                    <i data-lucide="alert-triangle" class="w-5 h-5 lg:w-6 lg:h-6"></i>
                                </div>
                                <div class="min-w-0">
                                    <span class="text-2xl sm:text-3xl lg:text-[34px] font-black text-black dark:text-white leading-none block tracking-tight">{{ $overdueCount }}</span>
                                    <span class="text-xs sm:text-sm font-bold text-black dark:text-slate-300 mt-1.5 block truncate">Tareas vencidas</span>
                                </div>
                            </div>
                            <div class="mt-2.5">
                                <a href="{{ route('dashboard', array_filter(['project_id' => $activeProject?->id, 'module_id' => $activeModuleId, 'view' => 'kanban', 'user_id' => $selectedUserId])) }}" class="text-[11px] sm:text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 hover:underline transition inline-flex items-center gap-1">
                                    <span>Ver todas</span>
                                    <i data-lucide="chevron-right" class="w-3 h-3"></i>
                                </a>
                            </div>
                        </div>

                        <!-- KPI 2: En proceso -->
                        <div class="p-3.5 sm:p-4 lg:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-soft hover:shadow-card dark:hover:shadow-card-dark transition relative overflow-hidden flex flex-col justify-between">
                            <div class="flex items-center gap-3.5">
                                <div class="w-10 h-10 sm:w-11 sm:h-11 lg:w-12 lg:h-12 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                                    <i data-lucide="clock" class="w-5 h-5 lg:w-6 lg:h-6"></i>
                                </div>
                                <div class="min-w-0">
                                    <span class="text-2xl sm:text-3xl lg:text-[34px] font-black text-black dark:text-white leading-none block tracking-tight">{{ $inProgressTasksCount }}</span>
                                    <span class="text-xs sm:text-sm font-bold text-black dark:text-slate-300 mt-1.5 block truncate">En proceso</span>
                                </div>
                            </div>
                        </div>

                        <!-- KPI 3: En revisión -->
                        <div class="p-3.5 sm:p-4 lg:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-soft hover:shadow-card dark:hover:shadow-card-dark transition relative overflow-hidden flex flex-col justify-between">
                            <div class="flex items-center gap-3.5">
                                <div class="w-10 h-10 sm:w-11 sm:h-11 lg:w-12 lg:h-12 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                                    <i data-lucide="search" class="w-5 h-5 lg:w-6 lg:h-6"></i>
                                </div>
                                <div class="min-w-0">
                                    <span class="text-2xl sm:text-3xl lg:text-[34px] font-black text-black dark:text-white leading-none block tracking-tight">{{ $inReviewTasksCount }}</span>
                                    <span class="text-xs sm:text-sm font-bold text-black dark:text-slate-300 mt-1.5 block truncate">En revisión</span>
                                </div>
                            </div>
                        </div>

                        <!-- KPI 4: Incidencias -->
                        <div class="p-3.5 sm:p-4 lg:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-soft hover:shadow-card dark:hover:shadow-card-dark transition relative overflow-hidden flex flex-col justify-between">
                            <div class="flex items-center gap-3.5">
                                <div class="w-10 h-10 sm:w-11 sm:h-11 lg:w-12 lg:h-12 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                                    <i data-lucide="shield-alert" class="w-5 h-5 lg:w-6 lg:h-6"></i>
                                </div>
                                <div class="min-w-0">
                                    <span id="kpi-incidents-count" class="text-2xl sm:text-3xl lg:text-[34px] font-black text-black dark:text-white leading-none block tracking-tight">{{ $incidents->count() }}</span>
                                    <span class="text-xs sm:text-sm font-bold text-black dark:text-slate-300 mt-1.5 block truncate">Incidencias</span>
                                </div>
                            </div>
                        </div>

                        <!-- KPI 5: Tareas periódicas -->
                        <div class="p-3.5 sm:p-4 lg:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-soft hover:shadow-card dark:hover:shadow-card-dark transition relative overflow-hidden flex flex-col justify-between col-span-2 sm:col-span-2 lg:col-span-1 xl:col-span-1">
                            <div class="flex items-center gap-3.5">
                                <div class="w-10 h-10 sm:w-11 sm:h-11 lg:w-12 lg:h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                                    <i data-lucide="repeat" class="w-5 h-5 lg:w-6 lg:h-6"></i>
                                </div>
                                <div class="min-w-0">
                                    <span class="text-2xl sm:text-3xl lg:text-[34px] font-black text-black dark:text-white leading-none block tracking-tight">{{ $recurringTasks->count() }}</span>
                                    <span class="text-xs sm:text-sm font-bold text-black dark:text-slate-300 mt-1.5 block truncate">Tareas periódicas</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Distribución de las Tres Listas de Tareas (Inspirado fielmente en diseñosreferencia) -->
                    <div class="grid grid-cols-1 lg:grid-cols-3 gap-5 sm:gap-6 items-start lg:items-stretch">
                        
                        <!-- CONTENEDOR 1: Todas las tareas -->
                        <div id="contenedor-todas-tareas" class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 shadow-soft flex flex-col lg:h-[650px]">
                            @php
                                $currentResumenStatus = $resumenStatus ?? request('task_status', 'all');
                                $generalTasksList = $generalTasks ?? $tasks->filter(fn($t) => is_null($t->recurring_task_id))->values();
                                $initialFilteredTasks = $generalTasksList->filter(function($t) use ($currentResumenStatus) {
                                    if ($currentResumenStatus === 'all' || empty($currentResumenStatus)) return true;
                                    if ($currentResumenStatus === 'vencida') return $t->isOverdue();
                                    return $t->status === $currentResumenStatus;
                                });
                            @endphp

                            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3.5 gap-2 flex-wrap shrink-0">
                                <div class="flex items-center gap-2 min-w-0">
                                    <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                                        <i data-lucide="clipboard-list" class="w-4 h-4"></i>
                                    </div>
                                    <h3 class="text-sm font-bold text-slate-900 dark:text-white truncate">Todas las tareas</h3>
                                    <span id="all-tasks-count-badge" class="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 shrink-0">
                                        {{ $initialFilteredTasks->count() }}
                                    </span>
                                </div>

                                <!-- Filtro por estado en «Todas las tareas» -->
                                <div class="relative flex items-center shrink-0">
                                    <i data-lucide="filter" class="w-3.5 h-3.5 absolute left-2.5 text-slate-400 pointer-events-none"></i>
                                    <select id="resumen-all-tasks-status-filter" onchange="filterAllTasksByStatus(this.value)"
                                        class="pl-8 pr-7 py-1.5 rounded-xl bg-slate-50 hover:bg-slate-100/80 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 text-xs font-semibold appearance-none cursor-pointer outline-none focus:ring-2 focus:ring-indigo-500/20 transition shadow-2xs"
                                        title="Filtrar por estado">
                                        <option value="all" {{ $currentResumenStatus === 'all' ? 'selected' : '' }}>Todos los estados</option>
                                        <option value="vencida" {{ $currentResumenStatus === 'vencida' ? 'selected' : '' }}>Vencida</option>
                                        <option value="en_proceso" {{ $currentResumenStatus === 'en_proceso' ? 'selected' : '' }}>En proceso</option>
                                        <option value="en_revision" {{ $currentResumenStatus === 'en_revision' ? 'selected' : '' }}>En revisión</option>
                                        <option value="no_iniciado" {{ $currentResumenStatus === 'no_iniciado' ? 'selected' : '' }}>No iniciada</option>
                                        <option value="finalizado" {{ $currentResumenStatus === 'finalizado' ? 'selected' : '' }}>Finalizada</option>
                                        <option value="rechazado" {{ $currentResumenStatus === 'rechazado' ? 'selected' : '' }}>Rechazada</option>
                                    </select>
                                    <i data-lucide="chevron-down" class="w-3.5 h-3.5 absolute right-2 text-slate-400 pointer-events-none"></i>
                                </div>
                            </div>

                            <div class="space-y-2.5 max-h-[580px] lg:max-h-none overflow-y-auto pr-1 pb-1 flex-1 min-h-0">
                                <!-- Mensaje cuando el filtro de estado no arroja resultados -->
                                <div id="all-tasks-empty-filter-msg" class="{{ ($generalTasksList->isNotEmpty() && $initialFilteredTasks->isEmpty()) ? '' : 'hidden' }} text-center py-12 text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
                                    <i data-lucide="filter-x" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                    <span>No hay tareas con el estado seleccionado.</span>
                                </div>

                                @forelse($generalTasksList as $t)
                                    @php
                                        $isOverdue = $t->isOverdue();
                                        $isToday = $t->status !== 'finalizado' && !$isOverdue && (
                                            ($t->start_date && substr((string)$t->start_date, 0, 10) === $todayBolivia) ||
                                            ($t->end_date && substr((string)$t->end_date, 0, 10) === $todayBolivia) ||
                                            (!$t->start_date && !$t->end_date && $t->created_at && $t->created_at->copy()->timezone('America/La_Paz')->toDateString() === $todayBolivia)
                                        );

                                        $matchesInitial = true;
                                        if ($currentResumenStatus === 'vencida') {
                                            $matchesInitial = $isOverdue;
                                        } elseif ($currentResumenStatus !== 'all' && !empty($currentResumenStatus)) {
                                            $matchesInitial = ($t->status === $currentResumenStatus);
                                        }

                                        if ($isOverdue) {
                                            $iconName = 'alert-triangle';
                                            $iconBoxClass = 'bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400';
                                            $badgeLabel = 'Vencida';
                                            $badgeClass = 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300';
                                            $dueRef = $t->end_date ? \Carbon\Carbon::parse($t->end_date) : ($t->start_date ? \Carbon\Carbon::parse($t->start_date) : null);
                                            $temporalText = 'Debía realizarse: ' . ($dueRef ? $dueRef->locale('es')->isoFormat('D MMM') : 'Ayer');
                                        } elseif ($t->status === 'en_proceso') {
                                            $iconName = 'clock';
                                            $iconBoxClass = 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400';
                                            $badgeLabel = 'En proceso';
                                            $badgeClass = 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300';
                                            $timeStr = $t->start_time ? substr($t->start_time, 0, 5) : ($t->end_time ? substr($t->end_time, 0, 5) : 'Hoy');
                                            $temporalText = $isToday ? ('Hoy · ' . $timeStr) : ($t->end_date ? 'Vence: ' . \Carbon\Carbon::parse($t->end_date)->locale('es')->isoFormat('D MMM') : 'En curso');
                                        } elseif ($t->status === 'en_revision') {
                                            $iconName = 'search';
                                            $iconBoxClass = 'bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400';
                                            $badgeLabel = 'En revisión';
                                            $badgeClass = 'bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300';
                                            $temporalText = $t->end_date ? 'Límite: ' . \Carbon\Carbon::parse($t->end_date)->locale('es')->isoFormat('D MMM') : 'Pendiente de aprobación';
                                        } elseif ($t->status === 'finalizado') {
                                            $iconName = 'check-circle-2';
                                            $iconBoxClass = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400';
                                            $badgeLabel = 'Finalizada';
                                            $badgeClass = 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300';
                                            $temporalText = 'Completada' . ($t->updated_at ? ' · ' . $t->updated_at->locale('es')->isoFormat('D MMM') : '');
                                        } elseif ($t->status === 'rechazado') {
                                            $iconName = 'x-circle';
                                            $iconBoxClass = 'bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400';
                                            $badgeLabel = 'Rechazada';
                                            $badgeClass = 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300';
                                            $temporalText = 'Requiere ajustes';
                                        } else {
                                            $iconName = $t->recurring_task_id ? 'repeat' : 'circle';
                                            $iconBoxClass = $t->recurring_task_id ? 'bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400';
                                            $badgeLabel = 'No iniciada';
                                            $badgeClass = 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300';
                                            $temporalText = $isToday ? 'Hoy · ' . ($t->start_time ? substr($t->start_time, 0, 5) : 'Sin hora') : ($t->start_date ? 'Programada: ' . \Carbon\Carbon::parse($t->start_date)->locale('es')->isoFormat('D MMM') : 'Por iniciar');
                                        }
                                    @endphp
                                    <div onclick='openTaskModal(@json($t->load(["assignedUsers", "subtasks"])))'
                                        data-status="{{ $t->status }}"
                                        data-overdue="{{ $isOverdue ? '1' : '0' }}"
                                        class="all-tasks-item {{ !$matchesInitial ? 'hidden' : '' }} p-2.5 sm:p-3 rounded-xl border border-slate-100 dark:border-transparent bg-slate-50/60 dark:bg-slate-800/40 hover:bg-slate-100/70 dark:hover:bg-slate-800/80 transition flex items-center justify-between gap-3 cursor-pointer group">
                                        <div class="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
                                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl {{ $iconBoxClass }} flex items-center justify-center shrink-0">
                                                <i data-lucide="{{ $iconName }}" class="w-4 h-4"></i>
                                            </div>
                                            <div class="min-w-0 flex-1">
                                                <div class="flex items-center gap-1.5 flex-wrap">
                                                    <h4 class="text-xs sm:text-[13px] font-bold text-slate-900 dark:text-slate-100 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition">
                                                        {{ $t->title }}
                                                    </h4>
                                                    <span class="text-[9px] sm:text-[10px] font-semibold px-1.5 py-0.2 rounded-md {{ $badgeClass }} shrink-0">
                                                        {{ $badgeLabel }}
                                                    </span>
                                                </div>
                                                <p class="text-[11px] {{ $isOverdue ? 'text-red-600/90 dark:text-red-400/90 font-medium' : 'text-slate-500 dark:text-slate-400' }} mt-0.5 truncate">
                                                    {{ $temporalText }}
                                                </p>
                                            </div>
                                        </div>
                                        @if($t->assignedUsers->isNotEmpty())
                                            <div class="flex items-center -space-x-1 shrink-0">
                                                @foreach($t->assignedUsers->take(2) as $au)
                                                    <span class="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 font-bold text-[9px] flex items-center justify-center border border-white dark:border-transparent" title="{{ $au->name }}">
                                                        {{ $au->initials }}
                                                    </span>
                                                @endforeach
                                            </div>
                                        @endif
                                    </div>
                                @empty
                                    <div class="text-center py-12 text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
                                        <i data-lucide="clipboard-x" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                        <span>No hay tareas registradas para este criterio.</span>
                                    </div>
                                @endforelse
                            </div>
                        </div>

                        <!-- CONTENEDOR 2: Tareas periódicas con selector Hoy / Mes / Año -->
                        <div id="contenedor-periodicas" class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 shadow-soft flex flex-col lg:h-[650px]">
                            @php
                                $activePeriodicPeriod = $periodicPeriod ?? request('periodic_period', 'hoy');
                                if (!in_array($activePeriodicPeriod, ['hoy', 'mes', 'anio'])) {
                                    $activePeriodicPeriod = 'hoy';
                                }
                                $activePeriodicCount = match($activePeriodicPeriod) {
                                    'mes' => ($monthRecurringTasks ?? collect())->count(),
                                    'anio' => ($yearRecurringTasks ?? collect())->count(),
                                    default => ($todayRecurringTasks ?? collect())->count(),
                                };
                            @endphp

                            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3.5 gap-2 flex-wrap shrink-0">
                                <div class="flex items-center gap-2 min-w-0">
                                    <div class="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                                        <i data-lucide="repeat" class="w-4 h-4"></i>
                                    </div>
                                    <h3 class="text-sm font-bold text-slate-900 dark:text-white truncate">Tareas periódicas</h3>
                                    <span id="periodic-tasks-count-badge" class="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 shrink-0">
                                        {{ $activePeriodicCount }}
                                    </span>
                                </div>

                                <!-- Selector de periodos compacto y control de calendario -->
                                <div class="flex items-center gap-1.5 shrink-0">
                                    <button type="button"
                                        id="resumen-periodic-calendar-btn"
                                        onclick="onPeriodicCalendarIconClick()"
                                        title="Ver tareas periódicas del mes actual"
                                        class="w-7 h-7 sm:w-8 sm:h-8 rounded-xl border {{ $activePeriodicPeriod === 'mes' ? 'bg-emerald-50 text-emerald-600 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-400 dark:border-emerald-700' : 'bg-slate-50 text-slate-600 border-slate-200/80 hover:bg-emerald-50 hover:text-emerald-600 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 dark:hover:bg-emerald-950/50 dark:hover:text-emerald-400' }} flex items-center justify-center transition shadow-2xs cursor-pointer">
                                        <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                                    </button>

                                    <div class="relative flex items-center shrink-0">
                                        <select id="resumen-periodic-period-filter" onchange="changePeriodicPeriod(this.value)"
                                            class="pl-3 pr-7 py-1.5 rounded-xl bg-slate-50 hover:bg-slate-100/80 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 text-xs font-semibold appearance-none cursor-pointer outline-none focus:ring-2 focus:ring-emerald-500/20 transition shadow-2xs"
                                            title="Seleccionar periodo de tareas periódicas">
                                            <option value="hoy" {{ $activePeriodicPeriod === 'hoy' ? 'selected' : '' }}>Hoy</option>
                                            <option value="mes" {{ $activePeriodicPeriod === 'mes' ? 'selected' : '' }}>Mes</option>
                                            <option value="anio" {{ $activePeriodicPeriod === 'anio' ? 'selected' : '' }}>Año</option>
                                        </select>
                                        <i data-lucide="chevron-down" class="w-3.5 h-3.5 absolute right-2 text-slate-400 pointer-events-none"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="max-h-[580px] lg:max-h-none overflow-y-auto pr-1 pb-1 flex-1 min-h-0">
                                <!-- Lista: Hoy -->
                                <div id="periodic-tasks-list-hoy" class="space-y-2.5 {{ $activePeriodicPeriod === 'hoy' ? '' : 'hidden' }}">
                                    @forelse($todayRecurringTasks as $rtTask)
                                        @php
                                            $recRule = $rtTask->recurringTask;
                                            $recLabel = $recRule ? ucfirst($recRule->recurrence ?? 'Diaria') : 'Periódica';
                                            
                                            if ($rtTask->status === 'finalizado') {
                                                $badgeLabel = 'Finalizada';
                                                $badgeClass = 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300';
                                                $iconName = 'check-circle-2';
                                                $iconBoxClass = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400';
                                            } elseif ($rtTask->isOverdue()) {
                                                $badgeLabel = 'Vencida';
                                                $badgeClass = 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300';
                                                $iconName = 'alert-triangle';
                                                $iconBoxClass = 'bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400';
                                            } elseif ($rtTask->status === 'en_proceso') {
                                                $badgeLabel = 'En proceso';
                                                $badgeClass = 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300';
                                                $iconName = 'clock';
                                                $iconBoxClass = 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400';
                                            } elseif ($rtTask->status === 'en_revision') {
                                                $badgeLabel = 'En revisión';
                                                $badgeClass = 'bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300';
                                                $iconName = 'search';
                                                $iconBoxClass = 'bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400';
                                            } else {
                                                $badgeLabel = $recLabel;
                                                $badgeClass = 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300';
                                                $iconName = 'repeat';
                                                $iconBoxClass = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400';
                                            }

                                            $timeStr = $rtTask->start_time ? substr($rtTask->start_time, 0, 5) : ($recRule?->start_time ? substr($recRule->start_time, 0, 5) : 'Todo el día');
                                            $temporalText = 'Hoy · ' . $timeStr;
                                        @endphp
                                        <div onclick='openTaskModal(@json($rtTask->load(["assignedUsers", "subtasks"])))'
                                            class="periodic-task-item p-2.5 sm:p-3 rounded-xl border border-slate-100 dark:border-transparent bg-slate-50/60 dark:bg-slate-800/40 hover:bg-slate-100/70 dark:hover:bg-slate-800/80 transition flex items-center justify-between gap-3 cursor-pointer group">
                                            <div class="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
                                                <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl {{ $iconBoxClass }} flex items-center justify-center shrink-0">
                                                    <i data-lucide="{{ $iconName }}" class="w-4 h-4"></i>
                                                </div>
                                                <div class="min-w-0 flex-1">
                                                    <div class="flex items-center gap-1.5 flex-wrap">
                                                        <h4 class="text-xs sm:text-[13px] font-bold text-slate-900 dark:text-slate-100 truncate group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition">
                                                            {{ $rtTask->title }}
                                                        </h4>
                                                        <span class="text-[9px] sm:text-[10px] font-semibold px-1.5 py-0.2 rounded-md {{ $badgeClass }} shrink-0">
                                                            {{ $badgeLabel }}
                                                        </span>
                                                    </div>
                                                    <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                                                        {{ $temporalText }}
                                                    </p>
                                                </div>
                                            </div>
                                            @if($rtTask->assignedUsers->isNotEmpty())
                                                <div class="flex items-center -space-x-1 shrink-0">
                                                    @foreach($rtTask->assignedUsers->take(2) as $au)
                                                        <span class="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-[9px] flex items-center justify-center border border-white dark:border-transparent" title="{{ $au->name }}">
                                                            {{ $au->initials }}
                                                        </span>
                                                    @endforeach
                                                </div>
                                            @endif
                                        </div>
                                    @empty
                                        <div class="text-center py-12 text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
                                            <i data-lucide="calendar-check" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                            <span>No hay tareas periódicas programadas para hoy.</span>
                                        </div>
                                    @endforelse
                                </div>

                                <!-- Lista: Mes -->
                                <div id="periodic-tasks-list-mes" class="space-y-2.5 {{ $activePeriodicPeriod === 'mes' ? '' : 'hidden' }}">
                                    @forelse($monthRecurringTasks ?? [] as $rtTask)
                                        @php
                                            $recRule = $rtTask->recurringTask;
                                            $recLabel = $recRule ? ucfirst($recRule->recurrence ?? 'Diaria') : 'Periódica';
                                            
                                            if ($rtTask->status === 'finalizado') {
                                                $badgeLabel = 'Finalizada';
                                                $badgeClass = 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300';
                                                $iconName = 'check-circle-2';
                                                $iconBoxClass = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400';
                                            } elseif ($rtTask->isOverdue()) {
                                                $badgeLabel = 'Vencida';
                                                $badgeClass = 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300';
                                                $iconName = 'alert-triangle';
                                                $iconBoxClass = 'bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400';
                                            } elseif ($rtTask->status === 'en_proceso') {
                                                $badgeLabel = 'En proceso';
                                                $badgeClass = 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300';
                                                $iconName = 'clock';
                                                $iconBoxClass = 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400';
                                            } elseif ($rtTask->status === 'en_revision') {
                                                $badgeLabel = 'En revisión';
                                                $badgeClass = 'bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300';
                                                $iconName = 'search';
                                                $iconBoxClass = 'bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400';
                                            } else {
                                                $badgeLabel = $recLabel;
                                                $badgeClass = 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300';
                                                $iconName = 'repeat';
                                                $iconBoxClass = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400';
                                            }

                                            $isToday = $rtTask->start_date && substr((string)$rtTask->start_date, 0, 10) === $todayBolivia;
                                            $timeStr = $rtTask->start_time ? substr($rtTask->start_time, 0, 5) : ($recRule?->start_time ? substr($recRule->start_time, 0, 5) : null);
                                            if ($isToday) {
                                                $temporalText = 'Hoy · ' . ($timeStr ?: 'Todo el día');
                                            } else {
                                                $dateObj = \Carbon\Carbon::parse($rtTask->start_date);
                                                $temporalText = $dateObj->locale('es')->isoFormat('D MMM') . ($timeStr ? ' · ' . $timeStr : '');
                                            }
                                        @endphp
                                        <div onclick='openTaskModal(@json($rtTask->load(["assignedUsers", "subtasks"])))'
                                            class="periodic-task-item p-2.5 sm:p-3 rounded-xl border border-slate-100 dark:border-transparent bg-slate-50/60 dark:bg-slate-800/40 hover:bg-slate-100/70 dark:hover:bg-slate-800/80 transition flex items-center justify-between gap-3 cursor-pointer group">
                                            <div class="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
                                                <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl {{ $iconBoxClass }} flex items-center justify-center shrink-0">
                                                    <i data-lucide="{{ $iconName }}" class="w-4 h-4"></i>
                                                </div>
                                                <div class="min-w-0 flex-1">
                                                    <div class="flex items-center gap-1.5 flex-wrap">
                                                        <h4 class="text-xs sm:text-[13px] font-bold text-slate-900 dark:text-slate-100 truncate group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition">
                                                            {{ $rtTask->title }}
                                                        </h4>
                                                        <span class="text-[9px] sm:text-[10px] font-semibold px-1.5 py-0.2 rounded-md {{ $badgeClass }} shrink-0">
                                                            {{ $badgeLabel }}
                                                        </span>
                                                    </div>
                                                    <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                                                        {{ $temporalText }}
                                                    </p>
                                                </div>
                                            </div>
                                            @if($rtTask->assignedUsers->isNotEmpty())
                                                <div class="flex items-center -space-x-1 shrink-0">
                                                    @foreach($rtTask->assignedUsers->take(2) as $au)
                                                        <span class="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-[9px] flex items-center justify-center border border-white dark:border-transparent" title="{{ $au->name }}">
                                                            {{ $au->initials }}
                                                        </span>
                                                    @endforeach
                                                </div>
                                            @endif
                                        </div>
                                    @empty
                                        <div class="text-center py-12 text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
                                            <i data-lucide="calendar-range" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                            <span>No hay tareas periódicas programadas para este mes.</span>
                                        </div>
                                    @endforelse
                                </div>

                                <!-- Lista: Año -->
                                <div id="periodic-tasks-list-anio" class="space-y-2.5 {{ $activePeriodicPeriod === 'anio' ? '' : 'hidden' }}">
                                    @forelse($yearRecurringTasks ?? [] as $rtTask)
                                        @php
                                            $recRule = $rtTask->recurringTask;
                                            $recLabel = $recRule ? ucfirst($recRule->recurrence ?? 'Diaria') : 'Periódica';
                                            
                                            if ($rtTask->status === 'finalizado') {
                                                $badgeLabel = 'Finalizada';
                                                $badgeClass = 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300';
                                                $iconName = 'check-circle-2';
                                                $iconBoxClass = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400';
                                            } elseif ($rtTask->isOverdue()) {
                                                $badgeLabel = 'Vencida';
                                                $badgeClass = 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300';
                                                $iconName = 'alert-triangle';
                                                $iconBoxClass = 'bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400';
                                            } elseif ($rtTask->status === 'en_proceso') {
                                                $badgeLabel = 'En proceso';
                                                $badgeClass = 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300';
                                                $iconName = 'clock';
                                                $iconBoxClass = 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400';
                                            } elseif ($rtTask->status === 'en_revision') {
                                                $badgeLabel = 'En revisión';
                                                $badgeClass = 'bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300';
                                                $iconName = 'search';
                                                $iconBoxClass = 'bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400';
                                            } else {
                                                $badgeLabel = $recLabel;
                                                $badgeClass = 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300';
                                                $iconName = 'repeat';
                                                $iconBoxClass = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400';
                                            }

                                            $isToday = $rtTask->start_date && substr((string)$rtTask->start_date, 0, 10) === $todayBolivia;
                                            $timeStr = $rtTask->start_time ? substr($rtTask->start_time, 0, 5) : ($recRule?->start_time ? substr($recRule->start_time, 0, 5) : null);
                                            if ($isToday) {
                                                $temporalText = 'Hoy · ' . ($timeStr ?: 'Todo el día');
                                            } else {
                                                $dateObj = \Carbon\Carbon::parse($rtTask->start_date);
                                                $temporalText = $dateObj->locale('es')->isoFormat('D MMM YYYY') . ($timeStr ? ' · ' . $timeStr : '');
                                            }
                                        @endphp
                                        <div onclick='openTaskModal(@json($rtTask->load(["assignedUsers", "subtasks"])))'
                                            class="periodic-task-item p-2.5 sm:p-3 rounded-xl border border-slate-100 dark:border-transparent bg-slate-50/60 dark:bg-slate-800/40 hover:bg-slate-100/70 dark:hover:bg-slate-800/80 transition flex items-center justify-between gap-3 cursor-pointer group">
                                            <div class="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
                                                <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl {{ $iconBoxClass }} flex items-center justify-center shrink-0">
                                                    <i data-lucide="{{ $iconName }}" class="w-4 h-4"></i>
                                                </div>
                                                <div class="min-w-0 flex-1">
                                                    <div class="flex items-center gap-1.5 flex-wrap">
                                                        <h4 class="text-xs sm:text-[13px] font-bold text-slate-900 dark:text-slate-100 truncate group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition">
                                                            {{ $rtTask->title }}
                                                        </h4>
                                                        <span class="text-[9px] sm:text-[10px] font-semibold px-1.5 py-0.2 rounded-md {{ $badgeClass }} shrink-0">
                                                            {{ $badgeLabel }}
                                                        </span>
                                                    </div>
                                                    <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                                                        {{ $temporalText }}
                                                    </p>
                                                </div>
                                            </div>
                                            @if($rtTask->assignedUsers->isNotEmpty())
                                                <div class="flex items-center -space-x-1 shrink-0">
                                                    @foreach($rtTask->assignedUsers->take(2) as $au)
                                                        <span class="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-[9px] flex items-center justify-center border border-white dark:border-transparent" title="{{ $au->name }}">
                                                            {{ $au->initials }}
                                                        </span>
                                                    @endforeach
                                                </div>
                                            @endif
                                        </div>
                                    @empty
                                        <div class="text-center py-12 text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
                                            <i data-lucide="calendar" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                                            <span>No hay tareas periódicas programadas para este año.</span>
                                        </div>
                                    @endforelse
                                </div>
                            </div>
                        </div>

                        <!-- CONTENEDOR 3: Tareas vencidas -->
                        <div id="contenedor-tareas-vencidas" class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 shadow-soft flex flex-col lg:h-[650px]">
                            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3.5 shrink-0">
                                <div class="flex items-center gap-2.5 min-w-0">
                                    <div class="w-8 h-8 rounded-xl bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
                                        <i data-lucide="alert-triangle" class="w-4 h-4"></i>
                                    </div>
                                    <h3 class="text-sm font-bold text-slate-900 dark:text-white truncate">Tareas vencidas</h3>
                                </div>
                                <span class="text-xs font-bold px-2 py-0.5 rounded-full {{ $overdueCount > 0 ? 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300' }} shrink-0">
                                    {{ $overdueCount }}
                                </span>
                            </div>

                            <div class="space-y-2.5 max-h-[580px] lg:max-h-none overflow-y-auto pr-1 pb-1 flex-1 min-h-0">
                                @forelse($overdueTasks as $ot)
                                    @php
                                        $dueDateFormatted = $ot->end_date ? \Carbon\Carbon::parse($ot->end_date)->locale('es')->isoFormat('D MMM') : ($ot->start_date ? \Carbon\Carbon::parse($ot->start_date)->locale('es')->isoFormat('D MMM') : 'Fecha superada');
                                        $temporalText = 'Debía realizarse: ' . $dueDateFormatted . ($ot->end_time ? ' · ' . substr($ot->end_time, 0, 5) : '');
                                    @endphp
                                    <div onclick='openTaskModal(@json($ot->load(["assignedUsers", "subtasks"])))'
                                        class="overdue-task-item p-2.5 sm:p-3 rounded-xl border border-red-200/50 dark:border-transparent bg-red-50/40 dark:bg-red-950/20 hover:bg-red-50/70 dark:hover:bg-red-950/40 transition flex items-center justify-between gap-3 cursor-pointer group">
                                        <div class="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
                                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-red-100 dark:bg-red-950/80 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
                                                <i data-lucide="alert-triangle" class="w-4 h-4"></i>
                                            </div>
                                            <div class="min-w-0 flex-1">
                                                <div class="flex items-center gap-1.5 flex-wrap">
                                                    <h4 class="text-xs sm:text-[13px] font-bold text-red-900 dark:text-red-200 truncate group-hover:text-red-700 dark:group-hover:text-red-300 transition">
                                                        {{ $ot->title }}
                                                    </h4>
                                                    <span class="text-[9px] sm:text-[10px] font-semibold px-1.5 py-0.2 rounded-md bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 shrink-0">
                                                        Vencida
                                                    </span>
                                                </div>
                                                <p class="text-[11px] text-red-600/90 dark:text-red-400/90 mt-0.5 truncate font-medium">
                                                    {{ $temporalText }}
                                                </p>
                                            </div>
                                        </div>
                                        @if($ot->assignedUsers->isNotEmpty())
                                            <div class="flex items-center -space-x-1 shrink-0">
                                                @foreach($ot->assignedUsers->take(2) as $au)
                                                    <span class="w-6 h-6 rounded-full bg-red-100 dark:bg-red-900/60 text-red-700 dark:text-red-300 font-bold text-[9px] flex items-center justify-center border border-white dark:border-transparent" title="{{ $au->name }}">
                                                        {{ $au->initials }}
                                                    </span>
                                                @endforeach
                                            </div>
                                        @endif
                                    </div>
                                @empty
                                    <div class="text-center py-12 text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
                                        <div class="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                                            <i data-lucide="check" class="w-5 h-5"></i>
                                        </div>
                                        <span class="font-bold text-slate-700 dark:text-slate-300">¡Todo al día!</span>
                                        <span class="text-[11px]">No hay tareas vencidas pendientes.</span>
                                    </div>
                                @endforelse
                            </div>
                        </div>

                    </div>
                </div>

            <!-- ========================================================================= -->
            <!-- VIEW 1: CALENDARIO                                                        -->
            <!-- ========================================================================= -->
            @elseif($activeView === 'calendario')
                {{-- 
                =========================================================================
                BLOQUE ORIGINAL COMENTADO (Distribución anterior: Lista a la Izquierda 7/12, Calendario a la Derecha 5/12)
                =========================================================================
                <div class="flex flex-col lg:flex-row gap-5 sm:gap-6">
                    <!-- Left List: Tasks list by date (anteriormente 7/12 a la izquierda) -->
                    <div class="lg:w-7/12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 shadow-soft space-y-4">
                        ...
                    </div>

                    <!-- Right FullCalendar Render (anteriormente 5/12 a la derecha) -->
                    <div class="lg:w-5/12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3 sm:p-5 shadow-soft overflow-hidden">
                        <div id="calendar-container" class="w-full overflow-x-auto"></div>
                    </div>
                </div>
                =========================================================================
                --}}

                <div id="cal-main-container" class="flex flex-col lg:flex-row gap-5 sm:gap-6 lg:items-start">
                    <!-- Script de inicialización inmediata para aplicar estado de localStorage sin parpadeo -->
                    <script>
                        (function() {
                            try {
                                var isSplit = (localStorage.getItem('calendarCollapsed') ?? localStorage.getItem('calendar_collapsed')) === 'true';
                                if (isSplit) {
                                    document.documentElement.classList.add('cal-split-active');
                                }
                            } catch(e) {}
                        })();
                    </script>

                    <!-- IZQUIERDA: Calendario con soporte de Ancho Completo o Dividido con Lista de Tareas -->
                    <div id="cal-view-calendar" class="w-full bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 shadow-soft overflow-hidden flex flex-col transition-colors duration-150">
                        <!-- Cabecera del Calendario con botones [ Contraer ] y [ Expandir ] -->
                        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4 gap-2">
                            <div class="flex items-center gap-2.5 min-w-0">
                                <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                                    <i data-lucide="calendar" class="w-4 h-4"></i>
                                </div>
                                <div class="min-w-0">
                                    <h3 class="text-sm sm:text-base font-bold text-slate-800 dark:text-white truncate">
                                        Calendario
                                    </h3>
                                </div>
                            </div>

                            <div class="flex items-center gap-2 shrink-0">
                                @if(!$user->isHelper() && $activeProject)
                                    <div class="relative flex items-center">
                                        <i data-lucide="user" class="w-3.5 h-3.5 absolute left-2.5 text-slate-400 pointer-events-none"></i>
                                        <select id="calendar-user-filter" onchange="onUserFilterChange(this.value)"
                                            class="pl-7 pr-7 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200/70 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 text-xs font-semibold appearance-none cursor-pointer outline-none focus:ring-2 focus:ring-indigo-500/20 transition max-w-[145px] sm:max-w-[190px] truncate"
                                            title="Filtrar tareas por usuario">
                                            <option value="">Todos los usuarios</option>
                                            @foreach($projectUsers as $pUser)
                                                <option value="{{ $pUser->id }}" {{ (string)$selectedUserId === (string)$pUser->id ? 'selected' : '' }}>
                                                    {{ $pUser->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <i data-lucide="chevron-down" class="w-3.5 h-3.5 absolute right-2 text-slate-400 pointer-events-none"></i>
                                    </div>
                                @endif

                                <!-- Botón Contraer / Expandir vista de Calendario principal (conmutador con Lista de Tareas) -->
                                <button type="button" id="btn-toggle-calendar-split" onclick="toggleCalendarSplitView()"
                                    class="hidden lg:flex px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 text-xs font-semibold items-center gap-1.5 transition shadow-2xs active:scale-95 shrink-0"
                                    title="Contraer calendario para mostrar lista de tareas">
                                    <i id="btn-toggle-calendar-icon" data-lucide="columns-2" class="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400"></i>
                                    <span id="btn-toggle-calendar-text">Contraer</span>
                                </button>
                            </div>
                        </div>

                        <!-- Leyenda de Estados en Calendario según Configuración -->
                        <div class="flex items-center gap-3 overflow-x-auto no-scrollbar text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-3 px-1 py-1">
                            <span class="inline-flex items-center gap-1.5 shrink-0">
                                <span class="w-2.5 h-2.5 rounded-full shadow-2xs" style="background-color: {{ $estadoColores['no_iniciado'] ?? '#64748b' }};"></span>
                                No iniciado
                            </span>
                            <span class="inline-flex items-center gap-1.5 shrink-0">
                                <span class="w-2.5 h-2.5 rounded-full shadow-2xs" style="background-color: {{ $estadoColores['en_proceso'] ?? '#3b82f6' }};"></span>
                                En proceso
                            </span>
                            <span class="inline-flex items-center gap-1.5 shrink-0">
                                <span class="w-2.5 h-2.5 rounded-full shadow-2xs" style="background-color: {{ $estadoColores['en_revision'] ?? '#f59e0b' }};"></span>
                                En revisión
                            </span>
                            <span class="inline-flex items-center gap-1.5 shrink-0">
                                <span class="w-2.5 h-2.5 rounded-full shadow-2xs" style="background-color: {{ $estadoColores['rechazado'] ?? '#ef4444' }};"></span>
                                Rechazado
                            </span>
                            <span class="inline-flex items-center gap-1.5 shrink-0">
                                <span class="w-2.5 h-2.5 rounded-full shadow-2xs" style="background-color: {{ $estadoColores['finalizado'] ?? '#10b981' }};"></span>
                                Finalizado
                            </span>
                            <span class="inline-flex items-center gap-1.5 shrink-0 text-red-600 dark:text-red-400 font-semibold border-l border-slate-200 dark:border-slate-700 pl-3">
                                <span class="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
                                No iniciado vencido (Rojo)
                            </span>
                        </div>

                        <!-- Contenedor del calendario en vista normal -->
                        <div id="calendar-normal-slot" class="w-full">
                            <div id="calendar-container" class="w-full overflow-x-auto"></div>
                        </div>
                    </div>

                    <!-- DERECHA: Lista de Tareas del Proyecto (5/12 en lg+) manteniendo exactamente su contenido y funcionamiento -->
                    <div id="cal-view-list" class="w-full lg:w-5/12 lg:hidden bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 shadow-soft flex flex-col overflow-hidden">
                        <!-- Task List Header & Tabs -->
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4 gap-2 shrink-0">
                            <h3 class="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                <i data-lucide="list-checks" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                                <span>Lista de Tareas del Proyecto</span>
                            </h3>

                            <!-- Tabs de Filtro: Tareas de Hoy vs Tareas del Mes -->
                            <div class="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs overflow-x-auto no-scrollbar max-w-full">
                                @php
                                    $taskFilterParams = array_filter([
                                        'project_id' => $activeProject->id,
                                        'module_id' => $activeModuleId,
                                        'view' => $activeView,
                                        'user_id' => $selectedUserId,
                                        'task_filter_option' => $taskFilterOption,
                                        'task_search' => $taskSearch,
                                    ]);
                                    $taskMatchesFilter = function($task) use ($selectedUserId, $taskFilterOption, $taskSearch) {
                                        if ($selectedUserId && !$task->assignedUsers->contains('id', (int)$selectedUserId)) return false;

                                        // Buscador por nombre
                                        if ($taskSearch !== '') {
                                            $title = mb_strtolower($task->title ?? '');
                                            if (!str_contains($title, mb_strtolower($taskSearch))) {
                                                return false;
                                            }
                                        }

                                        // Filtro Unificado
                                        if (empty($taskFilterOption) || $taskFilterOption === 'status:all' || $taskFilterOption === 'priority:all') {
                                            return true;
                                        }

                                        [$fType, $fVal] = array_pad(explode(':', $taskFilterOption, 2), 2, '');
                                        if ($fType === 'status') {
                                            return $fVal === 'all' || $task->status === $fVal;
                                        }
                                        if ($fType === 'priority') {
                                            $pNorm = strtolower(trim($task->priority === 'urgente' ? 'alta' : ($task->priority ?? 'media')));
                                            return $fVal === 'all' || $pNorm === strtolower($fVal);
                                        }
                                        if ($fType === 'due') {
                                            $isOverdue = $task->isOverdue();
                                            if ($fVal === 'vencidas') return $isOverdue;
                                            if ($fVal === 'no_vencidas') return !$isOverdue;
                                        }
                                        return true;
                                    };
                                    $todayVisibleCount = $todayTasks->filter($taskMatchesFilter)->count();
                                    $monthVisibleCount = $monthTasks->filter($taskMatchesFilter)->count();
                                    $calFilteredTasks = $filteredTasks;
                                    $totalVisibleTasks = $calFilteredTasks->filter($taskMatchesFilter)->count();
                                @endphp
                                <a id="tab-tasks-today" href="{{ route('dashboard', array_merge($taskFilterParams, ['task_filter' => 'hoy'])) }}"
                                    class="px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap {{ $taskFilter === 'hoy' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                                    <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                                    <span>Tareas de Hoy</span>
                                    <span id="badge-count-today" class="px-1.5 py-0.2 text-[10px] rounded-full {{ $taskFilter === 'hoy' ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300' }}">{{ $todayVisibleCount }}</span>
                                </a>
                                <a id="tab-tasks-month" href="{{ route('dashboard', array_merge($taskFilterParams, ['task_filter' => 'mes'])) }}"
                                    class="px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap {{ $taskFilter === 'mes' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                                    <i data-lucide="calendar-range" class="w-3.5 h-3.5"></i>
                                    <span>Tareas del Mes</span>
                                    <span id="badge-count-month" class="px-1.5 py-0.2 text-[10px] rounded-full {{ $taskFilter === 'mes' ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300' }}">{{ $monthVisibleCount }}</span>
                                </a>
                            </div>
                        </div>

                        <!-- Barra de Filtros: Selector Unificado y Buscador por Nombre -->
                        <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pb-3 mb-3 border-b border-slate-100 dark:border-slate-800/80 shrink-0">
                            <!-- Selector Unificado de Filtros -->
                            <div class="relative w-full sm:w-[210px] shrink-0">
                                <i data-lucide="filter" class="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"></i>
                                <select id="task-filter-select" onchange="onTaskUnifiedFilterChange()"
                                    class="w-full pl-8 pr-7 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200/70 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 text-xs font-semibold appearance-none cursor-pointer outline-none focus:ring-2 focus:ring-indigo-500/20 transition truncate"
                                    title="Filtrar tareas">
                                    <option value="" {{ empty($taskFilterOption) ? 'selected' : '' }} class="font-semibold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200">Todas las tareas</option>

                                    <optgroup label="Estados" class="font-bold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800">
                                        @foreach($quickStatusList as $st)
                                            <option value="status:{{ $st['id'] }}" {{ $taskFilterOption === 'status:'.$st['id'] ? 'selected' : '' }} class="font-normal bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                                                {{ $st['title'] }}
                                            </option>
                                        @endforeach
                                    </optgroup>

                                    <optgroup label="Prioridades" class="font-bold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800">
                                        @foreach($prioridadesList as $prio)
                                            <option value="priority:{{ $prio['id'] }}" {{ $taskFilterOption === 'priority:'.$prio['id'] ? 'selected' : '' }} class="font-normal bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                                                {{ $prio['title'] }}
                                            </option>
                                        @endforeach
                                    </optgroup>

                                    <optgroup label="Vencimiento" class="font-bold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800">
                                        <option value="due:vencidas" {{ $taskFilterOption === 'due:vencidas' ? 'selected' : '' }} class="font-normal bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200">Vencidas</option>
                                       <!-- <option value="due:no_vencidas" {{ $taskFilterOption === 'due:no_vencidas' ? 'selected' : '' }} class="font-normal bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200">No vencidas</option>-->
                                    </optgroup>
                                </select>
                                <i data-lucide="chevron-down" class="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"></i>
                            </div>

                            <!-- Buscador por nombre de tarea -->
                            <div class="relative flex-1 min-w-0">
                                <i data-lucide="search" class="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"></i>
                                <input type="text" id="task-search-input" value="{{ $taskSearch }}"
                                    oninput="onTaskSearchInput(this.value)"
                                    placeholder="Buscar tarea..."
                                    autocomplete="off"
                                    class="w-full pl-8 pr-7 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200/70 focus:bg-white dark:bg-slate-800 dark:hover:bg-slate-700/80 dark:focus:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 text-xs font-medium placeholder-slate-400 outline-none focus:ring-2 focus:ring-indigo-500/20 transition truncate"
                                    title="Buscar tarea por nombre">
                                <button type="button" id="btn-clear-task-search" onclick="clearTaskSearch()"
                                    class="{{ empty($taskSearch) ? 'hidden' : '' }} absolute right-2 top-1/2 -translate-y-1/2 p-0.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition cursor-pointer"
                                    title="Limpiar búsqueda">
                                    <i data-lucide="x" class="w-3.5 h-3.5"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Scrollable Tasks Container -->
                        <div class="flex-1 min-h-0 overflow-y-auto pr-1.5 space-y-4 max-h-[640px] lg:max-h-none">
                        @if($calFilteredTasks->isEmpty())
                            <div class="text-center py-12 text-slate-400 dark:text-slate-500 text-xs">
                                {{ $taskFilter === 'mes' ? 'No hay tareas registradas para este mes.' : 'No hay tareas pendientes para hoy.' }}
                            </div>
                        @else
                            @php
                                if ($taskFilter === 'mes') {
                                    $groupedTasks = $calFilteredTasks->sortBy(function($t) {
                                        if ($t->start_date) return \Carbon\Carbon::parse($t->start_date)->timestamp;
                                        if ($t->end_date) return \Carbon\Carbon::parse($t->end_date)->timestamp;
                                        return $t->created_at ? $t->created_at->timestamp : 0;
                                    })->groupBy(function($t) use ($todayBolivia) {
                                        if ($t->start_date) return \Carbon\Carbon::parse($t->start_date)->format('Y-m-d');
                                        if ($t->end_date) return \Carbon\Carbon::parse($t->end_date)->format('Y-m-d');
                                        return $t->created_at ? $t->created_at->copy()->timezone('America/La_Paz')->format('Y-m-d') : 'sin_fecha';
                                    });
                                } else {
                                    $groupedTasks = collect(['todas' => $calFilteredTasks]);
                                }
                            @endphp

                            <div class="space-y-6">
                                @foreach($groupedTasks as $dateKey => $groupTasks)
                                    @php
                                        $visibleInGroupCount = $groupTasks->filter($taskMatchesFilter)->count();
                                    @endphp
                                    <div class="task-date-group {{ $visibleInGroupCount === 0 ? 'hidden' : '' }}" data-group-date="{{ $dateKey }}">
                                        @if($taskFilter === 'mes')
                                            <div class="flex items-center gap-2 pb-2 mb-3 border-b border-slate-200 dark:border-slate-800">
                                                <i data-lucide="calendar" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
                                                <h4 class="{{ $dateKey === $todayBolivia ? 'text-sm font-bold text-black dark:text-slate-100' : 'text-xs font-bold text-slate-800 dark:text-slate-200' }}">
                                                    @if($dateKey === 'sin_fecha')
                                                        Sin Fecha Definida
                                                    @else
                                                        {{ ucfirst(\Carbon\Carbon::parse($dateKey)->locale('es')->isoFormat('dddd D \d\e MMMM, YYYY')) }}
                                                    @if($dateKey === $todayBolivia)
                                                            <span class="text-[9px] bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold px-1.5 py-0.2 rounded ml-1">Hoy</span>
                                                        @endif
                                                    @endif
                                                </h4>
                                                <span class="task-group-count text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded-full ml-auto">
                                                    {{ $visibleInGroupCount }} tarea(s)
                                                </span>
                                            </div>
                                        @endif

                                        <div class="space-y-3">
                                            @foreach($groupTasks as $t)
                                                @php
                                                    $isPendingApproval = ($t->status === 'en_revision' && $t->needs_review);
                                                    $canApproveReject = ($isPendingApproval && $user->hasFullAccess());
                                                    $isHelperRestricted = ($isPendingApproval && !$user->hasFullAccess());
                                                    $tNormalizedPrio = strtolower(trim($t->priority === 'urgente' ? 'alta' : ($t->priority ?? 'media')));
                                                    $isCardInitiallyVisible = $taskMatchesFilter($t);
                                                @endphp
                                                <div class="task-list-card group p-3 sm:p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-white dark:hover:bg-slate-800 transition shadow-xs space-y-2.5 {{ $isCardInitiallyVisible ? '' : 'hidden' }}"
                                                    data-task-id="{{ $t->id }}"
                                                    data-title="{{ mb_strtolower($t->title ?? '') }}"
                                                    data-status="{{ $t->status }}"
                                                    data-priority="{{ $tNormalizedPrio }}"
                                                    data-overdue="{{ $t->isOverdue() ? '1' : '0' }}"
                                                    data-assigned-users="{{ json_encode($t->assignedUsers->pluck('id')->all()) }}">
                                                    <!-- Fila Superior: Checkbox + Título + Descripción + Badges (Ancho Completo) -->
                                                    <div class="flex items-start gap-2.5 min-w-0">
                                                        @if($isHelperRestricted)
                                                            <div class="mt-0.5 shrink-0" title="En revisión: pendiente de aprobación del administrador">
                                                                <span class="w-4 h-4 rounded border border-purple-400 bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center cursor-not-allowed">
                                                                    <i data-lucide="clock" class="w-2.5 h-2.5"></i>
                                                                </span>
                                                            </div>
                                                        @elseif($t->isFutureScheduled())
                                                            <div class="mt-0.5 shrink-0" title="Tarea programada para una fecha futura: no disponible todavía">
                                                                <input type="checkbox" disabled
                                                                    class="w-4 h-4 rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-0 cursor-not-allowed pointer-events-none">
                                                            </div>
                                                        @elseif($canApproveReject)
                                                            <form method="POST" action="{{ route('tasks.updateStatus', $t->id) }}" class="mt-0.5 shrink-0">
                                                                @csrf
                                                                @method('PATCH')
                                                                <input type="hidden" name="status" value="finalizado">
                                                                <input type="checkbox" onchange="this.form.submit()" title="Marcar como finalizado (aprobar)"
                                                                    class="w-4 h-4 rounded border-slate-300 dark:border-slate-600 text-emerald-600 focus:ring-emerald-500 accent-emerald-600 cursor-pointer">
                                                            </form>
                                                        @else
                                                            <form method="POST" action="{{ route('tasks.updateStatus', $t->id) }}" class="mt-0.5 shrink-0">
                                                                @csrf
                                                                @method('PATCH')
                                                                <input type="hidden" name="status" value="{{ $t->status === 'finalizado' ? 'no_iniciado' : ($t->needs_review && !$user->hasFullAccess() ? 'en_revision' : 'finalizado') }}">
                                                                <input type="checkbox" onchange="this.form.submit()" {{ $t->status === 'finalizado' ? 'checked' : '' }}
                                                                    class="w-4 h-4 rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 accent-indigo-600 cursor-pointer">
                                                            </form>
                                                        @endif

                                                        <div class="min-w-0 flex-1">
                                                            @php
                                                                $isTodayTask = $t->status !== 'finalizado' && !$t->isOverdue() && (
                                                                    ($t->start_date && substr((string)$t->start_date, 0, 10) === $todayBolivia) ||
                                                                    ($t->end_date && substr((string)$t->end_date, 0, 10) === $todayBolivia) ||
                                                                    (!$t->start_date && !$t->end_date && $t->created_at && $t->created_at->copy()->timezone('America/La_Paz')->toDateString() === $todayBolivia)
                                                                );
                                                                $dueDateStr = null;
                                                                if ($t->end_date) {
                                                                    $dueDateStr = \Carbon\Carbon::parse($t->end_date)->format('d/m/Y') . ($t->end_time ? ' a las ' . substr($t->end_time, 0, 5) : '');
                                                                } elseif ($t->start_date) {
                                                                    $dueDateStr = \Carbon\Carbon::parse($t->start_date)->format('d/m/Y') . ($t->start_time ? ' a las ' . substr($t->start_time, 0, 5) : '');
                                                                }
                                                            @endphp
                                                            <h4 class="text-xs sm:text-sm font-semibold break-normal [overflow-wrap:anywhere] leading-snug {{ $t->status === 'finalizado' ? 'line-through text-slate-400 dark:text-slate-500' : ($t->isOverdue() ? 'text-red-600 dark:text-red-400 font-bold' : ($isTodayTask ? 'text-indigo-600 dark:text-indigo-400 font-bold' : 'text-slate-800 dark:text-slate-100')) }}">
                                                                {{ $t->title }}
                                                            </h4>

                                                            @if($t->description)
                                                                <p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1 break-normal [overflow-wrap:anywhere]">{{ $t->description }}</p>
                                                            @endif

                                                            <!-- Badges row -->
                                                            <div class="flex flex-wrap items-center gap-1.5 mt-2">
                                                                @if($t->isOverdue())
                                                                    <span class="text-[10px] bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                                                                        <i data-lucide="alert-circle" class="w-3 h-3 text-red-600"></i>
                                                                        <span>Vencida: {{ $dueDateStr }}</span>
                                                                    </span>
                                                                @elseif($dueDateStr)
                                                                    <span class="text-[10px] bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                                                                        <i data-lucide="calendar" class="w-3 h-3 text-indigo-500"></i>
                                                                        <span>{{ $dueDateStr }}</span>
                                                                    </span>
                                                                @endif

                                                                @if($t->module)
                                                                    <span class="text-[10px] bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-medium px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                                                                        <i data-lucide="box" class="w-3 h-3"></i>
                                                                        <span>{{ $t->module->name }}</span>
                                                                    </span>
                                                                @endif

                                                                <span class="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full
                                                                    {{ $t->priority === 'alta' ? 'bg-red-50 dark:bg-red-950/50 text-red-600 dark:text-red-400 border border-red-200/50 dark:border-red-900/40' : ($t->priority === 'media' ? 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200/50 dark:border-amber-900/40' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300') }}">
                                                                    {{ $t->priority }}
                                                                </span>

                                                                @if($t->needs_review)
                                                                    <span class="text-[10px] bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 font-medium px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                                                                        <i data-lucide="search" class="w-3 h-3"></i>
                                                                        <span>Revisión</span>
                                                                    </span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!-- Review Actions (Aprobar / Rechazar estilo Kanban) -->
                                                    @if($canApproveReject)
                                                        <div class="flex items-center gap-1.5 pt-1">
                                                            <form method="POST" action="{{ route('tasks.updateStatus', $t->id) }}" class="flex-1">
                                                                @csrf @method('PATCH')
                                                                <input type="hidden" name="status" value="finalizado">
                                                                <button type="submit" class="w-full py-1 text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-lg transition flex items-center justify-center space-x-1 cursor-pointer">
                                                                    <i data-lucide="check" class="w-3 h-3"></i>
                                                                    <span>Aprobar</span>
                                                                </button>
                                                            </form>
                                                            <form method="POST" action="{{ route('tasks.updateStatus', $t->id) }}" class="flex-1">
                                                                @csrf @method('PATCH')
                                                                <input type="hidden" name="status" value="rechazado">
                                                                <button type="submit" class="w-full py-1 text-[11px] font-semibold bg-red-50 dark:bg-red-950/60 hover:bg-red-100 dark:hover:bg-red-900/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 rounded-lg transition flex items-center justify-center space-x-1 cursor-pointer">
                                                                    <i data-lucide="x" class="w-3 h-3"></i>
                                                                    <span>Rechazar</span>
                                                                </button>
                                                            </form>
                                                        </div>
                                                    @endif

                                                    <!-- Fila Inferior: Acciones Rápidas (Distribución limpia y equilibrada) -->
                                                    <div class="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-2 task-bottom-row-expandable">
                                                        <!-- Selector de estado rápido y badge de estado -->
                                                        <div class="flex items-center gap-1.5 flex-wrap">
                                                            @if($user->hasFullAccess())
                                                                <div class="flex items-center space-x-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
                                                                    @foreach($quickStatusList as $stBtn)
                                                                        @php
                                                                            $stIcon = $stBtn['ruta_icono'] ?? ($estadoIconos[$stBtn['id']] ?? null);
                                                                            $hasCustomIcon = !empty($stIcon) && file_exists(public_path($stIcon));
                                                                            $isActive = ($t->status === $stBtn['id']);
                                                                            $btnColor = $stBtn['color'] ?? ($estadoColores[$stBtn['id']] ?? '#64748b');
                                                                        @endphp
                                                                        <form method="POST" action="{{ route('tasks.updateStatus', $t->id) }}" class="inline">
                                                                            @csrf
                                                                            @method('PATCH')
                                                                            <input type="hidden" name="status" value="{{ $stBtn['id'] }}">
                                                                            <button type="submit" title="{{ $stBtn['title'] }}"
                                                                                class="w-6 h-6 rounded-md flex items-center justify-center transition p-0.5 {{ $isActive ? 'bg-white dark:bg-slate-700 shadow-xs ring-1 ring-slate-300 dark:ring-slate-600' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-700/60' }}">
                                                                            @if($hasCustomIcon)
                                                                                <img src="{{ asset($stIcon) }}" alt="{{ $stBtn['title'] }}" class="w-3.5 h-3.5 object-contain rounded-xs transition-transform {{ $isActive ? 'scale-110 drop-shadow-xs' : 'opacity-65 hover:opacity-100' }}">
                                                                            @else
                                                                                <i data-lucide="circle" class="w-3.5 h-3.5 {{ $isActive ? 'stroke-[2.5]' : 'stroke-[1.5]' }}" @if($isActive) style="color: {{ $btnColor }}" @endif></i>
                                                                            @endif
                                                                            </button>
                                                                        </form>
                                                                    @endforeach
                                                                </div>
                                                            @endif

                                                            <span class="text-[10px] font-semibold px-2 py-0.5 rounded-md 
                                                                {{ $t->status === 'finalizado' ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300' : ($t->status === 'en_proceso' ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300' : ($t->status === 'en_revision' ? 'bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300' : ($t->status === 'rechazado' ? 'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'))) }}">
                                                                {{ str_replace('_', ' ', ucfirst($t->status)) }}
                                                            </span>
                                                        </div>

                                                        <!-- Acciones: Comentarios, Editar, Desactivar y Eliminar -->
                                                        <div class="flex items-center gap-1 ml-auto shrink-0">
                                                            <button type="button" onclick="openCommentsModal({{ $t->id }}, this.getAttribute('data-title'))" data-title="{{ $t->title }}" class="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1 transition" title="Comentarios">
                                                                <i data-lucide="message-square" class="w-3.5 h-3.5"></i>
                                                                <span id="task-comment-count-{{ $t->id }}" class="text-[11px] font-semibold {{ $t->comments_count > 0 ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400' }}">{{ $t->comments_count }}</span>
                                                            </button>

                                                            @if(!$user->isHelper())
                                                                <button onclick='openTaskModal(@json($t->load(["assignedUsers", "subtasks"])))' class="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition" title="Editar tarea">
                                                                    <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                                                </button>
                                                                <form method="POST" action="{{ route('tasks.destroy', $t->id) }}" onsubmit="return confirmDelete(event, this, { title: '¿Eliminar tarea?', message: 'La tarea se enviará a la papelera. Podrás restaurarla más tarde si lo necesitas.', confirmText: 'Eliminar tarea' });" class="inline">
                                                                    @csrf @method('DELETE')
                                                                    <button type="submit" class="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition" title="Eliminar tarea">
                                                                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                                                    </button>
                                                                </form>
                                                            @endif
                                                        </div>
                                                    </div>

                                                    <!-- Subtasks List inline -->
                                                    @if($t->subtasks->count() > 0)
                                                        <div class="pl-7 pt-1 space-y-1">
                                                            @foreach($t->subtasks as $sub)
                                                                <div class="flex items-center gap-2 text-[11px]">
                                                                    <form method="POST" action="{{ route('subtasks.toggle', $sub->id) }}">
                                                                        @csrf
                                                                        @method('PATCH')
                                                                        <input type="checkbox" onchange="this.form.submit()" {{ $sub->status === 'finalizado' ? 'checked' : '' }}
                                                                            class="w-3.5 h-3.5 rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 accent-indigo-600 cursor-pointer">
                                                                    </form>
                                                                    <span class="{{ $sub->status === 'finalizado' ? 'line-through text-slate-400 dark:text-slate-500' : 'text-slate-600 dark:text-slate-300' }}">
                                                                        {{ $sub->title }}
                                                                    </span>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    @endif
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                @endforeach
                            </div>

                            <div id="cal-list-empty-state" class="{{ ($totalVisibleTasks === 0 && ($selectedUserId || $taskFilterOption || $taskSearch)) ? '' : 'hidden' }} text-center py-12 px-4 space-y-3">
                                <div class="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 flex items-center justify-center mx-auto">
                                    <i data-lucide="filter-x" class="w-6 h-6"></i>
                                </div>
                                <div class="space-y-1">
                                    <p class="text-xs font-semibold text-slate-700 dark:text-slate-300" id="cal-list-empty-msg">
                                        @if($taskSearch && $taskFilterOption)
                                            No se encontraron tareas que coincidan con la búsqueda y el filtro seleccionado.
                                        @elseif($taskSearch)
                                            No se encontraron tareas con el término "{{ $taskSearch }}".
                                        @elseif($taskFilterOption)
                                            No se encontraron tareas con el filtro seleccionado.
                                        @elseif($selectedUserId)
                                            No hay tareas asignadas a este usuario para este período.
                                        @else
                                            No se encontraron tareas para los criterios seleccionados.
                                        @endif
                                    </p>
                                    <p class="text-[11px] text-slate-400 dark:text-slate-500">
                                        Intenta cambiar el filtro seleccionado o limpiar el término de búsqueda.
                                    </p>
                                </div>
                                <button type="button" onclick="resetTaskFilters(true)" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 text-xs font-semibold transition shadow-2xs cursor-pointer">
                                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                                    <span>Restablecer filtros y búsqueda</span>
                                </button>
                            </div>
                            <div id="cal-list-empty-user" class="hidden"></div>
                        @endif
                        </div>
                    </div>
                </div>

            <!-- ========================================================================= -->
            <!-- VIEW 2: KANBAN                                                            -->
            <!-- ========================================================================= -->
            @elseif($activeView === 'kanban')
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 items-start max-w-[1600px] mx-auto pb-6">
                    @php
                        $columns = [
                            ['id' => 'no_iniciado', 'title' => 'No Iniciado', 'border' => 'border-slate-400 dark:border-slate-600', 'badgeBg' => 'bg-slate-200 dark:bg-slate-700', 'badgeText' => 'text-slate-700 dark:text-slate-300', 'icon' => 'circle'],
                            ['id' => 'en_proceso', 'title' => 'En Proceso', 'border' => 'border-amber-500', 'badgeBg' => 'bg-amber-100 dark:bg-amber-950/70', 'badgeText' => 'text-amber-800 dark:text-amber-300', 'icon' => 'clock'],
                            ['id' => 'en_revision', 'title' => 'En Revisión', 'border' => 'border-purple-500', 'badgeBg' => 'bg-purple-100 dark:bg-purple-950/70', 'badgeText' => 'text-purple-800 dark:text-purple-300', 'icon' => 'search'],
                            ['id' => 'rechazado', 'title' => 'Rechazado', 'border' => 'border-red-500', 'badgeBg' => 'bg-red-100 dark:bg-red-950/70', 'badgeText' => 'text-red-800 dark:text-red-300', 'icon' => 'x-circle'],
                            ['id' => 'finalizado', 'title' => 'Finalizado', 'border' => 'border-emerald-500', 'badgeBg' => 'bg-emerald-100 dark:bg-emerald-950/70', 'badgeText' => 'text-emerald-800 dark:text-emerald-300', 'icon' => 'check-circle'],
                        ];
                    @endphp

                    @foreach($columns as $col)
                        @php $colTasks = $filteredTasks->where('status', $col['id']); @endphp
                        <div id="kanban-col-{{ $col['id'] }}" data-kanban-col="{{ $col['id'] }}" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)" ondrop="handleDrop(event, '{{ $col['id'] }}')"
                            class="bg-slate-100/90 dark:bg-slate-900/80 rounded-2xl border-t-4 {{ $col['border'] }} border-x border-b border-slate-200/80 dark:border-slate-800 flex flex-col h-[75vh] sm:h-[78vh] lg:h-[calc(100vh-230px)] max-h-[calc(100vh-230px)] min-h-[460px] transition-all duration-200 shadow-soft kanban-column">
                            
                            <!-- Column Header -->
                            <div class="p-3 sm:p-3.5 border-b border-slate-200/80 dark:border-slate-800 flex items-center justify-between shrink-0 bg-white/70 dark:bg-slate-900/70 rounded-t-xl sticky top-0 z-10 backdrop-blur-xs">
                                <div class="flex items-center space-x-2">
                                    <i data-lucide="{{ $col['icon'] }}" class="w-4 h-4 {{ $col['badgeText'] }}"></i>
                                    <h3 class="font-bold text-xs sm:text-sm text-slate-800 dark:text-slate-200">{{ $col['title'] }}</h3>
                                    <span id="kanban-counter-{{ $col['id'] }}" class="text-[10px] font-bold px-2 py-0.5 rounded-full {{ $col['badgeBg'] }} {{ $col['badgeText'] }}">
                                        {{ $colTasks->count() }}
                                    </span>
                                </div>
                                @if(!$user->isHelper())
                                    <button onclick="openTaskModal(null, '{{ $col['id'] }}')"
                                        class="p-1 rounded-lg text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-white dark:hover:bg-slate-800 transition" title="Agregar tarea en {{ $col['title'] }}">
                                        <i data-lucide="plus" class="w-4 h-4"></i>
                                    </button>
                                @endif
                            </div>

                            <!-- Cards Scrollable Area -->
                            <div id="kanban-cards-{{ $col['id'] }}" class="kanban-cards-container kanban-scrollable p-2 sm:p-2.5 space-y-2.5 overflow-y-auto overscroll-contain flex-1 pr-1.5">
                                @if($colTasks->isEmpty())
                                    <div id="kanban-empty-{{ $col['id'] }}" class="kanban-empty-msg text-center py-8 text-slate-400 dark:text-slate-500 text-xs italic {{ $colTasks->isEmpty() ? '' : 'hidden' }}">
                                        Sin tareas
                                    </div>
                                @else
                                    @foreach($colTasks as $t)
                                        <div id="kanban-card-{{ $t->id }}" data-task-id="{{ $t->id }}" draggable="true" ondragstart="handleDragStart(event, '{{ $t->id }}')"
                                            class="bg-white dark:bg-slate-800/90 rounded-xl border border-slate-200/90 dark:border-slate-700/80 p-3 sm:p-3.5 space-y-2.5 shadow-soft hover:shadow-card dark:hover:shadow-card-dark transition cursor-grab active:cursor-grabbing group">
                                            
                                            <div class="flex items-start justify-between gap-1.5">
                                                <h4 class="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-100 flex-1 leading-snug">
                                                    {{ $t->title }}
                                                    @if($t->isOverdue())
                                                        <span class="text-[9px] bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 font-bold px-1.5 py-0.5 rounded ml-1 uppercase inline-block">Vencida</span>
                                                    @elseif($t->start_date && substr((string)$t->start_date, 0, 10) === $todayBolivia)
                                                        <span class="text-[9px] bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold px-1.5 py-0.5 rounded ml-1 uppercase inline-block">Para Hoy</span>
                                                    @endif
                                                </h4>
                                                <div class="flex items-center space-x-1 shrink-0 task-actions-hover">
                                                    <button type="button" onclick="openCommentsModal({{ $t->id }}, this.getAttribute('data-title'))" data-title="{{ $t->title }}" class="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-0.5" title="Comentarios">
                                                        <i data-lucide="message-square" class="w-3.5 h-3.5"></i>
                                                        <span id="task-comment-count-kanban-{{ $t->id }}" class="text-[10px] font-semibold {{ $t->comments_count > 0 ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400' }}">{{ $t->comments_count }}</span>
                                                    </button>
                                                    @if(!$user->isHelper())
                                                        <button onclick='openTaskModal(@json($t->load(["assignedUsers", "subtasks"])))' class="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded hover:bg-slate-100 dark:hover:bg-slate-700" title="Editar tarea">
                                                            <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                                        </button>
                                                        <form method="POST" action="{{ route('tasks.destroy', $t->id) }}" onsubmit="return confirmDelete(event, this, { title: '¿Eliminar tarea?', message: 'La tarea se enviará a la papelera. Podrás restaurarla más tarde si lo necesitas.', confirmText: 'Eliminar tarea' });" class="inline">
                                                            @csrf @method('DELETE')
                                                            <button type="submit" class="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-slate-100 dark:hover:bg-slate-700" title="Eliminar tarea">
                                                                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                                            </button>
                                                        </form>
                                                    @endif
                                                </div>
                                            </div>

                                            @if($t->description)
                                                <p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{{ $t->description }}</p>
                                            @endif

                                            <!-- Badges: Needs Review, Module, Start Date, End Date -->
                                            @if($t->needs_review || $t->module || $t->start_date || $t->end_date)
                                                <div class="flex flex-wrap items-center gap-1.5">
                                                    @if($t->needs_review)
                                                        <span class="text-[10px] bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-100 dark:border-purple-800/60 px-2 py-0.5 rounded-full font-medium inline-flex items-center space-x-1">
                                                            <i data-lucide="search" class="w-3 h-3"></i>
                                                            <span>Requiere revisión</span>
                                                        </span>
                                                    @endif
                                                    @if($t->module)
                                                        <span class="text-[10px] bg-slate-100 dark:bg-slate-700/80 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-600 px-2 py-0.5 rounded-full font-medium inline-flex items-center space-x-1">
                                                            <i data-lucide="box" class="w-3 h-3 text-indigo-500"></i>
                                                            <span>{{ $t->module->name }}</span>
                                                        </span>
                                                    @endif
                                                    @if($t->start_date)
                                                        <span class="text-[10px] bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-800/60 px-2 py-0.5 rounded-full font-medium inline-flex items-center space-x-1">
                                                            <i data-lucide="calendar" class="w-3 h-3"></i>
                                                            <span>{{ \Carbon\Carbon::parse($t->start_date)->format('d/m/Y') }}{{ $t->start_time ? ' '.substr($t->start_time, 0, 5) : '' }}</span>
                                                        </span>
                                                    @endif
                                                    @if($t->recurrence && $t->recurrence !== 'ninguna')
                                                        <span class="text-[10px] bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800/60 px-2 py-0.5 rounded-full font-medium inline-flex items-center space-x-1">
                                                            <i data-lucide="repeat" class="w-3 h-3 text-indigo-500"></i>
                                                            <span>{{ ucfirst($t->recurrence) }}</span>
                                                        </span>
                                                    @endif
                                                    @if($t->end_date)
                                                        <span class="text-[10px] bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-100 dark:border-purple-800/60 px-2 py-0.5 rounded-full font-medium inline-flex items-center space-x-1">
                                                            <i data-lucide="flag" class="w-3 h-3"></i>
                                                            <span>{{ \Carbon\Carbon::parse($t->end_date)->format('d/m/Y') }}{{ $t->end_time ? ' '.substr($t->end_time, 0, 5) : '' }}</span>
                                                        </span>
                                                    @endif
                                                    @if($t->isOverdue())
                                                        @php
                                                            $dueOverdueStr = null;
                                                            if ($t->end_date) {
                                                                $dueOverdueStr = \Carbon\Carbon::parse($t->end_date)->format('d/m/Y') . ($t->end_time ? ' '.$t->end_time : '');
                                                            } elseif ($t->start_date) {
                                                                $dueOverdueStr = \Carbon\Carbon::parse($t->start_date)->format('d/m/Y') . ($t->start_time ? ' '.$t->start_time : '');
                                                            }
                                                        @endphp
                                                        @if($dueOverdueStr)
                                                            <span class="text-[10px] bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-100 dark:border-red-900/60 px-2 py-0.5 rounded-full font-medium inline-flex items-center space-x-1">
                                                                <i data-lucide="alert-triangle" class="w-3 h-3 text-red-600"></i>
                                                                <span>Debía: {{ $dueOverdueStr }}</span>
                                                            </span>
                                                        @endif
                                                    @endif
                                                    @if($t->status === 'finalizado' && $t->completed_at)
                                                        <span class="text-[10px] bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-800/60 px-2 py-0.5 rounded-full font-medium inline-flex items-center space-x-1">
                                                            <i data-lucide="check-circle" class="w-3 h-3 text-emerald-600"></i>
                                                            <span>Fin: {{ $t->completed_at->copy()->timezone('America/La_Paz')->format('d/m/Y H:i') }}</span>
                                                        </span>
                                                    @endif
                                                </div>
                                            @endif

                                            <!-- Review Actions -->
                                            @if($t->status === 'en_revision' && $user->hasFullAccess())
                                                <div class="flex items-center gap-1.5 pt-1">
                                                    <form method="POST" action="{{ route('tasks.updateStatus', $t->id) }}" class="flex-1">
                                                        @csrf @method('PATCH')
                                                        <input type="hidden" name="status" value="finalizado">
                                                        <button type="submit" class="w-full py-1 text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-lg transition flex items-center justify-center space-x-1">
                                                            <i data-lucide="check" class="w-3 h-3"></i>
                                                            <span>Aprobar</span>
                                                        </button>
                                                    </form>
                                                    <form method="POST" action="{{ route('tasks.updateStatus', $t->id) }}" class="flex-1">
                                                        @csrf @method('PATCH')
                                                        <input type="hidden" name="status" value="rechazado">
                                                        <button type="submit" class="w-full py-1 text-[11px] font-semibold bg-red-50 dark:bg-red-950/60 hover:bg-red-100 dark:hover:bg-red-900/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 rounded-lg transition flex items-center justify-center space-x-1">
                                                            <i data-lucide="x" class="w-3 h-3"></i>
                                                            <span>Rechazar</span>
                                                        </button>
                                                    </form>
                                                </div>
                                            @endif

                                            <!-- Subtasks Progress Bar -->
                                            @if($t->subtasks->count() > 0)
                                                @php
                                                    $stTotal = $t->subtasks->count();
                                                    $stDone = $t->subtasks->where('status', 'finalizado')->count();
                                                    $stPct = round(($stDone / $stTotal) * 100);
                                                @endphp
                                                <div class="space-y-1 pt-1">
                                                    <div class="flex items-center justify-between text-[10px] text-slate-400">
                                                        <span class="flex items-center gap-1">
                                                            <i data-lucide="list-todo" class="w-3 h-3 text-indigo-400"></i>
                                                            Subtareas {{ $stDone }}/{{ $stTotal }}
                                                        </span>
                                                        <span>{{ $stPct }}%</span>
                                                    </div>
                                                    <div class="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 overflow-hidden">
                                                        <div class="bg-indigo-500 h-1.5 rounded-full transition-all" style="width: {{ $stPct }}%"></div>
                                                    </div>
                                                </div>
                                            @endif

                                            <!-- Card Footer: Priority Badge + Member Avatars + Quick Status Select -->
                                            <div class="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between flex-wrap gap-2">
                                                <span class="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md shrink-0
                                                    {{ $t->priority === 'alta' ? 'bg-red-50 dark:bg-red-950/50 text-red-600 dark:text-red-400 border border-red-200/50 dark:border-red-900/40' : ($t->priority === 'media' ? 'bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 border border-amber-200/50 dark:border-amber-900/40' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-600') }}">
                                                    {{ $t->priority }}
                                                </span>

                                                <div class="flex items-center gap-2 flex-wrap">
                                                    <div class="flex items-center -space-x-1.5 shrink-0">
                                                        @foreach($t->assignedUsers as $u)
                                                            <span class="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 font-bold text-[8px] flex items-center justify-center border border-white dark:border-slate-800" title="{{ $u->name }}">
                                                                {{ $u->initials }}
                                                            </span>
                                                        @endforeach
                                                    </div>

                                                    <form method="POST" action="{{ route('tasks.updateStatus', $t->id) }}" class="inline">
                                                        @csrf @method('PATCH')
                                                        <select name="status" onchange="this.form.submit()" class="text-[11px] bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-700 dark:text-slate-200 py-0.5 px-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                                                            <option value="no_iniciado" {{ $t->status === 'no_iniciado' ? 'selected' : '' }}>No Iniciado</option>
                                                            <option value="en_proceso" {{ $t->status === 'en_proceso' ? 'selected' : '' }}>En Proceso</option>
                                                            @if($t->needs_review)
                                                                <option value="en_revision" {{ $t->status === 'en_revision' ? 'selected' : '' }}>En Revisión</option>
                                                            @endif
                                                            @if(!$t->needs_review || $user->hasFullAccess())
                                                                <option value="rechazado" {{ $t->status === 'rechazado' ? 'selected' : '' }}>Rechazado</option>
                                                                <option value="finalizado" {{ $t->status === 'finalizado' ? 'selected' : '' }}>Finalizado</option>
                                                            @endif
                                                        </select>
                                                    </form>
                                                </div>
                                            </div>

                                        </div>
                                    @endforeach
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>

            <!-- ========================================================================= -->
            <!-- VIEW 3: INCIDENCIAS                                                       -->
            <!-- ========================================================================= -->
            @elseif($activeView === 'incidencias')
                <div class="space-y-6 max-w-[1600px] mx-auto">


                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
                        @php
                            $incCols = [
                                ['id' => 'abierta', 'title' => 'Abiertas', 'border' => 'border-red-500', 'badge' => 'bg-red-100 dark:bg-red-950/70 text-red-700 dark:text-red-300'],
                                ['id' => 'en_proceso', 'title' => 'En Proceso', 'border' => 'border-amber-500', 'badge' => 'bg-amber-100 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300'],
                                ['id' => 'resuelta', 'title' => 'Resueltas', 'border' => 'border-emerald-500', 'badge' => 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300'],
                            ];
                        @endphp

                        @foreach($incCols as $icol)
                            @php $incItems = $incidents->where('estado', $icol['id']); @endphp
                            <div id="inc-col-{{ $icol['id'] }}" data-incident-col="{{ $icol['id'] }}" class="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 border-t-4 {{ $icol['border'] }} shadow-soft space-y-3.5">
                                <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                                    <h4 class="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">{{ $icol['title'] }}</h4>
                                    <span class="text-xs font-bold px-2 py-0.5 rounded-full {{ $icol['badge'] }}">{{ $incItems->count() }}</span>
                                </div>

                                <div class="space-y-3">
                                    @if($incItems->isEmpty())
                                        <p class="text-center py-6 text-slate-400 dark:text-slate-500 text-xs italic">Sin incidencias en esta columna</p>
                                    @else
                                        @foreach($incItems as $inc)
                                            <div id="inc-card-{{ $inc->id }}" onclick='openIncidentModal(@json($inc))' class="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-2.5 group shadow-2xs hover:shadow-xs transition cursor-pointer hover:border-indigo-300 dark:hover:border-indigo-700">
                                                <div class="flex items-start justify-between gap-2">
                                                    <div class="flex-1 min-w-0">
                                                        <h5 class="text-xs sm:text-sm font-bold text-slate-900 dark:text-white break-words leading-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition">{{ $inc->titulo }}</h5>
                                                        <div class="flex items-center gap-1.5 mt-1 flex-wrap">
                                                            <span class="text-[9px] font-semibold px-1.5 py-0.5 rounded {{ $inc->project ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60' : 'bg-slate-200/70 dark:bg-slate-700 text-slate-700 dark:text-slate-300' }}">
                                                                {{ $inc->project ? $inc->project->name : 'General (Sin proyecto)' }}
                                                            </span>
                                                            @if($inc->assignedUser)
                                                                <span class="text-[9px] font-medium px-1.5 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800/60 inline-flex items-center gap-1">
                                                                    <i data-lucide="user" class="w-2.5 h-2.5"></i>
                                                                    <span>{{ $inc->assignedUser->name }}</span>
                                                                </span>
                                                            @endif
                                                        </div>
                                                    </div>
                                                    <div class="flex items-center gap-1 shrink-0">
                                                        <span class="text-[9px] font-bold px-1.5 py-0.5 rounded uppercase
                                                            {{ $inc->prioridad === 'urgente' ? 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300' }}">
                                                            {{ $inc->prioridad }}
                                                        </span>
                                                        @if($user->hasFullAccess() || Auth::id() === $inc->user_id)
                                                            <button type="button" onclick='event.stopPropagation(); openIncidentModal(@json($inc))' class="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded transition" title="Editar / Ver incidencia">
                                                                <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                                            </button>
                                                            <button type="button" onclick="event.stopPropagation(); deleteIncident({{ $inc->id }})" class="p-1 text-slate-400 hover:text-red-600 rounded transition" title="Eliminar incidencia">
                                                                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                                            </button>
                                                        @endif
                                                    </div>
                                                </div>
                                                @if($inc->descripcion)
                                                    <p class="text-xs text-slate-500 dark:text-slate-400 break-words line-clamp-3">{{ $inc->descripcion }}</p>
                                                @endif
                                                <div class="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between flex-wrap gap-2 text-[10px] text-slate-400">
                                                    <span class="truncate max-w-[180px]">Reportado: <strong>{{ $inc->reporter ? $inc->reporter->name : 'Anónimo' }}</strong></span>
                                                    <div class="flex items-center gap-1.5">
                                                        <label class="text-[10px] text-slate-400">Estado:</label>
                                                        <select name="estado" onclick="event.stopPropagation()" onchange="changeIncidentStatus({{ $inc->id }}, this.value, this)" class="text-[10px] font-semibold bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded px-1.5 py-0.5 text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-1 focus:ring-indigo-500">
                                                            <option value="abierta" {{ $inc->estado === 'abierta' ? 'selected' : '' }}>Abierta</option>
                                                            <option value="en_proceso" {{ $inc->estado === 'en_proceso' ? 'selected' : '' }}>En Proceso</option>
                                                            <option value="resuelta" {{ $inc->estado === 'resuelta' ? 'selected' : '' }}>Resuelta</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>

            <!-- ========================================================================= -->
            <!-- VIEW 4: ENLACES DE PROYECTO                                               -->
            <!-- ========================================================================= -->
            @elseif($activeView === 'enlaces')
                <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-6 shadow-soft space-y-4 max-w-[1600px] mx-auto">


                    @php
                        $visibleLinks = $user->isHelper()
                            ? $activeProject->links->filter(fn($l) => $l->assignedUsers->contains('id', $user->id))
                            : $activeProject->links;
                    @endphp

                    @if($visibleLinks->isEmpty())
                        <div class="text-center py-12 text-slate-400 dark:text-slate-500 text-xs">
                            {{ $user->isHelper() ? 'No tienes enlaces asignados en este proyecto todavía.' : 'No hay enlaces configurados para este proyecto.' }}
                        </div>
                    @else
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            @foreach($visibleLinks as $link)
                                <div class="p-4 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 hover:bg-white dark:hover:bg-slate-800 transition flex flex-col justify-between gap-3 shadow-xs">
                                    <div>
                                        <div class="flex items-start justify-between gap-2">
                                            <h4 class="text-xs sm:text-sm font-bold text-slate-900 dark:text-white flex items-start gap-1.5 leading-snug min-w-0 flex-1">
                                                <i data-lucide="external-link" class="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5"></i>
                                                <span class="break-words">{{ $link->name }}</span>
                                            </h4>
                                            @if($user->hasFullAccess())
                                                <button onclick='openProjectModal(@json($activeProject->load("links.assignedUsers")))' title="Editar enlace" class="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-200/60 dark:hover:bg-slate-700 rounded-lg transition shrink-0">
                                                    <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                                </button>
                                            @endif
                                        </div>
                                        <a href="{{ $link->url }}" target="_blank" class="text-xs text-indigo-600 dark:text-indigo-400 hover:underline break-all block mt-2">
                                            {{ $link->url }}
                                        </a>
                                    </div>
                                    <div class="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between flex-wrap gap-2 text-[10px] text-slate-400">
                                        <span>Miembros asignados:</span>
                                        <div class="flex items-center gap-1 flex-wrap">
                                            @foreach($link->assignedUsers as $u)
                                                <span class="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 font-bold text-[9px] flex items-center justify-center border border-white dark:border-slate-800" title="{{ $u->name }}">
                                                    {{ $u->initials }}
                                                </span>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>

            <!-- ========================================================================= -->
            <!-- VIEW 5: TAREAS PERIÓDICAS                                                 -->
            <!-- ========================================================================= -->
            @elseif($activeView === 'periodicas')
                <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-6 shadow-soft space-y-4 max-w-[1600px] mx-auto">


                    @if($recurringTasks->isEmpty())
                        <div class="text-center py-12 text-slate-400 dark:text-slate-500 text-xs">
                            No hay tareas periódicas configuradas en este proyecto o módulo.
                        </div>
                    @else
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            @foreach($recurringTasks as $rule)
                                <div class="p-4 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 hover:bg-white dark:hover:bg-slate-800 transition flex flex-col justify-between gap-3 shadow-xs">
                                    <div class="space-y-2">
                                        <div class="flex items-start justify-between gap-2">
                                            <h4 class="text-xs sm:text-sm font-bold text-slate-900 dark:text-white leading-snug flex-1">{{ $rule->title }}</h4>
                                            <span class="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase shrink-0 bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                                                {{ $rule->recurrence }}
                                            </span>
                                        </div>

                                        @if($rule->description)
                                            <p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{{ $rule->description }}</p>
                                        @endif

                                        <div class="flex flex-wrap items-center gap-1.5 pt-1">
                                            <span class="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md
                                                {{ $rule->priority === 'alta' ? 'bg-red-50 dark:bg-red-950/50 text-red-600 dark:text-red-400' : ($rule->priority === 'media' ? 'bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300') }}">
                                                {{ $rule->priority }}
                                            </span>

                                            @if($rule->module)
                                                <span class="text-[10px] bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-md">
                                                    {{ $rule->module->name }}
                                                </span>
                                            @endif

                                            @if($rule->needs_review)
                                                <span class="text-[10px] bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded-md">
                                                    Revisión requerida
                                                </span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="pt-3 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between gap-2">
                                        <div class="flex items-center gap-1.5">
                                            <form method="POST" action="{{ route('recurring-tasks.toggleActive', $rule->id) }}">
                                                @csrf @method('PATCH')
                                                <button type="submit" class="text-[10px] font-bold px-2 py-0.5 rounded-full transition {{ $rule->is_active ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400' }}">
                                                    {{ $rule->is_active ? 'Activa' : 'Pausada' }}
                                                </button>
                                            </form>
                                        </div>

                                        @if(!$user->isHelper())
                                            <div class="flex items-center gap-1">
                                                <button onclick='openRecurringTaskModal(@json($rule->load(["assignedUsers", "subtasks"])))' class="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Editar regla">
                                                    <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                                </button>
                                                <form method="POST" action="{{ route('recurring-tasks.destroy', $rule->id) }}" onsubmit="return confirmDelete(event, this, { title: '¿Eliminar regla periódica?', message: 'Esta regla ya no generará tareas automáticas programadas en el calendario. Las tareas creadas anteriormente se conservarán.', confirmText: 'Eliminar regla' });" class="inline">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition" title="Eliminar regla">
                                                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>

            <!-- VIEW 6: PAPELERA DE TAREAS ELIMINADAS (30 DÍAS DE RETENCIÓN) -->
            @elseif($activeView === 'papelera')
                <div class="space-y-4 max-w-[1600px] mx-auto">
                    <!-- Cabecera de la Papelera con Información de Retención y Filtros -->
                    <div class="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-soft flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div class="space-y-1">
                            <div class="flex items-center gap-2">
                                <span class="p-2 rounded-xl bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400 shrink-0">
                                    <i data-lucide="trash-2" class="w-5 h-5"></i>
                                </span>
                                <div>
                                    <h2 class="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                                        <span>Papelera de Tareas</span>
                                        <span class="text-xs font-semibold px-2 py-0.5 rounded-full bg-red-100 dark:bg-red-950/70 text-red-700 dark:text-red-300">
                                            {{ $trashedTasks->count() }}
                                        </span>
                                    </h2>
                                </div>
                            </div>
                        </div>

                        <div class="flex items-center gap-2 flex-wrap">
                            @if(!$user->isHelper() && $allTrashCount > 0)
                                <form method="POST" action="{{ route('tasks.emptyTrash') }}" onsubmit="return confirmDelete(event, this, { title: '¿Vaciar toda la papelera?', message: 'Todas las tareas que se encuentran en la papelera serán eliminadas de forma definitiva.', confirmText: 'Vaciar papelera', isPermanent: true, permanentText: 'Advertencia: Esta acción es permanente e irreversible. No se podrán recuperar las tareas eliminadas.' });" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    @if($activeProject)
                                        <input type="hidden" name="project_id" value="{{ $activeProject->id }}">
                                    @endif
                                    <button type="submit" class="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-xs transition cursor-pointer">
                                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                        <span>Vaciar papelera</span>
                                    </button>
                                </form>
                            @endif

                            <!-- Filtros de Tiempo: Todas, Día, Semana, Mes -->
                            <div class="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl overflow-x-auto no-scrollbar shrink-0 text-xs">
                                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'papelera', 'trash_filter' => 'todas']) }}"
                                    class="px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap {{ $trashFilter === 'todas' ? 'bg-white dark:bg-slate-900 text-red-600 dark:text-red-400 shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                                    <i data-lucide="layers" class="w-3.5 h-3.5"></i>
                                    <span>Todas</span>
                                    <span class="px-1.5 py-0.2 text-[10px] rounded-full {{ $trashFilter === 'todas' ? 'bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 font-bold' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300' }}">{{ $allTrashCount }}</span>
                                </a>
                                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'papelera', 'trash_filter' => 'dia']) }}"
                                    class="px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap {{ $trashFilter === 'dia' ? 'bg-white dark:bg-slate-900 text-red-600 dark:text-red-400 shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                                    <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                                    <span>Día</span>
                                </a>
                                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'papelera', 'trash_filter' => 'semana']) }}"
                                    class="px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap {{ $trashFilter === 'semana' ? 'bg-white dark:bg-slate-900 text-red-600 dark:text-red-400 shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                                    <i data-lucide="calendar-days" class="w-3.5 h-3.5"></i>
                                    <span>Semana</span>
                                </a>
                                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'papelera', 'trash_filter' => 'mes']) }}"
                                    class="px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap {{ $trashFilter === 'mes' ? 'bg-white dark:bg-slate-900 text-red-600 dark:text-red-400 shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                                    <i data-lucide="calendar-range" class="w-3.5 h-3.5"></i>
                                    <span>Mes</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Lista de Tareas en Papelera -->
                    @if($trashedTasks->isEmpty())
                        <div class="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-soft">
                            <div class="w-14 h-14 mx-auto rounded-2xl bg-red-50 dark:bg-red-950/50 text-red-500 dark:text-red-400 flex items-center justify-center mb-3">
                                <i data-lucide="trash-2" class="w-7 h-7"></i>
                            </div>
                            <h3 class="font-bold text-sm text-slate-800 dark:text-slate-200">La papelera está vacía</h3>
                            <p class="text-xs text-slate-400 dark:text-slate-500 mt-1 max-w-sm mx-auto">
                                No hay tareas eliminadas en el período seleccionado. Las tareas eliminadas se conservarán durante 30 días antes de ser purgadas definitivamente.
                            </p>
                        </div>
                    @else
                        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4">
                            @foreach($trashedTasks as $t)
                                @php
                                    $deletedDate = $t->deleted_at ? $t->deleted_at->copy()->timezone('America/La_Paz')->startOfDay() : \Carbon\Carbon::today('America/La_Paz');
                                    $todayBolivia = \Carbon\Carbon::today('America/La_Paz');
                                    $daysElapsed = $deletedDate->greaterThan($todayBolivia) ? 0 : (int) $deletedDate->diffInDays($todayBolivia);
                                    $daysRemaining = max(0, 30 - $daysElapsed);
                                @endphp
                                <div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-soft flex flex-col justify-between gap-3 relative transition hover:shadow-card dark:hover:shadow-card-dark">
                                    <div class="space-y-2">
                                        <!-- Top Row: Proyecto + Estado anterior + Días restantes -->
                                        <div class="flex items-center justify-between gap-2 flex-wrap">
                                            <div class="flex items-center gap-1.5 flex-wrap">
                                                @if($t->project)
                                                    <span class="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300">
                                                        {{ $t->project->name }}
                                                    </span>
                                                @endif
                                                @if($t->module)
                                                    <span class="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                                                        {{ $t->module->name }}
                                                    </span>
                                                @endif
                                            </div>

                                            <span class="text-[10px] font-bold px-2 py-0.5 rounded-full {{ $daysRemaining <= 5 ? 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 animate-pulse' : 'bg-amber-50 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300' }}" title="Días restantes antes de eliminación definitiva">
                                                {{ $daysRemaining }} {{ $daysRemaining === 1 ? 'día restante' : 'días restantes' }}
                                            </span>
                                        </div>

                                        <!-- Título de la tarea -->
                                        <h3 class="font-bold text-sm text-slate-800 dark:text-slate-100 line-clamp-2" title="{{ $t->title }}">
                                            {{ $t->title }}
                                        </h3>

                                        @if($t->description)
                                            <p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                                                {{ $t->description }}
                                            </p>
                                        @endif

                                        <!-- Información adicional: Estado original, prioridad, fecha de eliminación -->
                                        <div class="pt-2 flex flex-wrap items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 border-t border-slate-100 dark:border-slate-800/80">
                                            <!-- Badge de estado anterior -->
                                            <span class="px-2 py-0.5 rounded-md text-[10px] font-semibold
                                                @if($t->status === 'finalizado') bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300
                                                @elseif($t->status === 'en_proceso') bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300
                                                @elseif($t->status === 'en_revision') bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300
                                                @elseif($t->status === 'rechazado') bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300
                                                @else bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400
                                                @endif">
                                                Estado: {{ ucfirst(str_replace('_', ' ', $t->status)) }}
                                            </span>

                                            <!-- Prioridad -->
                                            <span class="px-2 py-0.5 rounded-md text-[10px] font-semibold
                                                @if($t->priority === 'alta') bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300
                                                @elseif($t->priority === 'media') bg-yellow-50 dark:bg-yellow-950/60 text-yellow-700 dark:text-yellow-300
                                                @else bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400
                                                @endif">
                                                {{ ucfirst($t->priority) }}
                                            </span>

                                            <!-- Fecha de eliminación -->
                                            <div class="flex items-center gap-1 text-[10px] text-slate-400 dark:text-slate-500 ml-auto">
                                                <i data-lucide="clock" class="w-3 h-3"></i>
                                                <span>Eliminada {{ $t->deleted_at->diffForHumans() }}</span>
                                            </div>
                                        </div>

                                        <!-- Asignados -->
                                        @if($t->assignedUsers->isNotEmpty())
                                            <div class="flex items-center gap-1.5 pt-1 text-[11px] text-slate-500 dark:text-slate-400">
                                                <span class="text-[10px] font-medium text-slate-400">Asignada a:</span>
                                                <div class="flex items-center -space-x-1.5 overflow-hidden">
                                                    @foreach($t->assignedUsers as $au)
                                                        <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-[9px] font-bold ring-1 ring-white dark:ring-slate-900" title="{{ $au->name }}">
                                                            {{ strtoupper(substr($au->name, 0, 2)) }}
                                                        </span>
                                                    @endforeach
                                                </div>
                                            </div>
                                        @endif
                                    </div>

                                    <!-- Acciones: Restablecer / Eliminar Definitivamente -->
                                    <div class="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2">
                                        <form method="POST" action="{{ route('tasks.restore', $t->id) }}" class="inline-block">
                                            @csrf
                                            @method('PATCH')
                                            <button type="submit" class="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs flex items-center gap-1.5 transition shadow-xs active:scale-95">
                                                <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                                                <span>Restablecer</span>
                                            </button>
                                        </form>

                                        @if($user->hasFullAccess())
                                            <form method="POST" action="{{ route('tasks.forceDestroy', $t->id) }}" onsubmit="return confirmDelete(event, this, { title: '¿Eliminar definitivamente?', message: 'Esta acción es definitiva y no se puede deshacer. La tarea será eliminada permanentemente del sistema.', confirmText: 'Eliminar definitivamente', isPermanent: true, permanentText: 'Advertencia: La tarea no se podrá recuperar de ninguna manera.' });" class="inline-block">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/40 transition" title="Eliminar">
                                                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                                                </button>
                                            </form>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>

            <!-- ========================================================================= -->
            <!-- VIEW: CHECKLIST (MATRIZ MENSUAL CON CHECKS)                               -->
            <!-- ========================================================================= -->
            @elseif($activeView === 'checklist' || $activeView === 'lista_tareas')
                <div class="space-y-4 sm:space-y-6 max-w-[1700px] mx-auto">
                    <!-- Top Bar: Mes / Navegación y Filtros -->
                    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-soft flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div class="flex items-center space-x-3 sm:space-x-4 flex-wrap gap-y-2">
                            <!-- Navegación Mes Anterior -->
                            <a href="{{ route('dashboard', array_merge(request()->query(), ['view' => 'checklist', 'month' => $matrixData['prevMonth']])) }}"
                                class="p-2 sm:p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition shadow-2xs"
                                title="Mes anterior ({{ $matrixData['prevMonth'] }})">
                                <i data-lucide="chevron-left" class="w-4 h-4"></i>
                            </a>

                            <!-- Indicador de Mes y Año -->
                            <div class="flex items-center space-x-2">
                                <div class="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-800/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 shadow-xs">
                                    <i data-lucide="calendar" class="w-5 h-5"></i>
                                </div>
                                <div>
                                    <h2 class="text-base sm:text-lg font-black text-slate-900 dark:text-white capitalize tracking-tight leading-tight">
                                        {{ $matrixData['monthLabel'] }}
                                    </h2>
                                   
                                </div>
                            </div>

                            <!-- Navegación Mes Siguiente -->
                            <a href="{{ route('dashboard', array_merge(request()->query(), ['view' => 'checklist', 'month' => $matrixData['nextMonth']])) }}"
                                class="p-2 sm:p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition shadow-2xs"
                                title="Mes siguiente ({{ $matrixData['nextMonth'] }})">
                                <i data-lucide="chevron-right" class="w-4 h-4"></i>
                            </a>

                            <!-- Botón Mes Actual / Hoy -->
                            @if(!$matrixData['isCurrentMonth'])
                                <a href="{{ route('dashboard', array_merge(request()->query(), ['view' => 'checklist', 'month' => $matrixData['currentMonth']])) }}"
                                    class="px-3 py-1.5 text-xs font-semibold rounded-xl bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200/80 dark:border-indigo-800/80 transition shadow-2xs">
                                    Ir al mes actual
                                </a>
                            @endif
                        </div>

                        <!-- Filtro por Usuario y Buscador -->
                        <div class="flex items-center space-x-2.5 flex-wrap sm:flex-nowrap gap-y-2">
                            <!-- Buscador en tiempo real de filas -->
                            <div class="relative flex-1 sm:w-56">
                                <i data-lucide="search" class="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
                                <input type="text" id="matrixTaskSearch" oninput="filterMatrixRows()" placeholder="Buscar tarea..."
                                    class="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition">
                            </div>

                            <!-- Filtro por Usuario (Para Admin / Asignados) -->
                            @if($projectUsers->count() > 0 && !$user->isHelper())
                                <div class="relative shrink-0">
                                    <select onchange="window.location.href=this.value"
                                        class="text-xs py-1.5 pl-2.5 pr-8 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium">
                                        <option value="{{ route('dashboard', array_merge(request()->query(), ['view' => 'checklist', 'month' => $matrixData['month'], 'user_id' => ''])) }}">
                                            Todos los usuarios
                                        </option>
                                        @foreach($projectUsers as $pUser)
                                            <option value="{{ route('dashboard', array_merge(request()->query(), ['view' => 'checklist', 'month' => $matrixData['month'], 'user_id' => $pUser->id])) }}"
                                                {{ (string)$selectedUserId === (string)$pUser->id ? 'selected' : '' }}>
                                                {{ $pUser->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif
                        </div>
                    </div>

                    <!-- KPI Cards Resumen Mes -->
                   <!-- <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-3.5 shadow-2xs">
                            <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">Tareas en seguimiento</span>
                            <div class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">{{ $matrixData['totalTasks'] }}</div>
                        </div>

                        <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-3.5 shadow-2xs">
                            <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">Checks programados</span>
                            <div class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1" id="matrix-global-scheduled">{{ $matrixData['totalScheduled'] }}</div>
                        </div>

                        <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-3.5 shadow-2xs">
                            <span class="text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">Completados</span>
                            <div class="text-xl sm:text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1" id="matrix-global-completed">{{ $matrixData['totalCompleted'] }}</div>
                        </div>

                        <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-3.5 shadow-2xs">
                            <div class="flex items-center justify-between">
                                <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">Cumplimiento</span>
                                <span class="text-xs font-black text-indigo-600 dark:text-indigo-400" id="matrix-global-percent">{{ $matrixData['overallProgress'] }}%</span>
                            </div>
                            <div class="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full mt-2 overflow-hidden">
                                <div id="matrix-global-bar" class="bg-gradient-to-r from-indigo-500 to-emerald-500 h-full rounded-full transition-all duration-300" style="width: {{ $matrixData['overallProgress'] }}%"></div>
                            </div>
                        </div>
                    </div>-->

                    <!-- Tabla / Matriz con Columnas Semanales y Checks por Día -->
                    <div class="relative overflow-x-auto overflow-y-auto max-h-[520px] sm:max-h-[620px] lg:max-h-[calc(100vh-290px)] min-h-[280px] rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-soft" style="touch-action: pan-x pan-y; -webkit-overflow-scrolling: touch;">
                        <table class="w-full border-collapse text-left select-none">
                            <thead class="sticky top-0 z-30 bg-white dark:bg-slate-900 shadow-xs">
                                <!-- Fila 1: Títulos de Semana (Semana 1, Semana 2...) -->
                                <tr class="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-xs">
                                    <th class="sticky left-0 z-40 bg-slate-50 dark:bg-slate-900 p-2.5 sm:p-3 min-w-[160px] sm:min-w-[260px] max-w-[190px] sm:max-w-[320px] border-r border-slate-200 dark:border-slate-800 shadow-[2px_0_5px_rgba(0,0,0,0.03)] font-bold text-slate-700 dark:text-slate-200">
                                        Lista de Tareas
                                    </th>
                                    @foreach($matrixData['weeks'] as $wIdx => $week)
                                        <th colspan="{{ $week['daysCount'] }}"
                                            class="text-center py-2 px-1 text-[11px] font-black uppercase tracking-wider {{ $week['textColor'] }} {{ $week['bgHeader'] }} border-r border-slate-200/80 dark:border-slate-800">
                                            {{ $week['name'] }}
                                        </th>
                                    @endforeach
                                </tr>

                                <!-- Fila 2: Abreviatura del Día y Número de Fecha -->
                                <tr class="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-[11px]">
                                    <th class="sticky left-0 z-40 bg-white dark:bg-slate-900 p-2 min-w-[160px] sm:min-w-[260px] max-w-[190px] sm:max-w-[320px] border-r border-slate-200 dark:border-slate-800 shadow-[2px_0_5px_rgba(0,0,0,0.03)] text-[10px] text-slate-400 dark:text-slate-500 font-medium">
                                        Frecuencia y Nombre
                                    </th>
                                    @foreach($matrixData['days'] as $d => $dayInfo)
                                        @php
                                            $wTheme = $matrixData['weeks'][$dayInfo['weekIndex']];
                                            $isMatrixDayToday = ($dayInfo['date'] === $todayBolivia);
                                            $isMatrixDayFuture = ($dayInfo['date'] > $todayBolivia);
                                        @endphp
                                        <th class="p-1 sm:p-1.5 min-w-[42px] sm:min-w-[46px] text-center border-r border-slate-100 dark:border-slate-800/80 transition-colors
                                            @if($isMatrixDayToday)
                                                {{ $wTheme['todayHeaderBg'] }} {{ $wTheme['todayBorder'] }}
                                            @elseif($isMatrixDayFuture)
                                                bg-slate-100/60 dark:bg-slate-800/40 text-slate-400 dark:text-slate-500
                                            @else
                                                bg-white dark:bg-slate-900
                                            @endif">
                                            <div class="flex flex-col items-center justify-center py-1">
                                                <span class="text-[10px] leading-tight lowercase
                                                    @if($isMatrixDayToday)
                                                        {{ $wTheme['todayText'] }}
                                                    @elseif($isMatrixDayFuture)
                                                        text-slate-400 dark:text-slate-500 font-medium
                                                    @elseif($dayInfo['isWeekend'])
                                                        text-slate-400 dark:text-slate-500 font-semibold
                                                    @else
                                                        text-slate-600 dark:text-slate-300 font-semibold
                                                    @endif">
                                                    {{ $dayInfo['dayName'] }}
                                                </span>
                                                <span class="text-xs leading-tight mt-0.5
                                                    @if($isMatrixDayToday)
                                                        w-5 h-5 rounded-full {{ $wTheme['todayBadge'] }} flex items-center justify-center shadow-xs font-black
                                                    @elseif($isMatrixDayFuture)
                                                        text-slate-400 dark:text-slate-500 font-semibold
                                                    @else
                                                        text-slate-800 dark:text-slate-200 font-bold
                                                    @endif">
                                                    {{ $dayInfo['day'] }}
                                                </span>
                                            </div>
                                        </th>
                                    @endforeach
                                </tr>
                            </thead>

                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800/80 text-xs">
                                @forelse($matrixData['rows'] as $row)
                                    <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors group matrix-task-row"
                                        id="matrix-row-{{ $row['id'] }}"
                                        data-task-title="{{ $row['title'] }}">
                                        
                                        <!-- Columna Fija Izquierda: Título y Datos de la Tarea -->
                                        <td class="sticky left-0 z-20 bg-white dark:bg-slate-900 group-hover:bg-slate-50/90 dark:group-hover:bg-slate-800/90 p-2 sm:p-2.5 min-w-[160px] sm:min-w-[260px] max-w-[190px] sm:max-w-[320px] border-r border-slate-200 dark:border-slate-800 shadow-[2px_0_5px_rgba(0,0,0,0.03)] transition-colors">
                                            <div class="flex items-center space-x-2.5 min-w-0">
                                                <div class="w-7 h-7 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center shrink-0 shadow-2xs
                                                    {{ $row['type'] === 'periodica' ? 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300' }}">
                                                    <i data-lucide="{{ $row['type'] === 'periodica' ? 'repeat' : 'check-circle-2' }}" class="w-3.5 h-3.5 sm:w-4 sm:h-4"></i>
                                                </div>
                                                <div class="min-w-0 flex-1">
                                                    <span class="text-xs sm:text-[13px] font-bold text-slate-800 dark:text-slate-100 line-clamp-2 break-words leading-tight block" title="{{ $row['title'] }}">
                                                        {{ $row['title'] }}
                                                    </span>
                                                    <div class="flex items-center space-x-1.5 text-[10px] text-slate-400 dark:text-slate-500 mt-0.5 flex-wrap">
                                                        @if($row['type'] === 'periodica')
                                                            <span class="px-1.5 py-0.2 rounded font-semibold capitalize bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
                                                                {{ $row['recurrence'] }}
                                                            </span>
                                                        @else
                                                            <span class="px-1.5 py-0.2 rounded font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                                                                Espontánea
                                                            </span>
                                                        @endif
                                                        @if($row['module'])
                                                            <span class="truncate max-w-[90px] text-slate-400">{{ $row['module']->name }}</span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </td>

                                        <!-- Celdas de los Días del Mes con Checks -->
                                        @foreach($matrixData['days'] as $d => $dayInfo)
                                            @php
                                                $cell = $row['cells'][$d] ?? ['scheduled' => false];
                                                $wTheme = $matrixData['weeks'][$dayInfo['weekIndex']];
                                                $isMatrixDayToday = ($dayInfo['date'] === $todayBolivia);
                                                $isMatrixDayFuture = ($dayInfo['date'] > $todayBolivia);
                                            @endphp
                                            <td class="p-1 min-w-[38px] sm:min-w-[42px] text-center align-middle border-r border-slate-100 dark:border-slate-800/60 transition-colors
                                                @if($isMatrixDayToday)
                                                    {{ $wTheme['todayCellBg'] }}
                                                @elseif($isMatrixDayFuture)
                                                    bg-slate-100/40 dark:bg-slate-800/30
                                                @endif">
                                                @if($cell['scheduled'])
                                                    <div class="flex flex-col items-center justify-center gap-1 mx-auto py-0.5">
                                                        @if(!empty($cell['can_approve_reject']))
                                                            <div class="matrix-approval-actions flex items-center justify-center gap-1" id="approval-actions-{{ $cell['task_id'] }}">
                                                                <button type="button"
                                                                    onclick="approveMatrixTask(this, {{ $cell['task_id'] }})"
                                                                    data-task-id="{{ $cell['task_id'] }}"
                                                                    data-row-id="{{ $row['id'] }}"
                                                                    data-week-bg="{{ $wTheme['checkBg'] }}"
                                                                    data-week-pending="{{ $wTheme['checkPending'] }}"
                                                                    class="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center shadow-xs transition transform hover:scale-110 active:scale-95 cursor-pointer"
                                                                    title="Aprobar tarea">
                                                                    <i data-lucide="check" class="w-2.5 h-2.5 sm:w-3 sm:h-3 stroke-[3]"></i>
                                                                </button>
                                                                <button type="button"
                                                                    onclick="rejectMatrixTask(this, {{ $cell['task_id'] }})"
                                                                    data-task-id="{{ $cell['task_id'] }}"
                                                                    data-row-id="{{ $row['id'] }}"
                                                                    data-week-bg="{{ $wTheme['checkBg'] }}"
                                                                    data-week-pending="{{ $wTheme['checkPending'] }}"
                                                                    class="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded bg-red-500 hover:bg-red-600 text-white flex items-center justify-center shadow-xs transition transform hover:scale-110 active:scale-95 cursor-pointer"
                                                                    title="Rechazar tarea">
                                                                    <i data-lucide="x" class="w-2.5 h-2.5 sm:w-3 sm:h-3 stroke-[3]"></i>
                                                                </button>
                                                            </div>
                                                        @elseif(!empty($cell['is_pending_approval']) && !$user->hasFullAccess())
                                                            <div class="flex items-center justify-center" title="En revisión: pendiente de aprobación">
                                                                <span class="text-[8px] sm:text-[9px] font-bold px-1 py-0.2 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-800 leading-none">Rev</span>
                                                            </div>
                                                        @endif

                                                        @php
                                                            $isCellFuture = !empty($cell['is_future']) || $isMatrixDayFuture;
                                                            $cellTitle = $cell['is_completed']
                                                                ? 'Completado en ' . $cell['date'] . ' (clic para desmarcar)'
                                                                : (!empty($cell['is_pending_approval'])
                                                                    ? 'En revisión: pendiente de aprobación'
                                                                    : ($isCellFuture
                                                                        ? 'Fecha futura (' . $cell['date'] . '): no disponible todavía'
                                                                        : 'Pendiente en ' . $cell['date'] . ' (clic para completar)'));
                                                        @endphp
                                                        <button type="button"
                                                            id="matrix-btn-{{ $cell['task_id'] }}"
                                                            onclick="toggleMatrixCheck(this, {{ $cell['task_id'] }})"
                                                            data-task-id="{{ $cell['task_id'] }}"
                                                            data-completed="{{ $cell['is_completed'] ? 'true' : 'false' }}"
                                                            data-status="{{ $cell['status'] }}"
                                                            data-needs-review="{{ !empty($cell['needs_review']) ? 'true' : 'false' }}"
                                                            data-is-future="{{ $isCellFuture ? 'true' : 'false' }}"
                                                            data-row-id="{{ $row['id'] }}"
                                                            data-week-bg="{{ $wTheme['checkBg'] }}"
                                                            data-week-pending="{{ $wTheme['checkPending'] }}"
                                                            class="matrix-check-btn w-7 h-7 sm:w-8 sm:h-8 rounded-lg mx-auto flex items-center justify-center transition-all duration-150 transform select-none touch-manipulation
                                                            @if($cell['is_completed'])
                                                                @if($isCellFuture)
                                                                    bg-slate-400 dark:bg-slate-600 text-white border border-slate-400 dark:border-slate-600 opacity-60
                                                                @else
                                                                    {{ $wTheme['checkBg'] }}
                                                                @endif
                                                            @elseif(!empty($cell['is_pending_approval']))
                                                                border-2 border-dashed border-purple-400 dark:border-purple-500 bg-purple-50/40 dark:bg-purple-950/20 text-purple-500
                                                            @elseif($isCellFuture)
                                                                border-2 border-slate-300 dark:border-slate-700 bg-slate-100/70 dark:bg-slate-800/60 text-slate-300 dark:text-slate-600 opacity-60
                                                            @else
                                                                border-2 {{ $wTheme['checkPending'] }} text-transparent hover:scale-105 active:scale-90
                                                            @endif
                                                            {{ empty($cell['can_toggle']) ? 'cursor-not-allowed' : 'cursor-pointer' }}"
                                                            title="{{ $cellTitle }}"
                                                            {{ empty($cell['can_toggle']) ? 'disabled' : '' }}>
                                                            @if($cell['is_completed'])
                                                                <i data-lucide="check" class="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[3] block"></i>
                                                            @elseif(!empty($cell['is_pending_approval']))
                                                                <i data-lucide="clock" class="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2] block"></i>
                                                            @else
                                                                <i data-lucide="check" class="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[3] hidden"></i>
                                                            @endif
                                                        </button>
                                                    </div>
                                                @else
                                                    <div class="w-6 h-6 sm:w-7 sm:h-7 mx-auto"></div>
                                                @endif
                                            </td>
                                        @endforeach
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="{{ count($matrixData['days']) + 1 }}" class="py-16 text-center">
                                            <div class="flex flex-col items-center justify-center space-y-3">
                                                <div class="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400">
                                                    <i data-lucide="calendar-x" class="w-7 h-7"></i>
                                                </div>
                                                <h4 class="text-sm font-bold text-slate-700 dark:text-slate-200">No hay tareas programadas para este mes</h4>
                                                <p class="text-xs text-slate-400 max-w-sm">No se encontraron tareas ni reglas periódicas en {{ $matrixData['monthLabel'] }}.</p>
                                                @if(!$matrixData['isCurrentMonth'])
                                                    <div class="pt-2">
                                                        <a href="{{ route('dashboard', array_merge(request()->query(), ['view' => 'checklist', 'month' => $matrixData['currentMonth']])) }}"
                                                            class="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs transition">
                                                            Ir al mes actual
                                                        </a>
                                                    </div>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse

                                <tr id="matrix-no-search-results" class="hidden">
                                    <td colspan="{{ count($matrixData['days']) + 1 }}" class="py-10 text-center text-xs text-slate-400 dark:text-slate-500">
                                        No se encontraron actividades que coincidan con la búsqueda.
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            @endif

        @endif
    </div>

    <!-- Mobile Fixed Bottom Navigation Bar (PWA Experience Inspired by diseñosreferencia) -->
    <nav class="fixed md:hidden bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800 pb-safe shadow-lg">
        <div class="flex items-center justify-around h-16 px-2">
            <!-- 1. Resumen -->
            <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'resumen']) }}"
                class="flex flex-col items-center justify-center flex-1 h-full min-h-[44px] transition py-1
                {{ $activeView === 'resumen' ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
                <span class="text-[10px] mt-1">Resumen</span>
            </a>

            <!-- 2. Calendario -->
            <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'calendario']) }}"
                class="flex flex-col items-center justify-center flex-1 h-full min-h-[44px] transition py-1
                {{ $activeView === 'calendario' ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                <i data-lucide="calendar-days" class="w-5 h-5"></i>
                <span class="text-[10px] mt-1">Calendario</span>
            </a>

            <!-- 3. Kanban Tablero -->
            <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'kanban']) }}"
                class="flex flex-col items-center justify-center flex-1 h-full min-h-[44px] transition py-1
                {{ $activeView === 'kanban' ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                <i data-lucide="kanban" class="w-5 h-5"></i>
                <span class="text-[10px] mt-1">Tablero</span>
            </a>

            <!-- 4. Incidencias -->
            <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'incidencias']) }}"
                class="flex flex-col items-center justify-center flex-1 h-full min-h-[44px] transition py-1 relative
                {{ $activeView === 'incidencias' ? 'text-red-600 dark:text-red-400 font-bold' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                <i data-lucide="alert-circle" class="w-5 h-5"></i>
                <span class="text-[10px] mt-1">Incidencias</span>
                @if($incidents->where('estado', '!=', 'resuelta')->count() > 0)
                    <span class="absolute top-2 right-4 w-2 h-2 rounded-full bg-red-500 ring-2 ring-white dark:ring-slate-900"></span>
                @endif
            </a>

            <!-- 5. Menú Más (Opciones del header que no caben en la barra inferior) -->
            <button type="button" onclick="toggleMoreMobileMenu()" id="btn-mobile-more"
                class="flex flex-col items-center justify-center flex-1 h-full min-h-[44px] transition py-1
                {{ in_array($activeView, ['enlaces', 'periodicas', 'papelera', 'checklist']) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white' }}">
                <i data-lucide="more-vertical" class="w-5 h-5"></i>
                <span class="text-[10px] mt-1">Más</span>
            </button>
        </div>
    </nav>

    <!-- Mobile "Más" Bottom Sheet Modal -->
    <div id="mobile-more-menu" class="fixed inset-0 z-50 hidden" onclick="if(event.target === this) toggleMoreMobileMenu()">
        <div class="fixed inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity" onclick="toggleMoreMobileMenu()"></div>
        <div class="fixed bottom-0 left-0 right-0 z-51 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 rounded-t-2xl p-4 pb-safe shadow-2xl max-h-[85vh] overflow-y-auto">
            <div class="w-12 h-1 bg-slate-200 dark:bg-slate-700 rounded-full mx-auto mb-3"></div>
            <div class="flex items-center justify-between mb-3 px-1">
                <h3 class="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    <i data-lucide="grid" class="w-4 h-4 text-blue-600 dark:text-blue-400"></i>
                    <span>Más Opciones</span>
                </h3>
                <button type="button" onclick="toggleMoreMobileMenu()" class="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>
            <div class="grid grid-cols-2 gap-2.5">
                <!-- 1. Opción: Resumen -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'resumen']) }}"
                    class="flex items-center gap-3 p-3 rounded-xl border transition {{ $activeView === 'resumen' ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-500 text-blue-700 dark:text-blue-300 font-bold' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800' }}">
                    <div class="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400 shrink-0">
                        <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-semibold truncate">Resumen</div>
                    </div>
                </a>

                <!-- 2. Opción: Calendario -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'calendario']) }}"
                    class="flex items-center gap-3 p-3 rounded-xl border transition {{ $activeView === 'calendario' ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-500 text-blue-700 dark:text-blue-300 font-bold' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800' }}">
                    <div class="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400 shrink-0">
                        <i data-lucide="calendar-days" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-semibold truncate">Calendario</div>
                    </div>
                </a>

                <!-- 3. Opción: Tablero Kanban -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'kanban']) }}"
                    class="flex items-center gap-3 p-3 rounded-xl border transition {{ $activeView === 'kanban' ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-500 text-blue-700 dark:text-blue-300 font-bold' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800' }}">
                    <div class="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400 shrink-0">
                        <i data-lucide="kanban" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-semibold truncate">Tablero</div>
                    </div>
                </a>

                <!-- 4. Opción: Incidencias -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'incidencias']) }}"
                    class="flex items-center gap-3 p-3 rounded-xl border transition {{ $activeView === 'incidencias' ? 'bg-red-50 dark:bg-red-950/60 border-red-500 text-red-700 dark:text-red-300 font-bold' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800' }}">
                    <div class="p-2 rounded-lg bg-red-100 dark:bg-red-900/60 text-red-600 dark:text-red-400 shrink-0">
                        <i data-lucide="alert-circle" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-semibold truncate">Incidencias</div>
                    </div>
                </a>

                <!-- 5. Opción: Enlaces -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'enlaces']) }}"
                    class="flex items-center gap-3 p-3 rounded-xl border transition {{ $activeView === 'enlaces' ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-500 text-blue-700 dark:text-blue-300 font-bold' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800' }}">
                    <div class="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400 shrink-0">
                        <i data-lucide="link" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-semibold truncate">Enlaces</div>
                    </div>
                </a>

                <!-- 6. Opción: Tareas Periódicas (Admin/Dev) -->
                @if($user->isAdmin())
                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'periodicas']) }}"
                    class="flex items-center gap-3 p-3 rounded-xl border transition {{ $activeView === 'periodicas' ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-500 text-blue-700 dark:text-blue-300 font-bold' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800' }}">
                    <div class="p-2 rounded-lg bg-indigo-100 dark:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 shrink-0">
                        <i data-lucide="repeat" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-semibold truncate">Periódicas</div>
                    </div>
                </a>
                @endif

                <!-- 7. Opción: Papelera -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'papelera']) }}"
                    class="flex items-center gap-3 p-3 rounded-xl border transition {{ $activeView === 'papelera' ? 'bg-red-50 dark:bg-red-950/60 border-red-500 text-red-700 dark:text-red-300 font-bold' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800' }}">
                    <div class="p-2 rounded-lg bg-red-100 dark:bg-red-900/60 text-red-600 dark:text-red-400 shrink-0">
                        <i data-lucide="trash-2" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-semibold truncate">Papelera</div>
                    </div>
                </a>

                <!-- 8. Opción: CheckList -->
                <a href="{{ route('dashboard', ['project_id' => $activeProject ? $activeProject->id : '', 'module_id' => $activeModuleId, 'view' => 'checklist']) }}"
                    class="flex items-center gap-3 p-3 rounded-xl border transition {{ in_array($activeView, ['checklist', 'lista_tareas']) ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-700 dark:text-indigo-300 font-bold' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800' }}">
                    <div class="p-2 rounded-lg bg-indigo-100 dark:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 shrink-0">
                        <i data-lucide="check-square" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-semibold truncate">CheckList</div>
                    </div>
                </a>

                <!-- 8. Opción: Menú Lateral / Proyectos -->
                <button type="button" onclick="toggleMoreMobileMenu(); toggleSidebar();"
                    class="flex items-center gap-3 p-3 rounded-xl border bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition text-left">
                    <div class="p-2 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 shrink-0">
                        <i data-lucide="folder" class="w-5 h-5"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xs font-semibold truncate">Proyectos</div>
                    </div>
                </button>
            </div>
        </div>
    </div>

</main>

<!-- ========================================================================= -->
<!-- MODALS                                                                    -->
<!-- ========================================================================= -->

@if($activeView === 'calendario')
<!-- Modal: Calendario Expandido (Vista Grande Superpuesta) -->
<div id="calendarModal" onclick="if(event.target === this) closeCalendarExpand()" class="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 hidden">
    <div class="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-2xl shadow-2xl w-full max-w-[96vw] xl:max-w-[94vw] h-[92vh] max-h-[94vh] border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        <!-- Cabecera del Modal Expandido -->
        <div class="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-900/80 shrink-0">
            <div class="flex items-center gap-2.5 sm:gap-3 min-w-0">
                <div class="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shrink-0">
                    <i data-lucide="calendar" class="w-5 h-5"></i>
                </div>
                <div class="min-w-0">
                    <div class="flex items-center gap-2">
                        <h3 class="font-bold text-slate-900 dark:text-white text-sm sm:text-base tracking-tight truncate">
                            Calendario Completo
                        </h3>
                        @if($activeProject)
                            <span class="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                                <i data-lucide="folder" class="w-3 h-3"></i>
                                <span class="truncate max-w-[150px]">{{ $activeProject->name }}</span>
                            </span>
                        @endif
                    </div>
                    
                </div>
            </div>

            <!-- Botón para Cerrar la vista expandida (solo botón X para cerrar) -->
            <div class="flex items-center gap-2 shrink-0">
                @if(!$user->isHelper() && $activeProject)
                    <div class="relative flex items-center">
                        <i data-lucide="user" class="w-3.5 h-3.5 absolute left-2.5 text-slate-400 pointer-events-none"></i>
                        <select id="calendar-modal-user-filter" onchange="onUserFilterChange(this.value)"
                            class="pl-7 pr-7 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200/70 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 text-xs font-semibold appearance-none cursor-pointer outline-none focus:ring-2 focus:ring-indigo-500/20 transition max-w-[145px] sm:max-w-[190px] truncate"
                            title="Filtrar tareas por usuario">
                            <option value="">Todos los usuarios</option>
                            @foreach($projectUsers as $pUser)
                                <option value="{{ $pUser->id }}" {{ (string)$selectedUserId === (string)$pUser->id ? 'selected' : '' }}>
                                    {{ $pUser->name }}
                                </option>
                            @endforeach
                        </select>
                        <i data-lucide="chevron-down" class="w-3.5 h-3.5 absolute right-2 text-slate-400 pointer-events-none"></i>
                    </div>
                @endif
                <button type="button" onclick="closeCalendarExpand()" class="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition" title="Cerrar">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>
        </div>

        <!-- Área de contenido del Calendario Expandido -->
        <div id="calendar-expanded-slot" class="flex-1 min-h-0 p-3 sm:p-5 overflow-y-auto"></div>
    </div>
</div>
@endif

<!-- 1. Task Modal -->
<div id="taskModal" class="fixed inset-0 bg-slate-950/75 z-50 flex items-center justify-center p-2 sm:p-4 hidden">
    <div class="isolate task-modal-card bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div class="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/60 dark:bg-slate-900/60">
            <h3 id="taskModalTitle" class="font-bold text-slate-900 dark:text-white text-sm sm:text-base">Nueva Tarea</h3>
            <button onclick="closeModal('taskModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-lg"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>

        <form id="taskForm" method="POST" action="{{ route('tasks.store') }}" class="px-4 sm:px-6 pb-4 sm:pb-5 max-h-[calc(92vh-60px)] overflow-y-auto">
            @csrf
            <input type="hidden" id="task_method" name="_method" value="POST">
            <input type="hidden" name="project_id" value="{{ $activeProject ? $activeProject->id : '' }}">

            <div class="flex flex-col md:flex-row gap-4 pt-4">
                <!-- Left column -->
                <div class="w-full md:w-8/12 space-y-3.5">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Título de la Tarea *</label>
                        <input type="text" id="task_title" name="title" required autofocus
                            placeholder="¿Qué hay que hacer?"
                            class="w-full px-3.5 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm text-slate-900 dark:text-white outline-none transition">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Descripción</label>
                        <textarea id="task_description" name="description" rows="3"
                            placeholder="Detalles opcionales de la tarea..."
                            class="w-full px-3.5 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm text-slate-900 dark:text-white outline-none transition resize-none"></textarea>
                    </div>

                    <!-- Needs review checkbox -->
                    <label class="flex items-start gap-2.5 px-3.5 py-2.5 bg-purple-50/60 dark:bg-purple-950/40 border border-purple-100 dark:border-purple-900/50 rounded-xl cursor-pointer">
                        <input type="checkbox" id="task_needs_review" name="needs_review" value="1"
                            class="mt-0.5 rounded border-slate-300 dark:border-slate-600 text-purple-600 focus:ring-purple-500 accent-purple-600">
                        <span class="text-xs text-slate-700 dark:text-slate-300">
                            <span class="font-bold text-purple-900 dark:text-purple-200">Esta tarea necesita revisión</span><br>
                            <span class="text-slate-500 dark:text-slate-400">Antes de finalizar deberá pasar por "En Revisión" y ser aprobada por un Administrador.</span>
                        </span>
                    </label>

                    <!-- Subtasks section -->
                    <div class="pt-3 border-t border-slate-100 dark:border-slate-800">
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
                            <i data-lucide="list-todo" class="w-4 h-4 text-indigo-500"></i>
                            Subtareas
                            <span id="subtask-counter" class="text-[10px] bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 px-2 py-0.5 rounded-full font-bold hidden"></span>
                        </label>

                        <!-- Subtask list -->
                        <ul id="subtask-list" class="space-y-1 mb-2 max-h-36 overflow-y-auto pr-0.5"></ul>
                        <div id="subtask-inputs"></div>

                        <!-- Add subtask input -->
                        <div class="flex gap-2">
                            <input type="text" id="subtask_input"
                                placeholder="Nueva subtarea... (Enter para agregar)"
                                class="flex-1 px-3 py-1.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 text-xs text-slate-900 dark:text-white outline-none">
                            <button type="button" onclick="addSubtask()"
                                class="shrink-0 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition flex items-center shadow-xs">
                                <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Right column: status, priority, dates, assignees -->
                <div class="w-full md:w-4/12 space-y-3">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Módulo del Proyecto</label>
                        <select id="task_module_id" name="module_id"
                            style="color-scheme: light dark;"
                            class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 text-xs text-slate-900 dark:text-white outline-none">
                            <option value="">Sin Módulo (General)</option>
                            @if($activeProject)
                                @foreach($activeProject->modules as $m)
                                    <option value="{{ $m->id }}">{{ $m->name }}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Estado</label>
                        <select id="task_status" name="status"
                            style="color-scheme: light dark;"
                            class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 text-xs text-slate-900 dark:text-white outline-none">
                            <option value="no_iniciado">No Iniciado</option>
                            <option value="en_proceso">En Proceso</option>
                            <option value="en_revision">En Revisión</option>
                            <option value="rechazado">Rechazado</option>
                            <option value="finalizado">Finalizado</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Prioridad</label>
                        <select id="task_priority" name="priority"
                            style="color-scheme: light dark;"
                            class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 text-xs text-slate-900 dark:text-white outline-none">
                            <option value="baja">Baja</option>
                            <option value="media" selected>Media</option>
                            <option value="alta">Alta</option>
                        </select>
                    </div>

                    <!-- Fecha y Hora de Inicio -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Fecha y Hora de Inicio</label>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <input type="date" id="task_start_date" name="start_date"
                                oninput="syncTaskDateConstraints('start')" onchange="syncTaskDateConstraints('start')"
                                class="w-full px-2.5 py-1.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white outline-none">
                            <input type="time" id="task_start_time" name="start_time"
                                oninput="syncTaskDateConstraints('time')" onchange="syncTaskDateConstraints('time')"
                                class="w-full px-2.5 py-1.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white outline-none">
                        </div>
                    </div>

                    <!-- End Date toggle -->
                    <div id="end-date-toggle-btn">
                        <button type="button" onclick="showEndDate()" class="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center space-x-1">
                            <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                            <span>Agregar fecha de fin</span>
                        </button>
                    </div>

                    <div id="end-date-section" class="hidden p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1.5">
                        <div class="flex items-center justify-between">
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300">Fecha y Hora de Fin</label>
                            <button type="button" onclick="hideEndDate()" class="text-[11px] font-semibold text-red-500 hover:text-red-600 flex items-center space-x-1">
                                <i data-lucide="x" class="w-3 h-3"></i>
                                <span>Quitar</span>
                            </button>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <input type="date" id="task_end_date" name="end_date"
                                oninput="syncTaskDateConstraints('end')" onchange="syncTaskDateConstraints('end')"
                                class="w-full px-2 py-1.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg text-xs text-slate-900 dark:text-white outline-none">
                            <input type="time" id="task_end_time" name="end_time"
                                oninput="syncTaskDateConstraints('time')" onchange="syncTaskDateConstraints('time')"
                                class="w-full px-2 py-1.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg text-xs text-slate-900 dark:text-white outline-none">
                        </div>
                    </div>

                    <!-- Asignar Usuarios -->
                    @if($activeProject)
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Asignar a Miembros</label>
                        <div class="border border-slate-200 dark:border-slate-700 rounded-xl max-h-32 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-800">
                            @foreach($activeProject->members as $u)
                                <label class="flex items-center space-x-2 px-2.5 py-1.5 text-xs cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/60">
                                    <input type="checkbox" name="assigned_user_ids[]" value="{{ $u->id }}" class="task-user-checkbox rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 accent-indigo-600">
                                    <span class="w-4 h-4 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 text-[8px] font-bold flex items-center justify-center shrink-0">
                                        {{ $u->initials }}
                                    </span>
                                    <span class="text-slate-700 dark:text-slate-200 truncate">{{ $u->name }}</span>
                                    <span class="text-slate-400 text-[10px] shrink-0">({{ $u->role }})</span>
                                </label>
                            @endforeach
                        </div>
                    </div>
                    @endif

                    <!-- Archivos Adjuntos (Punto 17) -->
                    <div id="taskAttachmentsSection" class="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2 hidden">
                        <div class="flex items-center justify-between">
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                                <i data-lucide="paperclip" class="w-3.5 h-3.5 text-indigo-500"></i>
                                <span>Archivos Adjuntos</span>
                            </label>
                            <span id="taskAttachmentsCount" class="text-[10px] text-slate-400 font-mono"></span>
                        </div>
                        
                        <div class="flex items-center gap-2">
                            <input type="file" id="task_attachment_file" class="text-xs text-slate-600 dark:text-slate-300 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-950/80 file:text-indigo-600 dark:file:text-indigo-400 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-900 cursor-pointer w-full">
                            <button type="button" onclick="uploadTaskAttachment()" id="btnUploadTaskAttachment" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shrink-0 shadow-xs flex items-center gap-1">
                                <i data-lucide="upload" class="w-3 h-3"></i>
                                <span>Adjuntar</span>
                            </button>
                        </div>

                        <div id="taskAttachmentsList" class="space-y-1.5 max-h-36 overflow-y-auto"></div>
                    </div>
                </div>
            </div>

            <!-- Footer actions -->
            <div class="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-3 mt-4 border-t border-slate-100 dark:border-slate-800">
                <button type="button" onclick="closeModal('taskModal')" class="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition text-center">Cancelar</button>
                <button type="submit" id="btnSaveTaskPerUser" name="create_per_user" value="1" title="Crea 1 tarea independiente para cada usuario seleccionado" class="w-full sm:w-auto px-4 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl transition shadow-xs inline-flex items-center justify-center gap-1.5">
                    <i data-lucide="users" class="w-4 h-4"></i>
                    <span>Para cada usuario</span>
                </button>
                <button type="submit" class="w-full sm:w-auto px-4 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition shadow-xs text-center">Guardar Tarea</button>
            </div>
        </form>
    </div>
</div>

<!-- 2. Project Modal -->
<div id="projectModal" class="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 hidden">
    <div class="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-2xl shadow-2xl max-w-xl w-full p-4 sm:p-6 space-y-4 max-h-[90vh] overflow-y-auto border border-slate-200 dark:border-slate-800">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 id="projectModalTitle" class="text-sm sm:text-base font-bold text-slate-900 dark:text-white">Nuevo Proyecto</h3>
            <button onclick="closeModal('projectModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-white"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>

        <form id="projectForm" method="POST" action="{{ route('projects.store') }}" class="space-y-4">
            @csrf
            <input type="hidden" id="project_method" name="_method" value="POST">

            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Nombre del Proyecto *</label>
                <input type="text" id="project_name" name="name" required class="w-full px-3.5 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Miembros con Acceso</label>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-32 overflow-y-auto p-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs">
                    @foreach($allUsers as $u)
                        <label class="flex items-center gap-2 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700 p-1 rounded-lg">
                            <input type="checkbox" name="member_user_ids[]" value="{{ $u->id }}" onchange="renderProjectLinks()" class="proj-user-checkbox rounded border-slate-300 dark:border-slate-600 text-indigo-600 accent-indigo-600">
                            <span class="truncate text-slate-700 dark:text-slate-200">{{ $u->name }} <span class="text-slate-400 text-[10px]">({{ $u->role }})</span></span>
                        </label>
                    @endforeach
                </div>
            </div>

            <!-- Enlaces del Proyecto -->
            <div class="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <i data-lucide="link" class="w-4 h-4 text-[#0f172a] dark:text-slate-300"></i>
                    Enlaces y Recursos del Proyecto
                </label>

                <!-- Formulario agregar enlace -->
                <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <input type="text" id="link_name_input" placeholder="Nombre (Ej. Repositorio, Figma...)" class="w-full sm:flex-1 px-3 py-1.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-slate-900 focus:outline-none">
                    <input type="text" id="link_url_input" placeholder="URL (Ej. https://...)" class="w-full sm:flex-1 px-3 py-1.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-slate-900 focus:outline-none">
                    <button type="button" onclick="addProjectLink()" class="w-full sm:w-auto px-3.5 py-1.5 bg-[#0f172a] hover:bg-slate-800 text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-1 transition shrink-0">
                        <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                        <span>Agregar</span>
                    </button>
                </div>

                <!-- Lista de enlaces agregados -->
                <div id="project-links-list" class="space-y-2 max-h-48 overflow-y-auto pr-1"></div>
                <div id="project-links-hidden-inputs"></div>
            </div>

            <div class="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button type="button" onclick="closeModal('projectModal')" class="w-full sm:w-auto py-2 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-xl text-xs text-center transition">Cancelar</button>
                <button type="submit" class="w-full sm:w-auto py-2 px-4 bg-[#0f172a] hover:bg-slate-800 text-white font-semibold rounded-xl text-xs text-center shadow-xs transition">Guardar Proyecto</button>
            </div>
        </form>
    </div>
</div>

<!-- 3. Module Modal -->
<div id="moduleModal" class="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 hidden">
    <div class="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-2xl shadow-2xl max-w-sm w-full p-4 sm:p-6 space-y-4 max-h-[90vh] overflow-y-auto border border-slate-200 dark:border-slate-800">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 id="moduleModalTitle" class="text-sm font-bold text-slate-900 dark:text-white">Nuevo Módulo</h3>
            <button onclick="closeModal('moduleModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-white"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>

        <form id="moduleForm" method="POST" action="{{ route('modules.store') }}" class="space-y-4">
            @csrf
            <input type="hidden" id="module_method" name="_method" value="POST">
            <input type="hidden" id="module_project_id" name="project_id" value="">

            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Nombre del Módulo *</label>
                <input type="text" id="module_name" name="name" required class="w-full px-3.5 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-slate-900 focus:outline-none">
            </div>

            <div class="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button type="button" onclick="closeModal('moduleModal')" class="w-full sm:w-auto py-2 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-xl text-xs text-center">Cancelar</button>
                <button type="submit" class="w-full sm:w-auto py-2 px-4 bg-[#0f172a] hover:bg-slate-800 text-white font-semibold rounded-xl text-xs text-center shadow-xs">Guardar Módulo</button>
            </div>
        </form>
    </div>
</div>

<!-- 4. Incident Modal -->
<div id="incidentModal" class="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 hidden">
    <div class="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-2xl shadow-2xl max-w-lg w-full p-4 sm:p-6 space-y-4 max-h-[90vh] overflow-y-auto border border-slate-200 dark:border-slate-800">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 class="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="alert-triangle" class="w-4 h-4 text-red-500"></i>
                <span id="incidentModalTitle">Reportar Incidencia</span>
            </h3>
            <button onclick="closeModal('incidentModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-white"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>

        <form id="incidentForm" method="POST" action="{{ route('incidents.store') }}" enctype="multipart/form-data" class="space-y-4">
            @csrf
            <input type="hidden" id="incident_method" name="_method" value="POST">

            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Título de la Incidencia *</label>
                <input type="text" id="incident_titulo" name="titulo" required class="w-full px-3.5 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Descripción</label>
                <textarea id="incident_descripcion" name="descripcion" rows="3" class="w-full px-3.5 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none"></textarea>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Proyecto Vinculado</label>
                    <select id="incident_project_id" name="project_id" class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none">
                        <option value="">General (Sin proyecto asignado)</option>
                        @foreach(($visibleProjects ?? collect()) as $p)
                            <option value="{{ $p->id }}" {{ ($activeProject && $activeProject->id == $p->id) ? 'selected' : '' }}>
                                {{ $p->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Asignar a Usuario</label>
                    <select id="incident_assigned_user_id" name="assigned_user_id" class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none">
                        <option value="">Sin asignar</option>
                        @foreach($allUsers as $u)
                            <option value="{{ $u->id }}">{{ $u->name }} ({{ $u->role }})</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Prioridad</label>
                    <select id="incident_prioridad" name="prioridad" class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none">
                        <option value="baja">Baja</option>
                        <option value="media" selected>Media</option>
                        <option value="alta">Alta</option>
                        <option value="urgente">Urgente</option>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Estado</label>
                    <select id="incident_estado" name="estado" class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none">
                        <option value="abierta" selected>Abierta</option>
                        <option value="en_proceso">En Proceso</option>
                        <option value="resuelta">Resuelta</option>
                    </select>
                </div>
            </div>

            <!-- Archivos Adjuntos para Incidencias -->
            <div id="incidentAttachmentsSection" class="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
                <div class="flex items-center justify-between">
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <i data-lucide="paperclip" class="w-3.5 h-3.5 text-red-500"></i>
                        <span>Adjuntar Archivo</span>
                    </label>
                    <span id="incidentAttachmentsCount" class="text-[10px] text-slate-400 font-mono"></span>
                </div>
                
                <div class="space-y-2">
                    <div class="relative flex items-center">
                        <input type="file" id="incident_attachment_file" name="attachment_file" onchange="handleIncidentFileSelected(this)"
                            class="text-xs text-slate-600 dark:text-slate-300 file:mr-2.5 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-red-50 dark:file:bg-red-950/80 file:text-red-600 dark:file:text-red-400 hover:file:bg-red-100 dark:hover:file:bg-red-900 cursor-pointer w-full border border-slate-200 dark:border-slate-700 rounded-xl p-1 bg-white dark:bg-slate-800 focus:outline-none">
                    </div>

                    <!-- Previsualización de archivo recién seleccionado con icono de eliminar -->
                    <div id="incidentSelectedFilePreview" class="hidden flex items-center justify-between gap-2 p-2 bg-red-50/60 dark:bg-red-950/30 border border-red-200/80 dark:border-red-900/60 rounded-xl">
                        <div class="flex items-center gap-2 min-w-0 flex-1">
                            <div class="p-1 rounded-lg bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-300 shrink-0">
                                <i data-lucide="file" class="w-3.5 h-3.5"></i>
                            </div>
                            <div class="min-w-0 flex-1">
                                <div class="flex items-center gap-1.5">
                                    <span id="incidentSelectedFileName" class="text-xs font-medium text-slate-800 dark:text-slate-200 truncate block"></span>
                                    <span class="text-[9px] px-1.5 py-0.2 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 font-bold rounded shrink-0">Nuevo</span>
                                </div>
                                <span id="incidentSelectedFileSize" class="text-[10px] text-slate-400 block font-mono"></span>
                            </div>
                        </div>
                        <button type="button" onclick="clearSelectedIncidentFile(event)"
                            class="p-1 text-slate-400 hover:text-red-600 hover:bg-red-100/80 dark:hover:bg-red-900/50 rounded-lg transition shrink-0"
                            title="Quitar archivo seleccionado">
                            <i data-lucide="trash-2" class="w-4 h-4 text-red-500"></i>
                        </button>
                    </div>
                </div>

                <!-- Archivos existentes (al editar incidencia) -->
                <div id="incidentExistingFilesSection" class="hidden space-y-1.5 pt-1">
                    <span class="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Archivos adjuntos actuales:</span>
                    <div id="incidentAttachmentsList" class="space-y-1.5 max-h-36 overflow-y-auto"></div>
                </div>

                <!-- Hidden inputs para IDs marcados para eliminación -->
                <div id="incidentPendingRemoveInputs"></div>
            </div>

            <div class="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button type="button" id="btnDeleteIncidentModal" onclick="confirmDeleteCurrentIncident()" class="hidden w-full sm:w-auto py-2 px-3.5 bg-red-100 hover:bg-red-200 text-red-700 dark:bg-red-950/80 dark:hover:bg-red-900 dark:text-red-300 font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 transition border border-red-200 dark:border-red-900 cursor-pointer" title="Eliminar incidencia">
                    <i data-lucide="trash-2" class="w-4 h-4 text-red-600 dark:text-red-400"></i>
                    <span>Eliminar incidencia</span>
                </button>
                <div class="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 w-full sm:w-auto sm:ml-auto">
                    <button type="button" onclick="closeModal('incidentModal')" class="w-full sm:w-auto py-2 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-xl text-xs text-center cursor-pointer">Cancelar</button>
                    <button type="submit" id="btnSubmitIncident" class="w-full sm:w-auto py-2 px-4 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl text-xs text-center shadow-xs cursor-pointer">Guardar Incidencia</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- 5. Users List Modal -->
@if($user->isAdmin())
<div id="usersListModal" class="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 hidden">
    <div class="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-2xl shadow-2xl max-w-lg w-full p-4 sm:p-6 space-y-4 max-h-[90vh] overflow-y-auto border border-slate-200 dark:border-slate-800">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 class="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="users" class="w-5 h-5 text-indigo-600 dark:text-indigo-400"></i>
                <span>Gestión de Usuarios del Equipo</span>
            </h3>
            <button onclick="closeModal('usersListModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-white"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>

        <form id="userForm" method="POST" action="{{ route('users.store') }}" class="p-3.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl space-y-3">
            @csrf
            <input type="hidden" id="user_method" name="_method" value="POST">

            <div class="flex items-center justify-between gap-2">
                <h4 id="userFormTitle" class="text-xs font-bold text-slate-800 dark:text-slate-200">Agregar Nuevo Usuario</h4>
                <button type="button" id="btnCancelUserEdit" onclick="resetUserForm()" class="text-[10px] text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-semibold hidden flex items-center gap-1 shrink-0">
                    <i data-lucide="rotate-ccw" class="w-3 h-3"></i>
                    <span>Cancelar edición</span>
                </button>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input type="text" id="user_name" name="name" placeholder="Nombre completo" required class="w-full px-3 py-1.5 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 rounded-lg text-xs text-slate-900 dark:text-white">
                <input type="email" id="user_email" name="email" placeholder="Correo electrónico" required class="w-full px-3 py-1.5 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 rounded-lg text-xs text-slate-900 dark:text-white">
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input type="password" id="user_password" name="password" placeholder="Contraseña" required class="w-full px-3 py-1.5 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 rounded-lg text-xs text-slate-900 dark:text-white">
                <select id="user_role" name="role" required class="w-full px-3 py-1.5 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 rounded-lg text-xs text-slate-900 dark:text-white">
                    <option value="Admin">Admin</option>
                    <option value="Desarrollador">Desarrollador</option>
                    <option value="Ayudante">Ayudante</option>
                </select>
            </div>
            <button type="submit" id="btnSubmitUser" class="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl shadow-xs transition">Crear Usuario</button>
        </form>

        <div class="divide-y divide-slate-100 dark:divide-slate-800">
            @foreach($allUsers as $u)
                <div class="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1">
                        <div class="w-8 h-8 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-xs flex items-center justify-center shrink-0">
                            {{ $u->initials }}
                        </div>
                        <div class="min-w-0 flex-1">
                            <p class="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{{ $u->name }}</p>
                            <div class="flex flex-wrap items-center gap-1.5 sm:gap-2">
                                <p class="text-[10px] text-slate-400 truncate">{{ $u->email }}</p>
                                
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
                        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">{{ $u->role }}</span>
                        <button type="button" onclick='editUserInModal(@json($u))' class="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition" title="Editar usuario">
                            <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                        </button>
                        @if(Auth::id() !== $u->id)
                            <form method="POST" action="{{ route('users.destroy', $u->id) }}" onsubmit="return confirmDelete(event, this, { title: '¿Eliminar usuario?', message: '¿Estás seguro de que deseas eliminar a {{ addslashes($u->name) }}? Perderá el acceso al sistema inmediatamente.', confirmText: 'Eliminar usuario', isPermanent: true, permanentText: 'Advertencia: Se removerá el acceso de esta cuenta del sistema.' });" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="p-1.5 text-slate-400 hover:text-red-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition" title="Eliminar usuario">
                                    <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                </button>
                            </form>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endif

<!-- 6. Recurring Task Modal -->
<div id="recurringTaskModal" class="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center hidden p-3 sm:p-4">
    <div class="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-200 dark:border-slate-800 max-h-[92vh] flex flex-col">
        <div class="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/60 dark:bg-slate-900/60 shrink-0">
            <h3 class="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2" id="recurringTaskModalTitle">
                <i data-lucide="repeat" class="w-4 h-4 sm:w-5 sm:h-5 text-indigo-600 dark:text-indigo-400"></i>
                <span>Nueva Tarea Periódica</span>
            </h3>
            <button onclick="closeModal('recurringTaskModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-lg">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form id="recurringTaskForm" method="POST" action="{{ route('recurring-tasks.store') }}" class="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1">
            @csrf
            <input type="hidden" id="recurring_task_method" name="_method" value="POST">
            <input type="hidden" name="project_id" value="{{ $activeProject ? $activeProject->id : '' }}">

            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Título de la Tarea Periódica *</label>
                <input type="text" id="rec_title" name="title" required placeholder="Ej: Revisión diaria de servidores..."
                    class="w-full px-3.5 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Descripción</label>
                <textarea id="rec_description" name="description" rows="2" placeholder="Detalles de la tarea..."
                    class="w-full px-3.5 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"></textarea>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Periodicidad / Frecuencia *</label>
                    <select id="rec_recurrence" name="recurrence" required
                        class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                        <option value="diaria">Diaria (Todos los días)</option>
                        <option value="semanal">Semanal (Cada semana)</option>
                        <option value="mensual">Mensual (Una vez al mes)</option>
                        <option value="anual">Anual (Una vez al año)</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Prioridad *</label>
                    <select id="rec_priority" name="priority" required
                        class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                        <option value="baja">Baja</option>
                        <option value="media" selected>Media</option>
                        <option value="alta">Alta</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Módulo del Proyecto</label>
                    <select id="rec_module_id" name="module_id"
                        class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                        <option value="">Sin Módulo (General)</option>
                        @if($activeProject)
                            @foreach($activeProject->modules as $m)
                                <option value="{{ $m->id }}">{{ $m->name }}</option>
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Fecha de Inicio Base *</label>
                    <input type="date" id="rec_start_date" name="start_date" required
                        class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Hora Inicio (Opcional)</label>
                    <input type="time" id="rec_start_time" name="start_time"
                        oninput="syncRecurringTaskDateConstraints()" onchange="syncRecurringTaskDateConstraints()"
                        class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Hora Fin (Opcional)</label>
                    <input type="time" id="rec_end_time" name="end_time"
                        oninput="syncRecurringTaskDateConstraints()" onchange="syncRecurringTaskDateConstraints()"
                        class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                </div>
            </div>

            <!-- Needs review checkbox -->
            <label class="flex items-start gap-2.5 px-3.5 py-2.5 bg-purple-50/60 dark:bg-purple-950/40 border border-purple-100 dark:border-purple-900/50 rounded-xl cursor-pointer">
                <input type="checkbox" id="rec_needs_review" name="needs_review" value="1"
                    class="mt-0.5 rounded border-slate-300 dark:border-slate-600 text-purple-600 focus:ring-purple-500 accent-purple-600">
                <span class="text-xs text-slate-700 dark:text-slate-300">
                    <span class="font-bold text-purple-900 dark:text-purple-200">Requiere revisión al completarse</span><br>
                    <span class="text-slate-500 dark:text-slate-400">Las tareas generadas deberán pasar por revisión de Admin.</span>
                </span>
            </label>

            <!-- Asignar Usuarios -->
            @if($activeProject)
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Asignar Usuarios</label>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 p-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl max-h-32 overflow-y-auto">
                    @foreach($activeProject->members as $u)
                        <label class="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700 p-1 rounded-lg">
                            <input type="checkbox" name="assigned_user_ids[]" value="{{ $u->id }}" class="rec-user-checkbox rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500">
                            <span class="truncate">{{ $u->name }} <span class="text-[10px] text-slate-400">({{ $u->role }})</span></span>
                        </label>
                    @endforeach
                </div>
            </div>
            @endif

            <!-- Subtareas Plantilla -->
            <div class="pt-2 border-t border-slate-100 dark:border-slate-800">
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Subtareas Plantilla</label>
                <ul id="rec-subtask-list" class="space-y-1 mb-2 max-h-32 overflow-y-auto pr-0.5"></ul>
                <div id="rec-subtask-inputs"></div>
                <div class="flex gap-2">
                    <input type="text" id="rec_subtask_input" placeholder="Nueva subtarea plantilla..."
                        class="flex-1 px-3 py-1.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white outline-none">
                    <button type="button" onclick="addRecSubtask()" class="px-3 py-1.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-500 shrink-0 transition">
                        <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                    </button>
                </div>
            </div>

            <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2">
                <button type="button" onclick="closeModal('recurringTaskModal')" class="w-full sm:w-auto py-2 px-4 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 text-center transition">
                    Cancelar
                </button>
                <button type="submit" class="w-full sm:w-auto py-2 px-4 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-xs text-center transition">
                    Guardar Regla Periódica
                </button>
            </div>
        </form>
    </div>
</div>

<!-- 7. Comments Modal -->
<div id="commentsModal" class="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 hidden">
    <div class="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[88vh] border border-slate-200 dark:border-slate-800">
        <div class="px-4 sm:px-5 py-3 sm:py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/60 dark:bg-slate-900/60 shrink-0">
            <div class="flex items-center gap-2.5 min-w-0 flex-1 mr-2">
                <div class="p-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shrink-0">
                    <i data-lucide="message-square" class="w-4 h-4"></i>
                </div>
                <div class="min-w-0 flex-1">
                    <h3 class="font-bold text-slate-900 dark:text-white text-sm truncate" id="commentsModalTaskTitle">Comentarios</h3>
                    <p class="text-[11px] text-slate-400 truncate">Colaboración y notas de seguimiento de la tarea.</p>
                </div>
            </div>
            <button onclick="closeModal('commentsModal')" class="text-slate-400 hover:text-slate-600 dark:hover:text-white transition shrink-0 p-1"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>

        <div id="commentsList" class="p-3.5 sm:p-5 overflow-y-auto flex-1 space-y-3 min-h-[140px]">
            <div class="text-center py-8 text-slate-400 dark:text-slate-500 text-xs">Cargando comentarios...</div>
        </div>

        <form id="commentForm" onsubmit="submitComment(event)" class="p-3 sm:p-3.5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/60 flex flex-col sm:flex-row gap-2 sm:items-end shrink-0">
            <input type="hidden" id="comment_task_id" value="">
            <div class="w-full sm:flex-1">
                <textarea id="comment_input" rows="2" required placeholder="Escribe un comentario..." class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"></textarea>
            </div>
            <button type="submit" id="btnSubmitComment" class="w-full sm:w-auto px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl transition flex items-center justify-center gap-1 shrink-0 shadow-xs">
                <span>Comentar</span>
                <i data-lucide="send" class="w-3.5 h-3.5"></i>
            </button>
        </form>
    </div>
</div>

@endsection

@push('scripts')
<script>
    // Utilidad centralizada para obtener la fecha actual en la zona horaria de Bolivia (America/La_Paz)
    function getBoliviaTodayString() {
        try {
            const parts = new Intl.DateTimeFormat('en-US', {
                timeZone: 'America/La_Paz',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            }).formatToParts(new Date());
            const y = parts.find(p => p.type === 'year')?.value;
            const m = parts.find(p => p.type === 'month')?.value;
            const d = parts.find(p => p.type === 'day')?.value;
            if (y && m && d) return `${y}-${m}-${d}`;
        } catch (e) {}
        const local = new Date();
        const y = local.getFullYear();
        const m = String(local.getMonth() + 1).padStart(2, '0');
        const d = String(local.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }

    function initSidebarState() {
        if (window.innerWidth >= 768) {
            const sidebar = document.getElementById('sidebar');
            if (!sidebar) return;
            const saved = localStorage.getItem('sidebar_collapsed') ?? localStorage.getItem('sidebarCollapsed');
            if (saved === 'false') {
                sidebar.classList.remove('sidebar-collapsed');
            } else {
                sidebar.classList.add('sidebar-collapsed');
            }
        }
    }
    initSidebarState();

    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const backdrop = document.getElementById('sidebar-backdrop');
        if (!sidebar) return;

        const isDesktop = window.innerWidth >= 768;

        if (isDesktop) {
            // Modo Escritorio: Colapsar / Desplegar liberando espacio
            const isCurrentlyCollapsed = sidebar.classList.contains('sidebar-collapsed');
            if (isCurrentlyCollapsed) {
                sidebar.classList.remove('sidebar-collapsed');
                try {
                    localStorage.setItem('sidebar_collapsed', 'false');
                    localStorage.setItem('sidebarCollapsed', 'false');
                } catch (e) {}
            } else {
                sidebar.classList.add('sidebar-collapsed');
                try {
                    localStorage.setItem('sidebar_collapsed', 'true');
                    localStorage.setItem('sidebarCollapsed', 'true');
                } catch (e) {}
            }

            // Asegurar que el backdrop no quede visible en escritorio
            if (backdrop && !backdrop.classList.contains('hidden')) {
                backdrop.classList.add('hidden');
            }

            // Notificar redimensionamiento para actualizar componentes (FullCalendar, gráficos)
            setTimeout(() => {
                window.dispatchEvent(new Event('resize'));
            }, 310);
        } else {
            // Modo Celular / Tablet: Menú lateral con backdrop (comportamiento modal sin alterar)
            const isClosed = sidebar.classList.contains('-translate-x-full');
            if (isClosed) {
                sidebar.classList.remove('-translate-x-full');
                if (backdrop) backdrop.classList.remove('hidden');
            } else {
                sidebar.classList.add('-translate-x-full');
                if (backdrop) backdrop.classList.add('hidden');
            }
        }
    }

    window.addEventListener('resize', () => {
        if (window.innerWidth >= 768) {
            const backdrop = document.getElementById('sidebar-backdrop');
            if (backdrop && !backdrop.classList.contains('hidden')) {
                backdrop.classList.add('hidden');
            }
            const sidebar = document.getElementById('sidebar');
            if (sidebar) {
                sidebar.classList.remove('-translate-x-full');
                const saved = localStorage.getItem('sidebar_collapsed') ?? localStorage.getItem('sidebarCollapsed');
                if (saved === 'false') {
                    sidebar.classList.remove('sidebar-collapsed');
                } else {
                    sidebar.classList.add('sidebar-collapsed');
                }
            }
        } else {
            const sidebar = document.getElementById('sidebar');
            if (sidebar) {
                const backdrop = document.getElementById('sidebar-backdrop');
                if (!backdrop || backdrop.classList.contains('hidden')) {
                    sidebar.classList.add('-translate-x-full');
                }
            }
        }
    });


    // -------------------------------------------------------------
    // Lista de Tareas: Matriz mensual con checks por fecha
    // -------------------------------------------------------------
    window.userHasFullAccess = {{ $user->hasFullAccess() ? 'true' : 'false' }};
    const matrixInFlight = {};

    async function toggleMatrixCheck(buttonEl, taskId) {
        if (!buttonEl || !taskId) return;
        if (matrixInFlight[taskId] || buttonEl.disabled) return;

        const wasCompleted = buttonEl.getAttribute('data-completed') === 'true';
        const needsReview = buttonEl.getAttribute('data-needs-review') === 'true';
        const isFuture = buttonEl.getAttribute('data-is-future') === 'true';
        const currentStatus = buttonEl.getAttribute('data-status') || '';

        // Bloquear checks de tareas cuya fecha programada todavía no ha llegado
        if (isFuture) {
            showMatrixToast('Esta tarea está programada para una fecha futura y aún no puede marcarse.', 'info');
            return;
        }

        // Si la tarea está en revisión y el usuario no tiene permisos de aprobación, no puede completarla
        if (needsReview && currentStatus === 'en_revision' && !window.userHasFullAccess) {
            showMatrixToast('La tarea está en revisión y requiere aprobación del administrador.', 'info');
            return;
        }

        // Si la tarea ya está finalizada y requiere revisión, solo admin puede desmarcarla
        if (wasCompleted && needsReview && !window.userHasFullAccess) {
            showMatrixToast('Solo un administrador autorizado puede modificar una tarea aprobada.', 'info');
            return;
        }

        matrixInFlight[taskId] = true;
        buttonEl.disabled = true;
        buttonEl.classList.add('pointer-events-none');

        let targetStatus;
        if (wasCompleted) {
            targetStatus = 'no_iniciado';
        } else {
            targetStatus = (needsReview && !window.userHasFullAccess) ? 'en_revision' : 'finalizado';
        }

        const weekBg = buttonEl.getAttribute('data-week-bg') || '';
        const weekPending = buttonEl.getAttribute('data-week-pending') || '';
        const rowId = buttonEl.getAttribute('data-row-id');

        // Optimistic UI update solo cuando cambia a finalizado o a no_iniciado
        if (targetStatus === 'finalizado') {
            buttonEl.setAttribute('data-completed', 'true');
            buttonEl.setAttribute('title', 'Completado (clic para desmarcar)');
            setMatrixButtonVisual(buttonEl, true, weekBg, weekPending);
            updateRowCounter(rowId, true);
            updateGlobalMatrixCounter(true);
        } else if (targetStatus === 'no_iniciado') {
            buttonEl.setAttribute('data-completed', 'false');
            buttonEl.setAttribute('title', 'Pendiente (clic para completar)');
            setMatrixButtonVisual(buttonEl, false, weekBg, weekPending);
            updateRowCounter(rowId, false);
            updateGlobalMatrixCounter(false);
        }

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

        try {
            const response = await fetch(`/tasks/${taskId}/status`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ status: targetStatus })
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                throw new Error(data.error || 'No se pudo actualizar el estado de la tarea.');
            }

            buttonEl.setAttribute('data-status', targetStatus);

            if (targetStatus === 'finalizado') {
                buttonEl.setAttribute('data-completed', 'true');
                buttonEl.setAttribute('title', 'Completado (clic para desmarcar)');
                const actions = document.getElementById(`approval-actions-${taskId}`);
                if (actions) actions.remove();
            } else if (targetStatus === 'en_revision') {
                buttonEl.setAttribute('data-completed', 'false');
                buttonEl.setAttribute('title', 'En revisión: pendiente de aprobación');
                buttonEl.disabled = true;
                buttonEl.classList.add('cursor-not-allowed', 'opacity-75', 'border-dashed', 'border-purple-400', 'dark:border-purple-500', 'bg-purple-50/40', 'dark:bg-purple-950/20', 'text-purple-500');
                buttonEl.classList.remove('cursor-pointer');
                buttonEl.querySelectorAll('i, svg').forEach(el => el.remove());
                const icon = document.createElement('i');
                icon.setAttribute('data-lucide', 'clock');
                icon.className = 'w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2] block';
                buttonEl.appendChild(icon);
                if (window.lucide) lucide.createIcons({ root: buttonEl });
                showMatrixToast('Tarea enviada a revisión. Pendiente de aprobación del administrador.', 'info');
            } else {
                buttonEl.setAttribute('data-completed', 'false');
                buttonEl.setAttribute('title', 'Pendiente (clic para completar)');
            }

        } catch (err) {
            // Revert optimistic UI
            if (targetStatus === 'finalizado') {
                buttonEl.setAttribute('data-completed', 'false');
                buttonEl.setAttribute('title', 'Pendiente (clic para completar)');
                setMatrixButtonVisual(buttonEl, false, weekBg, weekPending);
                updateRowCounter(rowId, false);
                updateGlobalMatrixCounter(false);
            } else if (targetStatus === 'no_iniciado') {
                buttonEl.setAttribute('data-completed', 'true');
                buttonEl.setAttribute('title', 'Completado (clic para desmarcar)');
                setMatrixButtonVisual(buttonEl, true, weekBg, weekPending);
                updateRowCounter(rowId, true);
                updateGlobalMatrixCounter(true);
            }
            showMatrixToast(err.message || 'Error al guardar el cumplimiento.', 'error');
        } finally {
            matrixInFlight[taskId] = false;
            if (buttonEl.getAttribute('data-status') !== 'en_revision' && buttonEl.getAttribute('data-is-future') !== 'true') {
                buttonEl.disabled = false;
                buttonEl.classList.remove('pointer-events-none');
            }
        }
    }

    async function approveMatrixTask(btn, taskId) {
        if (!btn || !taskId) return;
        if (matrixInFlight[taskId]) return;
        matrixInFlight[taskId] = true;

        btn.disabled = true;
        const actionsContainer = document.getElementById(`approval-actions-${taskId}`);
        const checkBtn = document.getElementById(`matrix-btn-${taskId}`);
        const rowId = btn.getAttribute('data-row-id');
        const weekBg = btn.getAttribute('data-week-bg') || '';
        const weekPending = btn.getAttribute('data-week-pending') || '';

        if (actionsContainer) {
            actionsContainer.querySelectorAll('button').forEach(b => b.disabled = true);
        }

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

        try {
            const response = await fetch(`/tasks/${taskId}/status`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ status: 'finalizado' })
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                throw new Error(data.error || 'No se pudo aprobar la tarea.');
            }

            // 1. Quitar botones de aprobación
            if (actionsContainer) {
                actionsContainer.remove();
            }

            // 2. Marcar check como completado y actualizar estado
            if (checkBtn) {
                checkBtn.setAttribute('data-completed', 'true');
                checkBtn.setAttribute('data-status', 'finalizado');
                checkBtn.setAttribute('title', 'Completado (aprobado)');
                checkBtn.disabled = false;
                checkBtn.classList.remove('cursor-not-allowed', 'opacity-75', 'border-dashed', 'border-purple-400', 'dark:border-purple-500', 'bg-purple-50/40', 'dark:bg-purple-950/20', 'text-purple-500');
                checkBtn.classList.add('cursor-pointer');
                setMatrixButtonVisual(checkBtn, true, weekBg, weekPending);
            }

            // 3. Actualizar contadores
            updateRowCounter(rowId, true);
            updateGlobalMatrixCounter(true);

            showMatrixToast('Tarea aprobada y finalizada exitosamente.', 'success');

        } catch (err) {
            if (actionsContainer) {
                actionsContainer.querySelectorAll('button').forEach(b => b.disabled = false);
            }
            showMatrixToast(err.message || 'Error al aprobar la tarea.', 'error');
        } finally {
            matrixInFlight[taskId] = false;
        }
    }

    async function rejectMatrixTask(btn, taskId) {
        if (!btn || !taskId) return;
        if (matrixInFlight[taskId]) return;
        matrixInFlight[taskId] = true;

        btn.disabled = true;
        const actionsContainer = document.getElementById(`approval-actions-${taskId}`);
        const checkBtn = document.getElementById(`matrix-btn-${taskId}`);
        const rowId = btn.getAttribute('data-row-id');
        const weekBg = btn.getAttribute('data-week-bg') || '';
        const weekPending = btn.getAttribute('data-week-pending') || '';

        if (actionsContainer) {
            actionsContainer.querySelectorAll('button').forEach(b => b.disabled = true);
        }

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

        try {
            const response = await fetch(`/tasks/${taskId}/status`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ status: 'rechazado' })
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                throw new Error(data.error || 'No se pudo rechazar la tarea.');
            }

            // 1. Quitar botones de aprobación
            if (actionsContainer) {
                actionsContainer.remove();
            }

            // 2. Mantener check vacío con estado rechazado
            if (checkBtn) {
                checkBtn.setAttribute('data-completed', 'false');
                checkBtn.setAttribute('data-status', 'rechazado');
                checkBtn.setAttribute('title', 'Tarea rechazada');
                checkBtn.disabled = false;
                checkBtn.classList.remove('cursor-not-allowed', 'opacity-75', 'border-dashed', 'border-purple-400', 'dark:border-purple-500', 'bg-purple-50/40', 'dark:bg-purple-950/20', 'text-purple-500');
                checkBtn.classList.add('cursor-pointer');
                setMatrixButtonVisual(checkBtn, false, weekBg, weekPending);
            }

            showMatrixToast('Tarea rechazada. Permanece sin finalizar.', 'info');

        } catch (err) {
            if (actionsContainer) {
                actionsContainer.querySelectorAll('button').forEach(b => b.disabled = false);
            }
            showMatrixToast(err.message || 'Error al rechazar la tarea.', 'error');
        } finally {
            matrixInFlight[taskId] = false;
        }
    }

    function setMatrixButtonVisual(buttonEl, isCompleted, weekBg, weekPending) {
        // Eliminar cualquier icono previo (sean <i> o <svg> generados por Lucide)
        buttonEl.querySelectorAll('i, svg').forEach(el => el.remove());

        const icon = document.createElement('i');
        icon.setAttribute('data-lucide', 'check');
        buttonEl.appendChild(icon);

        const weekBgClasses = weekBg.split(' ').filter(Boolean);
        const weekPendingClasses = weekPending.split(' ').filter(Boolean);

        // Limpiar clases de estado de revisión
        buttonEl.classList.remove('border-dashed', 'border-purple-400', 'dark:border-purple-500', 'bg-purple-50/40', 'dark:bg-purple-950/20', 'text-purple-500');

        if (isCompleted) {
            weekPendingClasses.forEach(c => buttonEl.classList.remove(c));
            buttonEl.classList.remove('text-transparent', 'border-2');
            weekBgClasses.forEach(c => buttonEl.classList.add(c));
            buttonEl.classList.add('border');
            icon.className = 'w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[3] block';
        } else {
            weekBgClasses.forEach(c => buttonEl.classList.remove(c));
            buttonEl.classList.remove('border');
            weekPendingClasses.forEach(c => buttonEl.classList.add(c));
            buttonEl.classList.add('text-transparent', 'border-2');
            icon.className = 'w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[3] hidden';
        }
        if (window.lucide) lucide.createIcons({ root: buttonEl });
    }

    function updateRowCounter(rowId, isNowCompleted) {
        const countEl = document.getElementById(`row-count-${rowId}`);
        const percentEl = document.getElementById(`row-percent-${rowId}`);
        if (!countEl || !percentEl) return;

        const parts = countEl.textContent.trim().split('/');
        if (parts.length !== 2) return;

        let completed = parseInt(parts[0]) || 0;
        const total = parseInt(parts[1]) || 0;

        if (isNowCompleted) {
            completed = Math.min(total, completed + 1);
        } else {
            completed = Math.max(0, completed - 1);
        }

        countEl.textContent = `${completed}/${total}`;
        const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
        percentEl.textContent = `${pct}%`;
    }

    function updateGlobalMatrixCounter(isNowCompleted) {
        const completedEl = document.getElementById('matrix-global-completed');
        const percentEl = document.getElementById('matrix-global-percent');
        const barEl = document.getElementById('matrix-global-bar');
        const scheduledEl = document.getElementById('matrix-global-scheduled');
        if (!completedEl || !scheduledEl) return;

        let completed = parseInt(completedEl.textContent) || 0;
        const total = parseInt(scheduledEl.textContent) || 0;

        if (isNowCompleted) {
            completed = Math.min(total, completed + 1);
        } else {
            completed = Math.max(0, completed - 1);
        }

        completedEl.textContent = completed;
        const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
        if (percentEl) percentEl.textContent = `${pct}%`;
        if (barEl) barEl.style.width = `${pct}%`;
    }

    function filterMatrixRows() {
        const input = document.getElementById('matrixTaskSearch');
        if (!input) return;
        const term = input.value.toLowerCase().trim();
        const rows = document.querySelectorAll('.matrix-task-row');
        let visibleCount = 0;

        rows.forEach(r => {
            const title = (r.getAttribute('data-task-title') || '').toLowerCase();
            if (!term || title.includes(term)) {
                r.classList.remove('hidden');
                visibleCount++;
            } else {
                r.classList.add('hidden');
            }
        });

        const noMatchEl = document.getElementById('matrix-no-search-results');
        if (noMatchEl) {
            if (visibleCount === 0 && term) {
                noMatchEl.classList.remove('hidden');
            } else {
                noMatchEl.classList.add('hidden');
            }
        }
    }

    function showMatrixToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-xs font-semibold transition-all duration-300 transform translate-y-4 opacity-0 ${
            type === 'error'
                ? 'bg-red-600 text-white shadow-red-500/20'
                : 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-slate-900/20'
        }`;
        toast.innerHTML = `
            <i data-lucide="${type === 'error' ? 'alert-circle' : 'check-circle'}" class="w-4 h-4 shrink-0"></i>
            <span>${escapeHtml(message)}</span>
        `;
        document.body.appendChild(toast);
        if (window.lucide) lucide.createIcons({ root: toast });

        requestAnimationFrame(() => {
            toast.classList.remove('translate-y-4', 'opacity-0');
        });

        setTimeout(() => {
            toast.classList.add('opacity-0', 'translate-y-2');
            setTimeout(() => toast.remove(), 300);
        }, 3500);
    }

    function toggleMoreMobileMenu() {
        const menu = document.getElementById('mobile-more-menu');
        if (!menu) return;
        menu.classList.toggle('hidden');
        if (!menu.classList.contains('hidden') && window.lucide) {
            lucide.createIcons();
        }
    }

    function toggleProjectAccordion(projId) {
        const content = document.getElementById('acc-content-' + projId);
        const icon = document.getElementById('acc-icon-' + projId);
        if (content) content.classList.toggle('hidden');
        if (icon) icon.classList.toggle('-rotate-90');
    }

    function openModal(id) {
        if (window.innerWidth < 768) {
            const sidebar = document.getElementById('sidebar');
            const backdrop = document.getElementById('sidebar-backdrop');
            if (sidebar && !sidebar.classList.contains('-translate-x-full')) {
                sidebar.classList.add('-translate-x-full');
            }
            if (backdrop && !backdrop.classList.contains('hidden')) {
                backdrop.classList.add('hidden');
            }
        }
        const el = document.getElementById(id);
        if (el) el.classList.remove('hidden');
    }

    function closeModal(id) {
        const el = document.getElementById(id);
        if (el) el.classList.add('hidden');
        if (id === 'incidentModal') {
            if (typeof resetIncidentModalAttachments === 'function') {
                resetIncidentModalAttachments();
            }
        }
    }

    // ---- End Date Section ----
    function showEndDate() {
        document.getElementById('end-date-toggle-btn').classList.add('hidden');
        document.getElementById('end-date-section').classList.remove('hidden');
        const sDateInput = document.getElementById('task_start_date');
        const eDateInput = document.getElementById('task_end_date');
        if (sDateInput && eDateInput) {
            if (sDateInput.value) {
                eDateInput.min = sDateInput.value;
                if (!eDateInput.value) {
                    eDateInput.value = sDateInput.value;
                }
            }
        }
        if (typeof syncTaskDateConstraints === 'function') {
            syncTaskDateConstraints();
        }
        if (window.lucide) lucide.createIcons();
    }

    function hideEndDate() {
        document.getElementById('end-date-section').classList.add('hidden');
        document.getElementById('end-date-toggle-btn').classList.remove('hidden');
        const eDateInput = document.getElementById('task_end_date');
        const eTimeInput = document.getElementById('task_end_time');
        const sDateInput = document.getElementById('task_start_date');
        if (eDateInput) {
            eDateInput.value = '';
            eDateInput.removeAttribute('min');
        }
        if (eTimeInput) {
            eTimeInput.value = '';
            eTimeInput.removeAttribute('min');
        }
        if (sDateInput) {
            sDateInput.removeAttribute('max');
        }
        if (typeof syncTaskDateConstraints === 'function') {
            syncTaskDateConstraints();
        }
    }

    // ---- Subtask Management ----
    let subtasks = [];

    function renderSubtasks() {
        const list = document.getElementById('subtask-list');
        const inputs = document.getElementById('subtask-inputs');
        const counter = document.getElementById('subtask-counter');

        list.innerHTML = '';
        inputs.innerHTML = '';

        if (subtasks.length === 0) {
            counter.classList.add('hidden');
            return;
        }

        const done = subtasks.filter(s => s.status === 'finalizado').length;
        counter.textContent = done + '/' + subtasks.length;
        counter.classList.remove('hidden');

        subtasks.forEach((st, idx) => {
            const li = document.createElement('li');
            li.className = 'flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5';
            li.innerHTML = `
                <input type="checkbox" ${st.status === 'finalizado' ? 'checked' : ''}
                    onchange="toggleSubtaskStatus(${idx})"
                    class="h-3.5 w-3.5 shrink-0 rounded border-slate-300 dark:border-slate-600 text-indigo-600 accent-indigo-500">
                <span class="flex-1 text-xs truncate ${st.status === 'finalizado' ? 'line-through text-slate-400 dark:text-slate-500' : 'text-slate-700 dark:text-slate-200'}">${escapeHtml(st.title)}</span>
                <button type="button" onclick="removeSubtask(${idx})"
                    class="shrink-0 p-0.5 text-slate-400 hover:text-red-500 rounded transition" title="Eliminar subtarea">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>`;
            list.appendChild(li);

            // Hidden form inputs
            ['title', 'status'].forEach(key => {
                const inp = document.createElement('input');
                inp.type = 'hidden';
                inp.name = `subtasks[${idx}][${key}]`;
                inp.value = key === 'title' ? st.title : st.status;
                inputs.appendChild(inp);
            });
            if (st.id) {
                const idInp = document.createElement('input');
                idInp.type = 'hidden';
                idInp.name = `subtasks[${idx}][id]`;
                idInp.value = st.id;
                inputs.appendChild(idInp);
            }
        });
    }

    function addSubtask() {
        const input = document.getElementById('subtask_input');
        const title = input.value.trim();
        if (!title) return;
        subtasks.push({ title: title, status: 'no_iniciado' });
        input.value = '';
        renderSubtasks();
    }

    function removeSubtask(idx) {
        subtasks.splice(idx, 1);
        renderSubtasks();
    }

    function toggleSubtaskStatus(idx) {
        subtasks[idx].status = subtasks[idx].status === 'finalizado' ? 'no_iniciado' : 'finalizado';
        renderSubtasks();
    }

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    document.addEventListener('DOMContentLoaded', function () {
        const stInput = document.getElementById('subtask_input');
        if (stInput) {
            stInput.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') { e.preventDefault(); addSubtask(); }
            });
        }
    });

    // Current task ID for attachments
    let currentTaskModalId = null;

    // ---- Task Modal ----
    function openTaskModal(task = null, initialStatus = 'no_iniciado', defaultStartDate = null) {
        const form = document.getElementById('taskForm');
        const methodInput = document.getElementById('task_method');
        const titleHeading = document.getElementById('taskModalTitle');
        const btnPerUser = document.getElementById('btnSaveTaskPerUser');

        subtasks = [];
        hideEndDate();

        if (task) {
            currentTaskModalId = task.id;
            if (btnPerUser) btnPerUser.classList.add('hidden');
            form.action = '/tasks/' + task.id;
            methodInput.value = 'PUT';
            titleHeading.textContent = 'Editar Tarea';
            const attSection = document.getElementById('taskAttachmentsSection');
            if (attSection) {
                attSection.classList.remove('hidden');
                loadAttachments('Task', task.id);
            }
            document.getElementById('task_title').value = task.title || '';
            document.getElementById('task_description').value = task.description || '';
            document.getElementById('task_module_id').value = task.module_id || '';
            document.getElementById('task_priority').value = (task.priority === 'urgente' ? 'alta' : (task.priority || 'media'));
            document.getElementById('task_status').value = task.status || 'no_iniciado';
            document.getElementById('task_start_date').value = task.start_date ? String(task.start_date).substring(0, 10) : '';
            document.getElementById('task_start_time').value = task.start_time ? String(task.start_time).substring(0, 5) : '';
            document.getElementById('task_needs_review').checked = !!task.needs_review;

            if (task.end_date) {
                document.getElementById('task_end_date').value = String(task.end_date).substring(0, 10);
                document.getElementById('task_end_time').value = task.end_time ? String(task.end_time).substring(0, 5) : '';
                showEndDate();
            }

            const assignedIds = (task.assigned_users || task.assignedUsers || []).map(u => typeof u === 'object' ? u.id : parseInt(u));
            document.querySelectorAll('.task-user-checkbox').forEach(cb => {
                cb.checked = assignedIds.includes(parseInt(cb.value));
            });

            subtasks = (task.subtasks || []).map(st => ({
                id: st.id,
                title: st.title,
                status: st.status || 'no_iniciado'
            }));
            renderSubtasks();
            if (typeof syncTaskDateConstraints === 'function') syncTaskDateConstraints();

        } else {
            currentTaskModalId = null;
            if (btnPerUser) btnPerUser.classList.remove('hidden');
            form.action = '{{ route('tasks.store') }}';
            methodInput.value = 'POST';
            titleHeading.textContent = 'Nueva Tarea';
            const attSection = document.getElementById('taskAttachmentsSection');
            if (attSection) attSection.classList.add('hidden');
            form.reset();
            document.getElementById('task_status').value = initialStatus || 'no_iniciado';
            const todayStr = getBoliviaTodayString();
            document.getElementById('task_start_date').value = defaultStartDate || todayStr;
            if (typeof syncTaskDateConstraints === 'function') syncTaskDateConstraints();
            renderSubtasks();
        }

        openModal('taskModal');
        if (window.lucide) {
            const taskModalEl = document.getElementById('taskModal');
            if (taskModalEl) {
                lucide.createIcons({ root: taskModalEl });
            } else {
                lucide.createIcons();
            }
        }
    }

    // ---- Task Comments Modal & AJAX (Optimizado + Edición) ----
    let currentCommentTaskId = null;

    function openCommentsModal(taskId, taskTitle) {
        currentCommentTaskId = taskId;
        document.getElementById('comment_task_id').value = taskId;
        document.getElementById('commentsModalTaskTitle').textContent = 'Comentarios: ' + (taskTitle || '');
        document.getElementById('comment_input').value = '';
        
        const listEl = document.getElementById('commentsList');
        listEl.innerHTML = '<div class="text-center py-8 text-slate-400 dark:text-slate-500 text-xs">Cargando comentarios...</div>';
        
        openModal('commentsModal');

        fetch(`/tasks/${taskId}/comments`, {
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                renderComments(data.comments);
            } else {
                listEl.innerHTML = '<div class="text-center py-6 text-red-500 text-xs">Error al cargar comentarios.</div>';
            }
        })
        .catch(err => {
            console.error(err);
            listEl.innerHTML = '<div class="text-center py-6 text-red-500 text-xs">Error de conexión.</div>';
        });
    }

    function renderComments(comments) {
        const listEl = document.getElementById('commentsList');
        if (!comments || comments.length === 0) {
            listEl.innerHTML = '<div id="commentsEmptyPlaceholder" class="text-center py-8 text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center justify-center gap-1.5"><i data-lucide="message-square" class="w-6 h-6 text-slate-300 dark:text-slate-600"></i><span>No hay comentarios aún. ¡Sé el primero en comentar!</span></div>';
            if (window.lucide) lucide.createIcons();
            return;
        }

        listEl.innerHTML = comments.map(c => renderSingleCommentHtml(c)).join('');
        if (window.lucide) lucide.createIcons();
    }

    function renderSingleCommentHtml(c) {
        return `
            <div id="comment-item-${c.id}" class="pt-3 first:pt-0 border-b border-slate-100 dark:border-slate-800 pb-3 last:border-b-0 flex items-start justify-between gap-2.5 sm:gap-3 group">
                <div class="flex items-start gap-2.5 min-w-0 flex-1">
                    <div class="w-7 h-7 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-[10px] flex items-center justify-center shrink-0 border border-indigo-200 dark:border-indigo-800 mt-0.5">
                        ${escapeHtml(c.user_initials || 'U')}
                    </div>
                    <div class="space-y-1 min-w-0 flex-1">
                        <div class="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                            <span class="text-xs font-bold text-slate-800 dark:text-slate-200">${escapeHtml(c.user_name || 'Usuario')}</span>
                            <span class="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-1.5 py-0.2 rounded font-medium">${escapeHtml(c.user_role || '')}</span>
                            <span class="text-[10px] text-slate-400" title="${c.created_at_formatted || ''}">${c.created_at || ''}</span>
                        </div>
                        <div id="comment-body-${c.id}">
                            <p id="comment-text-${c.id}" class="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-line leading-relaxed break-words">${escapeHtml(c.comment)}</p>
                        </div>
                    </div>
                </div>
                <div class="flex items-center gap-1 shrink-0">
                    ${c.can_edit ? `
                        <button type="button" onclick="startEditComment(${c.id})" class="text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition p-1 opacity-100 sm:opacity-0 sm:group-hover:opacity-100" title="Editar comentario">
                            <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                        </button>
                    ` : ''}
                    ${c.can_delete ? `
                        <button type="button" onclick="deleteComment(${c.id})" class="text-slate-400 hover:text-red-600 transition p-1 opacity-100 sm:opacity-0 sm:group-hover:opacity-100" title="Eliminar comentario">
                            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
    }

    function submitComment(e) {
        e.preventDefault();
        const taskId = document.getElementById('comment_task_id').value;
        const input = document.getElementById('comment_input');
        const comment = input.value.trim();
        if (!comment || !taskId) return;

        const btn = document.getElementById('btnSubmitComment');
        btn.disabled = true;

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

        fetch(`/tasks/${taskId}/comments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ comment })
        })
        .then(res => res.json())
        .then(data => {
            btn.disabled = false;
            if (data.success) {
                input.value = '';
                // Remove placeholder if present
                const placeholder = document.getElementById('commentsEmptyPlaceholder');
                if (placeholder) placeholder.remove();

                // Append new comment directly to DOM without re-fetching
                const listEl = document.getElementById('commentsList');
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = renderSingleCommentHtml(data.comment);
                listEl.appendChild(tempDiv.firstElementChild);
                if (window.lucide) lucide.createIcons();

                updateCommentBadge(taskId, data.total_comments);
            } else {
                alert(data.error || 'Error al guardar comentario.');
            }
        })
        .catch(err => {
            btn.disabled = false;
            console.error(err);
            alert('Error de red al publicar comentario.');
        });
    }

    function deleteComment(commentId) {
        openDeleteConfirm({
            title: '¿Eliminar comentario?',
            message: 'El comentario será eliminado y ya no estará visible en esta tarea.',
            confirmText: 'Eliminar comentario',
            isPermanent: false,
            onConfirm: () => {
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

                fetch(`/comments/${commentId}`, {
                    method: 'DELETE',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken,
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const commentItem = document.getElementById(`comment-item-${commentId}`);
                        if (commentItem) commentItem.remove();

                        const listEl = document.getElementById('commentsList');
                        if (listEl && listEl.children.length === 0) {
                            listEl.innerHTML = '<div id="commentsEmptyPlaceholder" class="text-center py-8 text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center justify-center gap-1.5"><i data-lucide="message-square" class="w-6 h-6 text-slate-300 dark:text-slate-600"></i><span>No hay comentarios aún. ¡Sé el primero en comentar!</span></div>';
                            if (window.lucide) lucide.createIcons();
                        }

                        updateCommentBadge(currentCommentTaskId, data.total_comments);
                    } else {
                        alert(data.error || 'No se pudo eliminar el comentario.');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('Error de red al eliminar el comentario.');
                });
            }
        });
    }

    let commentOriginalTexts = {};

    function startEditComment(commentId) {
        const textEl = document.getElementById(`comment-text-${commentId}`);
        const bodyEl = document.getElementById(`comment-body-${commentId}`);
        if (!textEl || !bodyEl) return;

        const originalText = textEl.textContent.trim();
        commentOriginalTexts[commentId] = originalText;

        bodyEl.innerHTML = `
            <div class="space-y-1.5 mt-1">
                <textarea id="edit-textarea-${commentId}" rows="2" class="w-full text-xs p-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">${escapeHtml(originalText)}</textarea>
                <div class="flex items-center gap-1.5 justify-end">
                    <button type="button" onclick="cancelEditComment(${commentId})" class="px-2 py-1 text-[11px] rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-300">Cancelar</button>
                    <button type="button" onclick="saveEditComment(${commentId})" class="px-2.5 py-1 text-[11px] rounded bg-indigo-600 text-white font-semibold hover:bg-indigo-700 shadow-2xs">Guardar</button>
                </div>
            </div>
        `;
    }

    function cancelEditComment(commentId) {
        const bodyEl = document.getElementById(`comment-body-${commentId}`);
        if (!bodyEl) return;
        const originalText = commentOriginalTexts[commentId] || '';
        bodyEl.innerHTML = `<p id="comment-text-${commentId}" class="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-line leading-relaxed break-words">${escapeHtml(originalText)}</p>`;
    }

    function saveEditComment(commentId) {
        const textarea = document.getElementById(`edit-textarea-${commentId}`);
        if (!textarea) return;
        const newComment = textarea.value.trim();
        if (!newComment) return alert('El comentario no puede estar vacío.');

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

        fetch(`/comments/${commentId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ comment: newComment })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                const bodyEl = document.getElementById(`comment-body-${commentId}`);
                if (bodyEl) {
                    bodyEl.innerHTML = `<p id="comment-text-${commentId}" class="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-line leading-relaxed break-words">${escapeHtml(data.comment.comment)}</p>`;
                }
            } else {
                alert(data.error || 'Error al actualizar el comentario.');
            }
        })
        .catch(err => {
            console.error(err);
            alert('Error de red al guardar el comentario.');
        });
    }

    function updateCommentBadge(taskId, count) {
        const listBadge = document.getElementById(`task-comment-count-${taskId}`);
        if (listBadge) {
            listBadge.textContent = count;
            listBadge.className = `text-[11px] font-semibold ${count > 0 ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`;
        }
        const kanbanBadge = document.getElementById(`task-comment-count-kanban-${taskId}`);
        if (kanbanBadge) {
            kanbanBadge.textContent = count;
            kanbanBadge.className = `text-[10px] font-semibold ${count > 0 ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`;
        }
    }

    // ---- HTML5 Drag and Drop for Kanban ----
    function handleDragStart(e, taskId) {
        e.dataTransfer.setData('text/plain', taskId);
        e.dataTransfer.effectAllowed = 'move';
        e.target.classList.add('opacity-40');
        setTimeout(() => e.target.classList.remove('opacity-40'), 0);
    }

    function handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        const col = e.currentTarget;
        col.classList.add('ring-2', 'ring-indigo-400', 'bg-indigo-50/40', 'dark:bg-indigo-950/40');
    }

    function handleDragLeave(e) {
        const col = e.currentTarget;
        col.classList.remove('ring-2', 'ring-indigo-400', 'bg-indigo-50/40', 'dark:bg-indigo-950/40');
    }

    function handleDrop(e, newStatus) {
        e.preventDefault();
        const col = e.currentTarget;
        col.classList.remove('ring-2', 'ring-indigo-400', 'bg-indigo-50/40', 'dark:bg-indigo-950/40');

        const taskId = e.dataTransfer.getData('text/plain');
        if (!taskId) return;

        moveKanbanTask(taskId, newStatus);
    }

    function moveKanbanTask(taskId, newStatus) {
        const card = document.getElementById('kanban-card-' + taskId);
        if (!card) return;

        const originalCol = card.closest('[data-kanban-col]');
        const originalStatus = originalCol ? originalCol.getAttribute('data-kanban-col') : null;
        if (originalStatus === newStatus) return;

        const targetCardsContainer = document.getElementById('kanban-cards-' + newStatus);
        if (!targetCardsContainer) return;

        // Optimistic DOM move
        const originalParent = card.parentNode;
        const originalNextSibling = card.nextSibling;
        targetCardsContainer.appendChild(card);
        updateKanbanColumnCounters();

        const csrfMeta = document.querySelector('meta[name="csrf-token"]');
        const csrfToken = csrfMeta ? csrfMeta.content : '';

        fetch('{{ url('/tasks') }}/' + taskId + '/status', {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken,
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ status: newStatus })
        })
        .then(res => {
            if (!res.ok) {
                return res.json().then(data => { throw new Error(data.error || 'Error actualizando estado'); });
            }
            return res.json();
        })
        .then(data => {
            // Success: update counters cleanly
            updateKanbanColumnCounters();
        })
        .catch(err => {
            // Revert DOM position on failure
            if (originalParent) {
                if (originalNextSibling) {
                    originalParent.insertBefore(card, originalNextSibling);
                } else {
                    originalParent.appendChild(card);
                }
            }
            updateKanbanColumnCounters();
            alert(err.message || 'No se pudo mover la tarea');
        });
    }

    function updateKanbanColumnCounters() {
        document.querySelectorAll('[data-kanban-col]').forEach(col => {
            const colId = col.getAttribute('data-kanban-col');
            const container = document.getElementById('kanban-cards-' + colId);
            const counter = document.getElementById('kanban-counter-' + colId);
            const emptyMsg = document.getElementById('kanban-empty-' + colId);
            if (container) {
                const count = container.querySelectorAll('[data-task-id]').length;
                if (counter) counter.textContent = count;
                if (emptyMsg) {
                    if (count === 0) {
                        emptyMsg.classList.remove('hidden');
                    } else {
                        emptyMsg.classList.add('hidden');
                    }
                }
            }
        });
    }

    // Touch Drag support for Mobile Kanban (Punto 6)
    let touchDragTaskId = null;
    let touchDragCard = null;
    let touchStartX = 0;
    let touchStartY = 0;
    let isTouchDragging = false;

    document.addEventListener('touchstart', function (e) {
        const card = e.target.closest('[data-task-id]');
        if (!card) return;
        // Don't drag if touching interactive element inside card
        if (e.target.closest('button, a, input, select, textarea')) return;

        touchDragCard = card;
        touchDragTaskId = card.getAttribute('data-task-id');
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        isTouchDragging = false;
    }, { passive: true });

    document.addEventListener('touchmove', function (e) {
        if (!touchDragCard || !touchDragTaskId) return;

        const currentX = e.touches[0].clientX;
        const currentY = e.touches[0].clientY;
        const deltaX = currentX - touchStartX;
        const deltaY = currentY - touchStartY;

        // If vertical scroll gesture is dominant, cancel card drag to allow native page scroll
        if (!isTouchDragging) {
            if (Math.abs(deltaY) > 12 && Math.abs(deltaY) > Math.abs(deltaX)) {
                touchDragCard = null;
                touchDragTaskId = null;
                return;
            }
            if (Math.abs(deltaX) > 14) {
                isTouchDragging = true;
                touchDragCard.classList.add('opacity-40', 'scale-98');
            }
        }

        if (isTouchDragging) {
            // Highlight column under touch point
            const elemUnder = document.elementFromPoint(currentX, currentY);
            const targetCol = elemUnder ? elemUnder.closest('[data-kanban-col]') : null;
            document.querySelectorAll('[data-kanban-col]').forEach(col => {
                if (col === targetCol) {
                    col.classList.add('ring-2', 'ring-indigo-400', 'bg-indigo-50/40');
                } else {
                    col.classList.remove('ring-2', 'ring-indigo-400', 'bg-indigo-50/40');
                }
            });
        }
    }, { passive: true });

    document.addEventListener('touchend', function (e) {
        if (isTouchDragging && touchDragCard && touchDragTaskId) {
            const touch = e.changedTouches[0];
            const elemUnder = document.elementFromPoint(touch.clientX, touch.clientY);
            const targetCol = elemUnder ? elemUnder.closest('[data-kanban-col]') : null;
            if (targetCol) {
                const newStatus = targetCol.getAttribute('data-kanban-col');
                if (newStatus) {
                    moveKanbanTask(touchDragTaskId, newStatus);
                }
            }
        }

        if (touchDragCard) {
            touchDragCard.classList.remove('opacity-40', 'scale-98');
        }
        document.querySelectorAll('[data-kanban-col]').forEach(col => {
            col.classList.remove('ring-2', 'ring-indigo-400', 'bg-indigo-50/40');
        });

        touchDragCard = null;
        touchDragTaskId = null;
        isTouchDragging = false;
    });

    // ---- Project Link Management ----
    const allUsersList = @json($allUsers->map(fn($u) => ['id' => $u->id, 'name' => $u->name, 'role' => $u->role]));
    let projectLinks = [];
    let editingLinkIndex = null;

    function renderProjectLinks() {
        const listContainer = document.getElementById('project-links-list');
        const hiddenInputsContainer = document.getElementById('project-links-hidden-inputs');
        if (!listContainer || !hiddenInputsContainer) return;

        listContainer.innerHTML = '';
        hiddenInputsContainer.innerHTML = '';

        if (projectLinks.length === 0) {
            listContainer.innerHTML = '<p class="text-xs text-slate-400 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 italic">Aún no hay enlaces agregados.</p>';
            return;
        }

        const selectedMemberIds = Array.from(document.querySelectorAll('.proj-user-checkbox:checked')).map(cb => parseInt(cb.value));

        projectLinks.forEach((link, idx) => {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2.5 bg-slate-50 dark:bg-slate-800/60 space-y-2';

            if (editingLinkIndex === idx) {
                const editFormDiv = document.createElement('div');
                editFormDiv.className = 'space-y-2';
                editFormDiv.innerHTML = `
                    <div class="flex items-center justify-between pb-1 border-b border-slate-200 dark:border-slate-700">
                        <span class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1">
                            <i data-lucide="pencil" class="w-3 h-3"></i>
                            Editar Enlace
                        </span>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                            <label class="block text-[10px] font-semibold text-slate-600 dark:text-slate-400 mb-0.5">Nombre del enlace</label>
                            <input type="text" id="edit_link_name_${idx}" value="${escapeHtml(link.name)}"
                                class="w-full px-2.5 py-1 border border-slate-300 dark:border-slate-600 rounded-lg text-xs bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                        </div>
                        <div>
                            <label class="block text-[10px] font-semibold text-slate-600 dark:text-slate-400 mb-0.5">URL del enlace</label>
                            <input type="text" id="edit_link_url_${idx}" value="${escapeHtml(link.url)}"
                                class="w-full px-2.5 py-1 border border-slate-300 dark:border-slate-600 rounded-lg text-xs bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                        </div>
                    </div>
                    <div class="flex justify-end gap-1.5 pt-1">
                        <button type="button" onclick="cancelProjectLinkEdit()" class="px-2.5 py-1 text-[11px] font-medium text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg">
                            Cancelar
                        </button>
                        <button type="button" onclick="saveProjectLinkEdit(${idx})" class="px-2.5 py-1 text-[11px] font-semibold text-white bg-[#0f172a] hover:bg-slate-800 rounded-lg flex items-center gap-1">
                            <i data-lucide="check" class="w-3 h-3"></i>
                            <span>Guardar</span>
                        </button>
                    </div>
                `;
                itemDiv.appendChild(editFormDiv);
            } else {
                const topRow = document.createElement('div');
                topRow.className = 'flex items-start justify-between gap-2';

                const infoDiv = document.createElement('div');
                infoDiv.className = 'min-w-0 flex items-start gap-2 flex-1';
                infoDiv.innerHTML = `
                    <i data-lucide="link" class="w-3.5 h-3.5 text-[#0f172a] dark:text-slate-400 shrink-0 mt-0.5"></i>
                    <div class="min-w-0 flex-1">
                        <span class="text-xs font-bold text-slate-800 dark:text-slate-200 break-words block leading-snug">${escapeHtml(link.name)}</span>
                        <a href="${escapeHtml(link.url)}" target="_blank" class="text-[11px] text-blue-600 dark:text-blue-400 hover:underline break-all block mt-0.5">${escapeHtml(link.url)}</a>
                    </div>
                `;

                const actionBtnsDiv = document.createElement('div');
                actionBtnsDiv.className = 'flex items-center gap-1 shrink-0';

                const editBtn = document.createElement('button');
                editBtn.type = 'button';
                editBtn.className = 'p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition';
                editBtn.title = 'Editar enlace';
                editBtn.innerHTML = '<i data-lucide="pencil" class="w-3.5 h-3.5"></i>';
                editBtn.onclick = () => startProjectLinkEdit(idx);

                const deleteBtn = document.createElement('button');
                deleteBtn.type = 'button';
                deleteBtn.className = 'p-1 text-slate-400 hover:text-red-600 rounded-lg transition';
                deleteBtn.title = 'Eliminar enlace';
                deleteBtn.innerHTML = '<i data-lucide="trash-2" class="w-3.5 h-3.5"></i>';
                deleteBtn.onclick = () => removeProjectLink(idx);

                actionBtnsDiv.appendChild(editBtn);
                actionBtnsDiv.appendChild(deleteBtn);

                topRow.appendChild(infoDiv);
                topRow.appendChild(actionBtnsDiv);
                itemDiv.appendChild(topRow);
            }

            const assignables = allUsersList.filter(u => selectedMemberIds.length === 0 || selectedMemberIds.includes(u.id));
            if (assignables.length > 0) {
                const assigneesDiv = document.createElement('div');
                assigneesDiv.className = 'flex flex-wrap items-center gap-1 pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60';

                const label = document.createElement('span');
                label.className = 'text-[10px] font-semibold text-slate-400 mr-1';
                label.textContent = 'Asignar a:';
                assigneesDiv.appendChild(label);

                assignables.forEach(u => {
                    const isAssigned = (link.assigned_user_ids || []).includes(u.id);
                    const btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = `text-[10px] px-2 py-0.5 rounded-full border transition font-medium ${
                        isAssigned
                            ? 'bg-indigo-600 border-indigo-600 text-white shadow-xs'
                            : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-indigo-400'
                    }`;
                    btn.textContent = u.name;
                    btn.onclick = () => toggleLinkAssignee(idx, u.id);
                    assigneesDiv.appendChild(btn);
                });
                itemDiv.appendChild(assigneesDiv);
            }

            listContainer.appendChild(itemDiv);

            // Hidden form inputs
            const nameInp = document.createElement('input');
            nameInp.type = 'hidden';
            nameInp.name = `links[${idx}][name]`;
            nameInp.value = link.name;
            hiddenInputsContainer.appendChild(nameInp);

            const urlInp = document.createElement('input');
            urlInp.type = 'hidden';
            urlInp.name = `links[${idx}][url]`;
            urlInp.value = link.url;
            hiddenInputsContainer.appendChild(urlInp);

            (link.assigned_user_ids || []).forEach(uId => {
                const assignInp = document.createElement('input');
                assignInp.type = 'hidden';
                assignInp.name = `links[${idx}][assigned_user_ids][]`;
                assignInp.value = uId;
                hiddenInputsContainer.appendChild(assignInp);
            });
        });

        if (window.lucide) lucide.createIcons();
    }

    function startProjectLinkEdit(idx) {
        editingLinkIndex = idx;
        renderProjectLinks();
    }

    function cancelProjectLinkEdit() {
        editingLinkIndex = null;
        renderProjectLinks();
    }

    function saveProjectLinkEdit(idx) {
        const nameInp = document.getElementById(`edit_link_name_${idx}`);
        const urlInp = document.getElementById(`edit_link_url_${idx}`);
        if (!nameInp || !urlInp) return;

        const name = nameInp.value.trim();
        let url = urlInp.value.trim();

        if (!name || !url) {
            alert('Por favor, ingresa un nombre y una URL válidos.');
            return;
        }

        if (!/^https?:\/\//i.test(url)) {
            url = 'https://' + url;
        }

        projectLinks[idx].name = name;
        projectLinks[idx].url = url;
        editingLinkIndex = null;
        renderProjectLinks();
    }

    function addProjectLink() {
        const nameInp = document.getElementById('link_name_input');
        const urlInp = document.getElementById('link_url_input');
        const name = nameInp ? nameInp.value.trim() : '';
        let url = urlInp ? urlInp.value.trim() : '';

        if (!name || !url) return;

        if (!/^https?:\/\//i.test(url)) {
            url = 'https://' + url;
        }

        projectLinks.push({
            name: name,
            url: url,
            assigned_user_ids: []
        });

        if (nameInp) nameInp.value = '';
        if (urlInp) urlInp.value = '';
        renderProjectLinks();
    }

    function removeProjectLink(idx) {
        projectLinks.splice(idx, 1);
        if (editingLinkIndex === idx) {
            editingLinkIndex = null;
        } else if (editingLinkIndex > idx) {
            editingLinkIndex--;
        }
        renderProjectLinks();
    }

    function toggleLinkAssignee(linkIdx, userId) {
        if (!projectLinks[linkIdx].assigned_user_ids) {
            projectLinks[linkIdx].assigned_user_ids = [];
        }
        const arr = projectLinks[linkIdx].assigned_user_ids;
        const pos = arr.indexOf(userId);
        if (pos >= 0) {
            arr.splice(pos, 1);
        } else {
            arr.push(userId);
        }
        renderProjectLinks();
    }

    function openProjectModal(project = null) {
        const form = document.getElementById('projectForm');
        const methodInput = document.getElementById('project_method');
        const titleHeading = document.getElementById('projectModalTitle');
        editingLinkIndex = null;

        if (document.getElementById('link_name_input')) document.getElementById('link_name_input').value = '';
        if (document.getElementById('link_url_input')) document.getElementById('link_url_input').value = '';

        if (project) {
            form.action = '/projects/' + project.id;
            methodInput.value = 'PUT';
            titleHeading.textContent = 'Editar Proyecto';
            document.getElementById('project_name').value = project.name;
            const memberIds = (project.members || []).map(u => u.id);
            document.querySelectorAll('.proj-user-checkbox').forEach(cb => {
                cb.checked = memberIds.includes(parseInt(cb.value));
            });

            projectLinks = (project.links || []).map(l => ({
                name: l.name,
                url: l.url,
                assigned_user_ids: (l.assigned_users || l.assignedUsers || []).map(u => typeof u === 'object' ? u.id : parseInt(u))
            }));
        } else {
            form.action = '{{ route('projects.store') }}';
            methodInput.value = 'POST';
            titleHeading.textContent = 'Nuevo Proyecto';
            form.reset();
            projectLinks = [];
        }
        renderProjectLinks();
        openModal('projectModal');
        if (window.lucide) lucide.createIcons();
    }

    function openModuleModal(projectId, module = null) {
        const form = document.getElementById('moduleForm');
        const methodInput = document.getElementById('module_method');
        const titleHeading = document.getElementById('moduleModalTitle');
        document.getElementById('module_project_id').value = projectId;

        if (module) {
            form.action = '/modules/' + module.id;
            methodInput.value = 'PUT';
            titleHeading.textContent = 'Editar Módulo';
            document.getElementById('module_name').value = module.name;
        } else {
            form.action = '{{ route('modules.store') }}';
            methodInput.value = 'POST';
            titleHeading.textContent = 'Nuevo Módulo';
            document.getElementById('module_name').value = '';
        }
        openModal('moduleModal');
    }


    function openUsersListModal() {
        resetUserForm();
        openModal('usersListModal');
    }

    function editUserInModal(user) {
        const form = document.getElementById('userForm');
        const methodInput = document.getElementById('user_method');
        const titleHeading = document.getElementById('userFormTitle');
        const submitBtn = document.getElementById('btnSubmitUser');
        const cancelBtn = document.getElementById('btnCancelUserEdit');
        const pwdInput = document.getElementById('user_password');

        if (!form) return;

        form.action = '/users/' + user.id;
        methodInput.value = 'PUT';
        titleHeading.textContent = 'Actualizar Usuario';
        submitBtn.textContent = 'Actualizar Usuario';
        if (cancelBtn) cancelBtn.classList.remove('hidden');

        document.getElementById('user_name').value = user.name || '';
        document.getElementById('user_email').value = user.email || '';
        document.getElementById('user_role').value = user.role || 'Admin';

        pwdInput.removeAttribute('required');
        pwdInput.value = '';
        pwdInput.placeholder = 'Nueva contraseña (opcional)';

        if (window.lucide) lucide.createIcons();
    }

    function toggleUserPassword(userId) {
        const span = document.getElementById('user-clave-' + userId);
        const iconSpan = document.getElementById('user-clave-icon-' + userId);
        if (!span) return;

        const realClave = span.getAttribute('data-clave') || '';
        const isVisible = span.getAttribute('data-visible') === 'true';

        if (isVisible) {
            span.textContent = realClave ? '••••••••' : '(sin clave)';
            span.setAttribute('data-visible', 'false');
            if (iconSpan) iconSpan.innerHTML = '<i data-lucide="eye" class="w-3 h-3"></i>';
        } else {
            span.textContent = realClave;
            span.setAttribute('data-visible', 'true');
            if (iconSpan) iconSpan.innerHTML = '<i data-lucide="eye-off" class="w-3 h-3"></i>';
        }

        if (window.lucide) lucide.createIcons();
    }

    function resetUserForm() {
        const form = document.getElementById('userForm');
        const methodInput = document.getElementById('user_method');
        const titleHeading = document.getElementById('userFormTitle');
        const submitBtn = document.getElementById('btnSubmitUser');
        const cancelBtn = document.getElementById('btnCancelUserEdit');
        const pwdInput = document.getElementById('user_password');

        if (!form) return;

        form.action = '{{ route('users.store') }}';
        methodInput.value = 'POST';
        titleHeading.textContent = 'Agregar Nuevo Usuario';
        submitBtn.textContent = 'Crear Usuario';
        if (cancelBtn) cancelBtn.classList.add('hidden');

        form.reset();
        pwdInput.setAttribute('required', 'required');
        pwdInput.placeholder = 'Contraseña';
    }

    // ---- Recurring Task Modal ----
    let recSubtasks = [];

    function renderRecSubtasks() {
        const list = document.getElementById('rec-subtask-list');
        const inputs = document.getElementById('rec-subtask-inputs');
        if (!list || !inputs) return;
        list.innerHTML = '';
        inputs.innerHTML = '';

        recSubtasks.forEach((st, idx) => {
            const li = document.createElement('li');
            li.className = 'flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5';
            li.innerHTML = `
                <span class="flex-1 text-xs text-slate-700 dark:text-slate-300 truncate">${escapeHtml(st.title)}</span>
                <button type="button" onclick="removeRecSubtask(${idx})" class="text-slate-400 hover:text-red-500">
                    <i data-lucide="x" class="w-3 h-3"></i>
                </button>`;
            list.appendChild(li);

            const inp = document.createElement('input');
            inp.type = 'hidden';
            inp.name = `subtasks[${idx}][title]`;
            inp.value = st.title;
            inputs.appendChild(inp);
        });
        if (window.lucide) lucide.createIcons();
    }

    function addRecSubtask() {
        const input = document.getElementById('rec_subtask_input');
        const val = input.value.trim();
        if (val) {
            recSubtasks.push({ title: val });
            input.value = '';
            renderRecSubtasks();
        }
    }

    function removeRecSubtask(idx) {
        recSubtasks.splice(idx, 1);
        renderRecSubtasks();
    }

    function openRecurringTaskModal(rule = null) {
        const form = document.getElementById('recurringTaskForm');
        const methodInput = document.getElementById('recurring_task_method');
        const titleHeading = document.getElementById('recurringTaskModalTitle');

        recSubtasks = [];

        if (rule) {
            form.action = '/recurring-tasks/' + rule.id;
            methodInput.value = 'PUT';
            titleHeading.innerHTML = '<i data-lucide="pencil" class="w-5 h-5 text-indigo-600 dark:text-indigo-400"></i><span>Editar Tarea Periódica</span>';
            document.getElementById('rec_title').value = rule.title || '';
            document.getElementById('rec_description').value = rule.description || '';
            document.getElementById('rec_recurrence').value = rule.recurrence || 'diaria';
            document.getElementById('rec_priority').value = (rule.priority === 'urgente' ? 'alta' : (rule.priority || 'media'));
            document.getElementById('rec_module_id').value = rule.module_id || '';
            document.getElementById('rec_start_date').value = rule.start_date ? String(rule.start_date).substring(0, 10) : '';
            document.getElementById('rec_start_time').value = rule.start_time ? String(rule.start_time).substring(0, 5) : '';
            document.getElementById('rec_end_time').value = rule.end_time ? String(rule.end_time).substring(0, 5) : '';
            document.getElementById('rec_needs_review').checked = !!rule.needs_review;

            const assignedIds = (rule.assigned_users || rule.assignedUsers || []).map(u => typeof u === 'object' ? u.id : parseInt(u));
            document.querySelectorAll('.rec-user-checkbox').forEach(cb => {
                cb.checked = assignedIds.includes(parseInt(cb.value));
            });

            recSubtasks = (rule.subtasks || []).map(st => ({ title: st.title }));
            renderRecSubtasks();
            if (typeof syncRecurringTaskDateConstraints === 'function') syncRecurringTaskDateConstraints();
        } else {
            form.action = '{{ route('recurring-tasks.store') }}';
            methodInput.value = 'POST';
            titleHeading.innerHTML = '<i data-lucide="repeat" class="w-5 h-5 text-indigo-600 dark:text-indigo-400"></i><span>Nueva Tarea Periódica</span>';
            form.reset();
            document.getElementById('rec_start_date').value = getBoliviaTodayString();
            if (typeof syncRecurringTaskDateConstraints === 'function') syncRecurringTaskDateConstraints();
            renderRecSubtasks();
        }

        openModal('recurringTaskModal');
        if (window.lucide) lucide.createIcons();
    }

    // Map of all tasks for quick access by ID from calendar events
    const allTasksMap = {
        @foreach($tasks as $t)
            '{{ $t->id }}': @json($t->load(['assignedUsers', 'subtasks'])),
        @endforeach
    };

    // Control de modo de vista del Calendario (Ancho completo vs Dividido con Lista de Tareas)
    function isCalendarSplitMode() {
        try {
            const saved = localStorage.getItem('calendarCollapsed') ?? localStorage.getItem('calendar_collapsed');
            return saved === 'true';
        } catch (e) {
            return false;
        }
    }

    function setCalendarSplitMode(split) {
        try {
            localStorage.setItem('calendarCollapsed', split ? 'true' : 'false');
            localStorage.setItem('calendar_collapsed', split ? 'true' : 'false');
        } catch (e) {}

        applyCalendarViewMode(split);
    }

    function toggleCalendarSplitView() {
        const isSplit = isCalendarSplitMode();
        setCalendarSplitMode(!isSplit);
    }

    function applyCalendarViewMode(split) {
        const cal = document.getElementById('cal-view-calendar');
        const list = document.getElementById('cal-view-list');
        const btnText = document.getElementById('btn-toggle-calendar-text');
        const btnIcon = document.getElementById('btn-toggle-calendar-icon');
        const btnToggle = document.getElementById('btn-toggle-calendar-split');

        if (split) {
            document.documentElement.classList.add('cal-split-active');
            if (cal) {
                cal.classList.add('lg:w-7/12');
                cal.classList.remove('cal-view-full');
            }
            if (list) {
                list.classList.remove('lg:hidden');
            }
            if (btnText) btnText.textContent = 'Expandir';
            if (btnToggle) btnToggle.title = 'Expandir calendario a pantalla completa';
            if (btnIcon) btnIcon.setAttribute('data-lucide', 'maximize-2');
        } else {
            document.documentElement.classList.remove('cal-split-active');
            if (cal) {
                cal.classList.remove('lg:w-7/12');
                cal.classList.add('cal-view-full');
            }
            if (list) {
                list.classList.add('lg:hidden');
                list.style.height = '';
                list.style.maxHeight = '';
            }
            if (btnText) btnText.textContent = 'Contraer';
            if (btnToggle) btnToggle.title = 'Contraer calendario para mostrar lista de tareas';
            if (btnIcon) btnIcon.setAttribute('data-lucide', 'columns-2');
        }

        if (window.lucide) {
            lucide.createIcons();
        }

        // Forzar reflow sincrónico en cal para asegurar que el navegador aplique los estilos de layout inmediatamente
        if (cal) void cal.offsetWidth;

        const refreshCalendar = () => {
            if (window.calendarInstance) {
                if (split) {
                    window.calendarInstance.setOption('aspectRatio', 1.35);
                } else {
                    window.calendarInstance.setOption('aspectRatio', window.innerWidth >= 1280 ? 1.25 : 1.18);
                }
                window.calendarInstance.updateSize();
                window.calendarInstance.render();
            }

            if (split) {
                syncCalendarListHeight();
            }
        };

        // Recalcular y renderizar inmediatamente
        refreshCalendar();

        // Y en el siguiente ciclo de renderizado para garantizar dimensiones finales completas
        requestAnimationFrame(() => {
            refreshCalendar();
        });
    }

    // Helper para convertir HEX a RGBA con opacidad personalizada
    function hexToRgba(hex, alpha) {
        if (!hex || typeof hex !== 'string') return `rgba(100, 116, 139, ${alpha !== undefined ? alpha : 0.12})`;
        let clean = hex.trim().replace('#', '');
        if (clean.length === 3) {
            clean = clean.split('').map(c => c + c).join('');
        }
        if (clean.length !== 6) return `rgba(100, 116, 139, ${alpha !== undefined ? alpha : 0.12})`;
        const r = parseInt(clean.substring(0, 2), 16);
        const g = parseInt(clean.substring(2, 4), 16);
        const b = parseInt(clean.substring(4, 6), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha !== undefined ? alpha : 0.12})`;
    }

    // Eventos de calendario procesados (excluyendo tareas periódicas diarias)
    const allCalendarEvents = [
        @foreach($tasks as $t)
            @if($t->start_date && !$t->isDailyRecurring())
                @php
                    $statusKey = $t->status ?? 'no_iniciado';
                    $calEventColor = $estadoColores[$statusKey] ?? '#64748b';
                    if ($statusKey === 'no_iniciado' && $t->isOverdue()) {
                        $calEventColor = '#ef4444';
                    }

                    $prioRaw = strtolower(trim($t->priority ?? 'media'));
                    if ($prioRaw === 'urgente') { $prioRaw = 'alta'; }
                    if (!in_array($prioRaw, ['baja', 'media', 'alta'])) {
                        $prioRaw = 'media';
                    }
                    $prioColor = $prioridadColores[$prioRaw] ?? '#f59e0b';
                    $prioLabel = $prioridadNombres[$prioRaw] ?? ucfirst($prioRaw);

                    $recRaw = strtolower(trim($t->recurrence ?? ''));
                    $isPeriodic = !empty($recRaw) && $recRaw !== 'ninguna' && in_array($recRaw, ['diaria', 'semanal', 'mensual', 'anual']);
                    $recColor = $isPeriodic ? ($periodicidadColores[$recRaw] ?? '#3b82f6') : '';
                    $recLabel = $isPeriodic ? ($periodicidadNombres[$recRaw] ?? ucfirst($recRaw)) : '';

                    $assignedIds = $t->assignedUsers->pluck('id')->all();
                @endphp
                {
                    id: '{{ $t->id }}',
                    title: @json($t->title),
                    start: '{{ \Carbon\Carbon::parse($t->start_date)->format('Y-m-d') }}',
                    allDay: true,
                    backgroundColor: 'transparent',
                    borderColor: 'transparent',
                    extendedProps: {
                        status: '{{ $statusKey }}',
                        statusColor: '{{ $calEventColor }}',
                        priority: '{{ $prioRaw }}',
                        priorityLabel: '{{ $prioLabel }}',
                        priorityColor: '{{ $prioColor }}',
                        isPeriodic: {{ $isPeriodic ? 'true' : 'false' }},
                        recurrence: '{{ $recRaw }}',
                        recurrenceLabel: '{{ $recLabel }}',
                        recurrenceColor: '{{ $recColor }}',
                        assignedUserIds: @json($assignedIds)
                    }
                },
            @endif
        @endforeach
    ];

    let currentFilteredUserId = '{{ $selectedUserId ?? '' }}';
    let currentUnifiedFilter = '{{ $taskFilterOption ?? '' }}';
    let currentSearchTerm = '{{ addslashes($taskSearch ?? '') }}'.toLowerCase();

    window.onResumenUserFilterChange = function(userId) {
        const url = new URL(window.location.href);
        if (userId && userId !== 'all') {
            url.searchParams.set('user_id', userId);
        } else {
            url.searchParams.set('user_id', 'all');
        }
        const statusSelect = document.getElementById('resumen-all-tasks-status-filter');
        if (statusSelect && statusSelect.value && statusSelect.value !== 'all') {
            url.searchParams.set('task_status', statusSelect.value);
        }
        const periodicSelect = document.getElementById('resumen-periodic-period-filter');
        if (periodicSelect && periodicSelect.value && periodicSelect.value !== 'hoy') {
            url.searchParams.set('periodic_period', periodicSelect.value);
        } else {
            url.searchParams.delete('periodic_period');
        }
        url.searchParams.set('view', 'resumen');
        window.location.href = url.toString();
    };

    window.changePeriodicPeriod = function(period) {
        const listHoy = document.getElementById('periodic-tasks-list-hoy');
        const listMes = document.getElementById('periodic-tasks-list-mes');
        const listAnio = document.getElementById('periodic-tasks-list-anio');
        const badge = document.getElementById('periodic-tasks-count-badge');
        const select = document.getElementById('resumen-periodic-period-filter');
        const calBtn = document.getElementById('resumen-periodic-calendar-btn');

        if (!listHoy || !listMes || !listAnio) return;

        listHoy.classList.add('hidden');
        listMes.classList.add('hidden');
        listAnio.classList.add('hidden');

        let count = 0;
        if (period === 'mes') {
            listMes.classList.remove('hidden');
            count = listMes.querySelectorAll('.periodic-task-item').length;
            if (calBtn) {
                calBtn.className = 'w-7 h-7 sm:w-8 sm:h-8 rounded-xl border bg-emerald-50 text-emerald-600 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-400 dark:border-emerald-700 flex items-center justify-center transition shadow-2xs cursor-pointer';
            }
        } else if (period === 'anio') {
            listAnio.classList.remove('hidden');
            count = listAnio.querySelectorAll('.periodic-task-item').length;
            if (calBtn) {
                calBtn.className = 'w-7 h-7 sm:w-8 sm:h-8 rounded-xl border bg-slate-50 text-slate-600 border-slate-200/80 hover:bg-emerald-50 hover:text-emerald-600 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 dark:hover:bg-emerald-950/50 dark:hover:text-emerald-400 flex items-center justify-center transition shadow-2xs cursor-pointer';
            }
        } else {
            period = 'hoy';
            listHoy.classList.remove('hidden');
            count = listHoy.querySelectorAll('.periodic-task-item').length;
            if (calBtn) {
                calBtn.className = 'w-7 h-7 sm:w-8 sm:h-8 rounded-xl border bg-slate-50 text-slate-600 border-slate-200/80 hover:bg-emerald-50 hover:text-emerald-600 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 dark:hover:bg-emerald-950/50 dark:hover:text-emerald-400 flex items-center justify-center transition shadow-2xs cursor-pointer';
            }
        }

        if (select) {
            select.value = period;
        }
        if (badge) {
            badge.textContent = count;
        }
        const subnavCounter = document.getElementById('subnav-periodicas-counter');
        if (subnavCounter) {
            subnavCounter.textContent = count;
        }

        try {
            const url = new URL(window.location.href);
            if (period && period !== 'hoy') {
                url.searchParams.set('periodic_period', period);
            } else {
                url.searchParams.delete('periodic_period');
            }
            window.history.replaceState({}, '', url.toString());
        } catch(e) {}
    };

    window.onPeriodicCalendarIconClick = function() {
        const select = document.getElementById('resumen-periodic-period-filter');
        const current = select ? select.value : 'hoy';
        if (current === 'mes') {
            changePeriodicPeriod('hoy');
        } else {
            changePeriodicPeriod('mes');
        }
    };

    window.filterAllTasksByStatus = function(selectedStatus) {
        const items = document.querySelectorAll('.all-tasks-item');
        const emptyMsg = document.getElementById('all-tasks-empty-filter-msg');
        let visibleCount = 0;

        items.forEach(item => {
            const itemStatus = item.getAttribute('data-status');
            const itemOverdue = item.getAttribute('data-overdue') === '1';

            let matches = false;
            if (!selectedStatus || selectedStatus === 'all') {
                matches = true;
            } else if (selectedStatus === 'vencida') {
                matches = itemOverdue;
            } else {
                matches = (itemStatus === selectedStatus);
            }

            if (matches) {
                item.classList.remove('hidden');
                visibleCount++;
            } else {
                item.classList.add('hidden');
            }
        });

        if (emptyMsg) {
            if (visibleCount === 0 && items.length > 0) {
                emptyMsg.classList.remove('hidden');
            } else {
                emptyMsg.classList.add('hidden');
            }
        }

        const countBadge = document.getElementById('all-tasks-count-badge');
        if (countBadge) {
            countBadge.textContent = visibleCount;
        }

        try {
            const url = new URL(window.location.href);
            if (selectedStatus && selectedStatus !== 'all') {
                url.searchParams.set('task_status', selectedStatus);
            } else {
                url.searchParams.delete('task_status');
            }
            window.history.replaceState({}, '', url.toString());
        } catch(e) {}
    };

    function getFilteredEvents(userId) {
        if (!userId) return allCalendarEvents;
        const uid = Number(userId);
        return allCalendarEvents.filter(e => {
            const uids = (e.extendedProps && e.extendedProps.assignedUserIds) ? e.extendedProps.assignedUserIds.map(Number) : [];
            return uids.includes(uid);
        });
    }

    const todayTasksMeta = {!! json_encode($todayTasks->map(fn($t) => [
        'id' => $t->id,
        'title' => mb_strtolower($t->title ?? ''),
        'users' => $t->assignedUsers->pluck('id')->all(),
        'status' => $t->status,
        'priority' => strtolower(trim($t->priority === 'urgente' ? 'alta' : ($t->priority ?? 'media'))),
        'overdue' => $t->isOverdue() ? 1 : 0
    ])->values()->all()) !!};
    const monthTasksMeta = {!! json_encode($monthTasks->map(fn($t) => [
        'id' => $t->id,
        'title' => mb_strtolower($t->title ?? ''),
        'users' => $t->assignedUsers->pluck('id')->all(),
        'status' => $t->status,
        'priority' => strtolower(trim($t->priority === 'urgente' ? 'alta' : ($t->priority ?? 'media'))),
        'overdue' => $t->isOverdue() ? 1 : 0
    ])->values()->all()) !!};
    const todayTasksUsers = todayTasksMeta;
    const monthTasksUsers = monthTasksMeta;

    function taskMatchesAllFilters(taskMeta, userId, filterOption, searchTerm) {
        if (userId && !taskMeta.users.map(Number).includes(Number(userId))) {
            return false;
        }
        if (searchTerm) {
            const cleanTerm = searchTerm.toLowerCase().trim();
            if (cleanTerm && !taskMeta.title.includes(cleanTerm)) {
                return false;
            }
        }
        if (!filterOption || filterOption === 'status:all' || filterOption === 'priority:all') {
            return true;
        }
        const parts = filterOption.split(':');
        const type = parts[0];
        const val = parts[1] || '';
        if (type === 'status') {
            return val === 'all' || taskMeta.status === val;
        }
        if (type === 'priority') {
            return val === 'all' || taskMeta.priority === val;
        }
        if (type === 'due') {
            if (val === 'vencidas') return taskMeta.overdue === 1;
            if (val === 'no_vencidas') return taskMeta.overdue === 0;
        }
        return true;
    }

    function applyAllTaskFilters() {
        const filterSelect = document.getElementById('task-filter-select');
        const searchInput = document.getElementById('task-search-input');
        const clearSearchBtn = document.getElementById('btn-clear-task-search');

        if (filterSelect) currentUnifiedFilter = filterSelect.value || '';
        if (searchInput) currentSearchTerm = (searchInput.value || '').trim().toLowerCase();

        if (clearSearchBtn) {
            if (searchInput && searchInput.value.length > 0) {
                clearSearchBtn.classList.remove('hidden');
            } else {
                clearSearchBtn.classList.add('hidden');
            }
        }

        const cards = document.querySelectorAll('.task-list-card');
        const emptyMsg = document.getElementById('cal-list-empty-msg');
        const emptyContainer = document.getElementById('cal-list-empty-state') || document.getElementById('cal-list-empty-user');
        const groups = document.querySelectorAll('.task-date-group');
        let visibleCount = 0;

        cards.forEach(card => {
            let assigned = [];
            try {
                assigned = JSON.parse(card.getAttribute('data-assigned-users') || '[]');
            } catch(e) {}

            // 1. Filtro Usuario
            const matchesUser = !currentFilteredUserId || assigned.map(Number).includes(Number(currentFilteredUserId));

            // 2. Buscador por nombre
            const cardTitle = (card.getAttribute('data-title') || '').toLowerCase();
            const matchesSearch = !currentSearchTerm || cardTitle.includes(currentSearchTerm);

            // 3. Filtro Unificado
            let matchesFilter = true;
            if (currentUnifiedFilter && currentUnifiedFilter !== 'status:all' && currentUnifiedFilter !== 'priority:all') {
                const parts = currentUnifiedFilter.split(':');
                const type = parts[0];
                const val = parts[1] || '';
                if (type === 'status') {
                    const cardStatus = card.getAttribute('data-status') || '';
                    matchesFilter = (val === 'all' || cardStatus === val);
                } else if (type === 'priority') {
                    const cardPriority = card.getAttribute('data-priority') || '';
                    matchesFilter = (val === 'all' || cardPriority === val);
                } else if (type === 'due') {
                    const isOverdue = card.getAttribute('data-overdue') === '1';
                    if (val === 'vencidas') matchesFilter = isOverdue;
                    else if (val === 'no_vencidas') matchesFilter = !isOverdue;
                }
            }

            const isVisible = matchesUser && matchesSearch && matchesFilter;
            if (isVisible) {
                card.classList.remove('hidden');
                visibleCount++;
            } else {
                card.classList.add('hidden');
            }
        });

        // Actualizar grupos por fecha
        groups.forEach(group => {
            const groupCards = group.querySelectorAll('.task-list-card:not(.hidden)');
            const countBadge = group.querySelector('.task-group-count');
            if (groupCards.length === 0) {
                group.classList.add('hidden');
            } else {
                group.classList.remove('hidden');
                if (countBadge) {
                    countBadge.textContent = groupCards.length + ' tarea(s)';
                }
            }
        });

        // Mensaje de estado vacío cuando no hay tareas coincidentes
        if (emptyContainer) {
            if (cards.length > 0 && visibleCount === 0) {
                emptyContainer.classList.remove('hidden');
                if (emptyMsg) {
                    if (currentSearchTerm && currentUnifiedFilter) {
                        emptyMsg.textContent = 'No se encontraron tareas que coincidan con la búsqueda y el filtro seleccionado.';
                    } else if (currentSearchTerm) {
                        emptyMsg.textContent = 'No se encontraron tareas con el término "' + (searchInput ? searchInput.value : '') + '".';
                    } else if (currentUnifiedFilter) {
                        emptyMsg.textContent = 'No se encontraron tareas con el filtro seleccionado.';
                    } else if (currentFilteredUserId) {
                        emptyMsg.textContent = 'No hay tareas asignadas a este usuario para este período.';
                    } else {
                        emptyMsg.textContent = 'No se encontraron tareas para los criterios seleccionados.';
                    }
                }
            } else {
                emptyContainer.classList.add('hidden');
            }
        }

        // Actualizar contadores de tabs y sincronizar enlaces
        updateTabCounts();

        // Sincronizar parámetros en URL sin recargar la página
        try {
            const url = new URL(window.location);
            if (currentFilteredUserId) {
                url.searchParams.set('user_id', currentFilteredUserId);
            } else {
                url.searchParams.delete('user_id');
            }
            if (currentUnifiedFilter) {
                url.searchParams.set('task_filter_option', currentUnifiedFilter);
            } else {
                url.searchParams.delete('task_filter_option');
            }
            if (currentSearchTerm) {
                url.searchParams.set('task_search', currentSearchTerm);
            } else {
                url.searchParams.delete('task_search');
            }
            url.searchParams.delete('task_status');
            url.searchParams.delete('task_priority');
            url.searchParams.delete('task_due');
            window.history.replaceState({}, '', url);
        } catch(e) {}

        if (window.lucide) {
            lucide.createIcons();
        }

        syncCalendarListHeight();
    }

    function updateTabCounts() {
        const todayBadge = document.getElementById('badge-count-today');
        const monthBadge = document.getElementById('badge-count-month');

        const countToday = todayTasksMeta.filter(t => taskMatchesAllFilters(t, currentFilteredUserId, currentUnifiedFilter, currentSearchTerm)).length;
        const countMonth = monthTasksMeta.filter(t => taskMatchesAllFilters(t, currentFilteredUserId, currentUnifiedFilter, currentSearchTerm)).length;

        if (todayBadge) todayBadge.textContent = countToday;
        if (monthBadge) monthBadge.textContent = countMonth;

        const mobHoyBadge = document.querySelector('#subnav-cal-btn-hoy .tab-counter-badge');
        const mobMesBadge = document.querySelector('#subnav-cal-btn-mes .tab-counter-badge');
        if (mobHoyBadge) mobHoyBadge.textContent = countToday;
        if (mobMesBadge) mobMesBadge.textContent = countMonth;

        ['tab-tasks-today', 'tab-tasks-month', 'subnav-cal-btn-hoy', 'subnav-cal-btn-mes'].forEach(tabId => {
            const tabEl = document.getElementById(tabId);
            if (tabEl) {
                const url = new URL(tabEl.href, window.location.origin);
                if (currentFilteredUserId) url.searchParams.set('user_id', currentFilteredUserId);
                else url.searchParams.delete('user_id');

                if (currentUnifiedFilter) url.searchParams.set('task_filter_option', currentUnifiedFilter);
                else url.searchParams.delete('task_filter_option');

                if (currentSearchTerm) url.searchParams.set('task_search', currentSearchTerm);
                else url.searchParams.delete('task_search');

                url.searchParams.delete('task_status');
                url.searchParams.delete('task_priority');
                url.searchParams.delete('task_due');

                tabEl.href = url.pathname + url.search;
            }
        });
    }

    function onTaskUnifiedFilterChange() {
        applyAllTaskFilters();
    }

    function onTaskSearchInput(val) {
        applyAllTaskFilters();
    }

    function clearTaskSearch() {
        const searchInput = document.getElementById('task-search-input');
        if (searchInput) {
            searchInput.value = '';
            searchInput.focus();
        }
        currentSearchTerm = '';
        applyAllTaskFilters();
    }

    function resetTaskFilters(includeUser = false) {
        const filterSelect = document.getElementById('task-filter-select');
        const searchInput = document.getElementById('task-search-input');

        if (filterSelect) filterSelect.value = '';
        if (searchInput) searchInput.value = '';

        currentUnifiedFilter = '';
        currentSearchTerm = '';

        if (includeUser && currentFilteredUserId) {
            onUserFilterChange('');
            return;
        }

        applyAllTaskFilters();
    }

    function filterTaskListByUser(userId) {
        currentFilteredUserId = userId ? String(userId) : '';
        applyAllTaskFilters();
    }

    function onUserFilterChange(userId) {
        currentFilteredUserId = userId ? String(userId) : '';

        // Mantener sincronizados ambos selectores (normal y modal)
        const f1 = document.getElementById('calendar-user-filter');
        const f2 = document.getElementById('calendar-modal-user-filter');
        if (f1 && f1.value !== currentFilteredUserId) f1.value = currentFilteredUserId;
        if (f2 && f2.value !== currentFilteredUserId) f2.value = currentFilteredUserId;

        // 1. Refrescar eventos de FullCalendar mediante refetch limpio de su fuente de eventos
        if (window.calendarInstance) {
            window.calendarInstance.refetchEvents();
        }

        // 2. Aplicar filtros combinados a la lista de tareas del proyecto
        applyAllTaskFilters();
    }

    // FullCalendar Initialization
    document.addEventListener('DOMContentLoaded', () => {
        const calendarEl = document.getElementById('calendar-container');
        if (calendarEl && window.FullCalendar) {
            const isInitialSplit = isCalendarSplitMode();
            window.calendarInstance = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'es',
                height: 'auto',
                aspectRatio: isInitialSplit ? 1.35 : (window.innerWidth >= 1280 ? 1.25 : 1.18),
                firstDay: 1,
                selectable: true,
                dayMaxEvents: false,
                displayEventTime: false,
                events: function(fetchInfo, successCallback, failureCallback) {
                    successCallback(getFilteredEvents(currentFilteredUserId));
                },

                eventContent: function(arg) {
                    const props = arg.event.extendedProps || {};
                    const statusColor = props.statusColor || '#64748b';
                    const prioLabel = props.priorityLabel || 'Media';
                    const prioColor = props.priorityColor || '#f59e0b';
                    const isPeriodic = !!props.isPeriodic;
                    const recurrence = (props.recurrence || '').toLowerCase().trim();
                    const recLabel = props.recurrenceLabel || '';
                    const recColor = props.recurrenceColor || '#3b82f6';
                    const title = arg.event.title || '(Sin título)';

                    const isDark = document.documentElement.classList.contains('dark');
                    const bgAlpha = isDark ? 0.20 : 0.10;
                    const borderAlpha = isDark ? 0.35 : 0.22;
                    const badgeBgAlpha = isDark ? 0.22 : 0.14;
                    const badgeBorderAlpha = isDark ? 0.40 : 0.28;

                    const bgSoft = hexToRgba(statusColor, bgAlpha);
                    const borderSoft = hexToRgba(statusColor, borderAlpha);

                    const prioBadgeBg = hexToRgba(prioColor, badgeBgAlpha);
                    const prioBadgeBorder = hexToRgba(prioColor, badgeBorderAlpha);
                    const prioBadge = `<span class="cal-badge" style="background-color: ${prioBadgeBg}; color: ${prioColor}; border: 1px solid ${prioBadgeBorder};">${escapeHtml(prioLabel)}</span>`;

                    // Visualización de periodicidad:
                    // - Diaria: NO mostrar etiqueta
                    // - Semanal: mostrar «Semanal»
                    // - Mensual: mostrar «Mensual»
                    // - Anual: mostrar «Anual»
                    let recBadge = '';
                    if (isPeriodic && recLabel && recurrence !== 'diaria') {
                        let displayRecLabel = recLabel;
                        if (recurrence === 'semanal') displayRecLabel = 'Semanal';
                        else if (recurrence === 'mensual') displayRecLabel = 'Mensual';
                        else if (recurrence === 'anual') displayRecLabel = 'Anual';

                        const recBadgeBg = hexToRgba(recColor, badgeBgAlpha);
                        const recBadgeBorder = hexToRgba(recColor, badgeBorderAlpha);
                        recBadge = `<span class="cal-badge" style="background-color: ${recBadgeBg}; color: ${recColor}; border: 1px solid ${recBadgeBorder};">${escapeHtml(displayRecLabel)}</span>`;
                    }

                    const cardHtml = `
                        <div class="cal-event-card" style="background-color: ${bgSoft}; border: 1px solid ${borderSoft}; border-left: 4px solid ${statusColor};">
                            <div class="cal-event-title" title="${escapeHtml(title)}">${escapeHtml(title)}</div>
                            <div class="cal-event-badges">
                                ${prioBadge}
                                ${recBadge}
                            </div>
                        </div>
                    `;

                    return { html: cardHtml };
                },

                datesSet: function() {
                    syncCalendarListHeight();
                },
                dateClick: function(info) {
                    @if(!$user->isHelper())
                        openTaskModal(null, 'no_iniciado', info.dateStr);
                    @endif
                },
                eventClick: function(info) {
                    const taskId = info.event.id;
                    const task = allTasksMap[taskId];
                    if (task) {
                        openTaskModal(task);
                    }
                }
            });
            window.calendarInstance.render();
            applyCalendarViewMode(isInitialSplit);
            applyAllTaskFilters();

            window.addEventListener('theme-toggled', () => {
                if (window.calendarInstance) {
                    window.calendarInstance.render();
                    setTimeout(syncCalendarListHeight, 50);
                }
            });

            const calCard = document.getElementById('cal-view-calendar');
            if (calCard) {
                let calResizeTimer = null;
                const debouncedCalResize = () => {
                    clearTimeout(calResizeTimer);
                    calResizeTimer = setTimeout(() => {
                        const taskModalEl = document.getElementById('taskModal');
                        if (taskModalEl && !taskModalEl.classList.contains('hidden')) return;
                        if (window.calendarInstance && (!document.getElementById('calendarModal') || document.getElementById('calendarModal').classList.contains('hidden'))) {
                            const isSplit = isCalendarSplitMode();
                            window.calendarInstance.setOption('aspectRatio', isSplit ? 1.35 : (window.innerWidth >= 1280 ? 1.25 : 1.18));
                            window.calendarInstance.updateSize();
                            syncCalendarListHeight();
                        }
                    }, 120);
                };

                if (window.ResizeObserver) {
                    let lastCalWidth = 0;
                    new ResizeObserver((entries) => {
                        for (const entry of entries) {
                            const currentWidth = Math.round(entry.contentRect.width);
                            if (currentWidth > 0 && Math.abs(currentWidth - lastCalWidth) >= 15) {
                                lastCalWidth = currentWidth;
                                debouncedCalResize();
                            }
                        }
                    }).observe(calCard);
                }
                window.addEventListener('resize', debouncedCalResize);
                setTimeout(syncCalendarListHeight, 150);
            }
        }
    });

    // Sincronización vertical exacta entre el Calendario y la Lista de Tareas
    function syncCalendarListHeight() {
        if (window.innerWidth >= 1024) {
            const cal = document.getElementById('cal-view-calendar');
            const list = document.getElementById('cal-view-list');
            const modal = document.getElementById('calendarModal');
            if (cal && list && (!modal || modal.classList.contains('hidden'))) {
                if (list.classList.contains('lg:hidden') || !isCalendarSplitMode()) {
                    list.style.height = '';
                    list.style.maxHeight = '';
                    return;
                }
                const h = cal.offsetHeight;
                if (h > 100) {
                    list.style.height = h + 'px';
                    list.style.maxHeight = h + 'px';
                }
            }
        } else {
            const list = document.getElementById('cal-view-list');
            if (list) {
                list.style.height = '';
                list.style.maxHeight = '';
            }
        }
    }

    // Control de vista expandida del calendario
    function expandCalendar() {
        const modal = document.getElementById('calendarModal');
        const modalSlot = document.getElementById('calendar-expanded-slot');
        const calendarEl = document.getElementById('calendar-container');
        if (!modal || !modalSlot || !calendarEl) return;

        modalSlot.appendChild(calendarEl);
        modal.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
        calendarEl.classList.add('h-full');

        if (window.calendarInstance) {
            window.calendarInstance.setOption('height', '100%');
            window.calendarInstance.updateSize();
        }
        if (window.lucide) lucide.createIcons();
    }

    function closeCalendarExpand() {
        const modal = document.getElementById('calendarModal');
        const normalSlot = document.getElementById('calendar-normal-slot');
        const calendarEl = document.getElementById('calendar-container');
        if (!modal || !normalSlot || !calendarEl) return;

        normalSlot.appendChild(calendarEl);
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
        calendarEl.classList.remove('h-full');

        if (window.calendarInstance) {
            const isSplit = isCalendarSplitMode();
            window.calendarInstance.setOption('height', 'auto');
            window.calendarInstance.setOption('aspectRatio', isSplit ? 1.35 : (window.innerWidth >= 1280 ? 1.55 : 1.4));
            window.calendarInstance.updateSize();
            if (isSplit) {
                setTimeout(syncCalendarListHeight, 50);
            }
        }
    }

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const modal = document.getElementById('calendarModal');
            if (modal && !modal.classList.contains('hidden')) {
                const taskModal = document.getElementById('taskModal');
                if (taskModal && !taskModal.classList.contains('hidden')) {
                    return;
                }
                closeCalendarExpand();
            }
        }
    });

    // -------------------------------------------------------------
    // Mobile Contextual Sub-navigation Logic
    // -------------------------------------------------------------
    function selectMobileCalView(viewMode) {
        const calCol = document.getElementById('cal-view-calendar');
        const listCol = document.getElementById('cal-view-list');
        if (!calCol || !listCol) return;

        document.querySelectorAll('.cal-subnav-btn').forEach(btn => {
            btn.classList.remove('border-indigo-600', 'text-indigo-600', 'dark:text-indigo-400', 'dark:border-indigo-500', 'border-blue-600', 'text-blue-600', 'dark:text-blue-400', 'dark:border-blue-500', 'font-bold');
            btn.classList.add('border-transparent', 'text-slate-500', 'dark:text-slate-400');
        });

        if (viewMode === 'calendar') {
            calCol.classList.remove('cal-panel-mobile-hidden');
            listCol.classList.add('cal-panel-mobile-hidden');
            const activeBtn = document.getElementById('subnav-cal-btn-calendar');
            if (activeBtn) {
                activeBtn.classList.add('border-indigo-600', 'text-indigo-600', 'dark:text-indigo-400', 'dark:border-indigo-500', 'font-bold');
                activeBtn.classList.remove('border-transparent', 'text-slate-500', 'dark:text-slate-400');
            }
            sessionStorage.setItem('cal_mobile_active_tab', 'calendar');
            if (window.calendarInstance) {
                setTimeout(() => {
                    window.calendarInstance.updateSize();
                }, 50);
            }
        } else {
            calCol.classList.add('cal-panel-mobile-hidden');
            listCol.classList.remove('cal-panel-mobile-hidden');
            let activeId = 'subnav-cal-btn-list';
            if (viewMode === 'hoy') activeId = 'subnav-cal-btn-hoy';
            if (viewMode === 'mes') activeId = 'subnav-cal-btn-mes';
            const activeBtn = document.getElementById(activeId);
            if (activeBtn) {
                activeBtn.classList.add('border-indigo-600', 'text-indigo-600', 'dark:text-indigo-400', 'dark:border-indigo-500', 'font-bold');
                activeBtn.classList.remove('border-transparent', 'text-slate-500', 'dark:text-slate-400');
            }
            sessionStorage.setItem('cal_mobile_active_tab', 'list');
        }
    }

    function filterMobileKanban(status) {
        document.querySelectorAll('.kanban-subnav-btn').forEach(btn => {
            btn.classList.remove('border-indigo-600', 'text-indigo-600', 'dark:text-indigo-400', 'dark:border-indigo-500', 'border-blue-600', 'text-blue-600', 'dark:text-blue-400', 'dark:border-blue-500', 'font-bold');
            btn.classList.add('border-transparent', 'text-slate-500', 'dark:text-slate-400');
        });

        const activeBtn = document.getElementById('subnav-kanban-btn-' + status);
        if (activeBtn) {
            activeBtn.classList.add('border-indigo-600', 'text-indigo-600', 'dark:text-indigo-400', 'dark:border-indigo-500', 'font-bold');
            activeBtn.classList.remove('border-transparent', 'text-slate-500', 'dark:text-slate-400');
        }

        const cols = document.querySelectorAll('[data-kanban-col]');
        cols.forEach(col => {
            if (status === 'todos' || col.getAttribute('data-kanban-col') === status) {
                col.classList.remove('kanban-col-mobile-hidden');
            } else {
                col.classList.add('kanban-col-mobile-hidden');
            }
        });
        sessionStorage.setItem('kanban_mobile_active_col', status);
    }

    function filterMobileIncidents(status) {
        document.querySelectorAll('.inc-subnav-btn').forEach(btn => {
            btn.classList.remove('border-red-600', 'text-red-600', 'dark:text-red-400', 'dark:border-red-500', 'font-bold');
            btn.classList.add('border-transparent', 'text-slate-500', 'dark:text-slate-400');
        });

        const activeBtn = document.getElementById('subnav-inc-btn-' + status);
        if (activeBtn) {
            activeBtn.classList.add('border-red-600', 'text-red-600', 'dark:text-red-400', 'dark:border-red-500', 'font-bold');
            activeBtn.classList.remove('border-transparent', 'text-slate-500', 'dark:text-slate-400');
        }

        const cols = document.querySelectorAll('[data-incident-col]');
        cols.forEach(col => {
            if (status === 'todas' || col.getAttribute('data-incident-col') === status) {
                col.classList.remove('incident-col-mobile-hidden');
            } else {
                col.classList.add('incident-col-mobile-hidden');
            }
        });
        sessionStorage.setItem('inc_mobile_active_col', status);
    }

    // Guardar la vista activa actual en localStorage para el botón de regreso de Configuración
    window.saveSettingsReturnView = function() {
        try {
            const currentActiveView = '{{ $activeView }}';
            if (currentActiveView && currentActiveView !== 'configuracion') {
                localStorage.setItem('settingsReturnView', currentActiveView);
                localStorage.setItem('settingsReturnUrl', window.location.href);
            }
        } catch (e) {
            console.error('Error al guardar settingsReturnView:', e);
        }
    };
    saveSettingsReturnView();

    // =========================================================================
    // CORRECCIÓN GENERAL DE VALIDACIÓN DE FECHAS EN TODO EL SISTEMA
    // =========================================================================

    /**
     * Sincroniza dinámicamente las restricciones entre fecha de inicio y fecha de fin
     * en el formulario de tareas (#taskModal).
     */
    function syncTaskDateConstraints(source = null) {
        const sDateInput = document.getElementById('task_start_date');
        const eDateInput = document.getElementById('task_end_date');
        const sTimeInput = document.getElementById('task_start_time');
        const eTimeInput = document.getElementById('task_end_time');

        if (!sDateInput || !eDateInput) return;

        const sDate = sDateInput.value;
        const eDate = eDateInput.value;
        const sTime = sTimeInput ? sTimeInput.value : '';
        const eTime = eTimeInput ? eTimeInput.value : '';

        // 1. Bloqueo en calendario: La fecha final no puede ser anterior a la fecha inicial
        if (sDate) {
            eDateInput.min = sDate;
            // Si la fecha de finalización deja de ser válida al mover la fecha inicial a una posterior,
            // ajustar automáticamente para evitar guardar valores inconsistentes
            if (eDate && eDate < sDate) {
                eDateInput.value = sDate;
            }
        } else {
            eDateInput.removeAttribute('min');
        }

        // 2. Si la fecha final está presente, limitar el máximo permitido para la fecha de inicio
        const currentEDate = eDateInput.value;
        if (currentEDate) {
            sDateInput.max = currentEDate;
            if (sDateInput.value && sDateInput.value > currentEDate) {
                sDateInput.value = currentEDate;
            }
        } else {
            sDateInput.removeAttribute('max');
        }

        // 3. Reglas de horas cuando fecha de inicio y fin coinciden en el mismo día
        const finalSDate = sDateInput.value;
        const finalEDate = eDateInput.value;

        if (eTimeInput && sTimeInput) {
            if (finalSDate && finalEDate && finalSDate === finalEDate) {
                if (sTime) {
                    eTimeInput.min = sTime;
                    if (eTime && eTime < sTime) {
                        eTimeInput.value = sTime;
                    }
                } else {
                    eTimeInput.removeAttribute('min');
                }
            } else {
                eTimeInput.removeAttribute('min');
            }
        }
    }

    /**
     * Sincroniza dinámicamente las restricciones de horario en tareas periódicas
     * (#recurringTaskModal).
     */
    function syncRecurringTaskDateConstraints() {
        const sTimeInput = document.getElementById('rec_start_time');
        const eTimeInput = document.getElementById('rec_end_time');
        if (!sTimeInput || !eTimeInput) return;

        const sTime = sTimeInput.value;
        const eTime = eTimeInput.value;

        if (sTime) {
            eTimeInput.min = sTime;
            if (eTime && eTime < sTime) {
                eTimeInput.value = sTime;
            }
        } else {
            eTimeInput.removeAttribute('min');
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        // Enlazar eventos para Tareas Normales
        const sDateInput = document.getElementById('task_start_date');
        const eDateInput = document.getElementById('task_end_date');
        const sTimeInput = document.getElementById('task_start_time');
        const eTimeInput = document.getElementById('task_end_time');

        if (sDateInput) {
            sDateInput.addEventListener('change', () => syncTaskDateConstraints('start'));
            sDateInput.addEventListener('input', () => syncTaskDateConstraints('start'));
        }
        if (eDateInput) {
            eDateInput.addEventListener('change', () => syncTaskDateConstraints('end'));
            eDateInput.addEventListener('input', () => syncTaskDateConstraints('end'));
        }
        if (sTimeInput) {
            sTimeInput.addEventListener('change', () => syncTaskDateConstraints('time'));
            sTimeInput.addEventListener('input', () => syncTaskDateConstraints('time'));
        }
        if (eTimeInput) {
            eTimeInput.addEventListener('change', () => syncTaskDateConstraints('time'));
            eTimeInput.addEventListener('input', () => syncTaskDateConstraints('time'));
        }

        // Validación en submit de Tareas Normales (comparación lexicográfica ISO libre de desfase horario)
        const taskForm = document.getElementById('taskForm');
        if (taskForm) {
            taskForm.addEventListener('submit', function (e) {
                const sDate = sDateInput?.value;
                const sTime = sTimeInput?.value || '00:00';
                const eDate = eDateInput?.value;
                const eTime = eTimeInput?.value || '23:59';

                if (sDate && eDate) {
                    const startStr = `${sDate} ${sTime}`;
                    const endStr = `${eDate} ${eTime}`;
                    if (endStr < startStr) {
                        e.preventDefault();
                        alert('La fecha y hora de finalización no pueden ser anteriores a la fecha y hora de inicio.');
                        return false;
                    }
                }
            });
        }

        // Enlazar eventos para Tareas Periódicas
        const recSTime = document.getElementById('rec_start_time');
        const recETime = document.getElementById('rec_end_time');

        if (recSTime) {
            recSTime.addEventListener('change', syncRecurringTaskDateConstraints);
            recSTime.addEventListener('input', syncRecurringTaskDateConstraints);
        }
        if (recETime) {
            recETime.addEventListener('change', syncRecurringTaskDateConstraints);
            recETime.addEventListener('input', syncRecurringTaskDateConstraints);
        }

        // Validación en submit de Tareas Periódicas
        const recForm = document.getElementById('recurringTaskForm');
        if (recForm) {
            recForm.addEventListener('submit', function (e) {
                const sTime = recSTime?.value;
                const eTime = recETime?.value;

                if (sTime && eTime && eTime < sTime) {
                    e.preventDefault();
                    alert('La hora de finalización no puede ser anterior a la hora de inicio.');
                    return false;
                }
            });
        }
    });

    // =========================================================================
    // PUNTOS 9, 10, 11: GESTIÓN DE INCIDENCIAS (EDITAR, ASIGNAR, ELIMINAR, CAMBIO DE ESTADO AJAX)
    // =========================================================================
    let currentIncidentModalId = null;

    function openIncidentModal(incident = null) {
        const form = document.getElementById('incidentForm');
        const methodInput = document.getElementById('incident_method');
        const titleHeading = document.getElementById('incidentModalTitle');
        const submitBtn = document.getElementById('btnSubmitIncident');
        const attSection = document.getElementById('incidentAttachmentsSection');

        if (!form) return;

        // Limpiar siempre estados de archivos adjuntos previos
        if (typeof resetIncidentModalAttachments === 'function') {
            resetIncidentModalAttachments();
        }

        const deleteBtn = document.getElementById('btnDeleteIncidentModal');

        if (incident) {
            currentIncidentModalId = incident.id;
            form.action = '{{ url('/incidents') }}/' + incident.id;
            methodInput.value = 'PUT';
            if (titleHeading) titleHeading.textContent = 'Detalles de la Incidencia';
            if (submitBtn) submitBtn.textContent = 'Actualizar Incidencia';

            if (deleteBtn) {
                const userHasFullAccess = {{ $user->hasFullAccess() ? 'true' : 'false' }};
                const currentUserId = {{ (int) Auth::id() }};
                const isOwner = incident.user_id !== undefined && incident.user_id !== null &&
                                (Number(incident.user_id) === currentUserId || String(incident.user_id) === String(currentUserId));
                if (userHasFullAccess || isOwner) {
                    deleteBtn.classList.remove('hidden');
                } else {
                    deleteBtn.classList.add('hidden');
                }
            }

            document.getElementById('incident_titulo').value = incident.titulo || '';
            document.getElementById('incident_descripcion').value = incident.descripcion || '';
            document.getElementById('incident_project_id').value = incident.project_id || '';
            document.getElementById('incident_assigned_user_id').value = incident.assigned_user_id || '';
            document.getElementById('incident_prioridad').value = incident.prioridad || 'media';
            document.getElementById('incident_estado').value = incident.estado || 'abierta';

            if (attSection) attSection.classList.remove('hidden');
            loadIncidentAttachments(incident.id);
        } else {
            currentIncidentModalId = null;
            if (deleteBtn) deleteBtn.classList.add('hidden');
            form.action = '{{ route('incidents.store') }}';
            methodInput.value = 'POST';
            if (titleHeading) titleHeading.textContent = 'Reportar Incidencia';
            if (submitBtn) submitBtn.textContent = 'Guardar Incidencia';
            form.reset();

            @if($activeProject)
                document.getElementById('incident_project_id').value = '{{ $activeProject->id }}';
            @else
                document.getElementById('incident_project_id').value = '';
            @endif

            // En creación, la sección de adjuntar archivo también está visible y lista para usar
            if (attSection) attSection.classList.remove('hidden');
        }

        openModal('incidentModal');
        if (window.lucide) {
            const modalEl = document.getElementById('incidentModal');
            if (modalEl) lucide.createIcons({ root: modalEl });
        }
    }

    function confirmDeleteCurrentIncident() {
        if (!currentIncidentModalId) return;
        deleteIncident(currentIncidentModalId, true);
    }

    function deleteIncident(incidentId, fromModal = false) {
        openDeleteConfirm({
            title: '¿Eliminar incidencia?',
            message: 'Esta acción no se puede deshacer. Se eliminarán definitivamente la incidencia y sus archivos adjuntos asociados.',
            confirmText: 'Eliminar incidencia',
            isPermanent: true,
            permanentText: 'Advertencia: La incidencia se eliminará de forma permanente.',
            onConfirm: () => {
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
                const url = '{{ url('/incidents') }}/' + incidentId;

                fetch(url, {
                    method: 'DELETE',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken,
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(async res => {
                    const data = await res.json().catch(() => null);
                    if (!res.ok) {
                        throw new Error(data?.error || data?.message || 'Error al eliminar la incidencia');
                    }
                    return data;
                })
                .then(data => {
                    // Cerrar el modal de detalles
                    closeModal('incidentModal');
                    currentIncidentModalId = null;

                    // Eliminar la tarjeta del tablero
                    const card = document.getElementById('inc-card-' + incidentId);
                    if (card) card.remove();

                    // Actualizar contadores
                    updateIncidentColumnCounters();
                })
                .catch(err => {
                    console.error(err);
                    alert(err.message || 'No se pudo eliminar la incidencia');
                });
            }
        });
    }

    function changeIncidentStatus(incidentId, newStatus, selectElem) {
        const card = document.getElementById('inc-card-' + incidentId);
        const originalParent = card ? card.parentNode : null;
        const originalNext = card ? card.nextSibling : null;
        const targetCol = document.getElementById('inc-col-' + newStatus);

        if (card && targetCol) {
            const targetList = targetCol.querySelector('.space-y-3');
            if (targetList) {
                const emptyNotice = targetList.querySelector('p');
                if (emptyNotice && emptyNotice.textContent.includes('Sin incidencias')) {
                    emptyNotice.remove();
                }
                targetList.appendChild(card);
                updateIncidentColumnCounters();
            }
        }

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
        const url = '{{ url('/incidents') }}/' + incidentId + '/status';

        fetch(url, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ estado: newStatus })
        })
        .then(async res => {
            const data = await res.json().catch(() => null);
            if (!res.ok) throw new Error(data?.error || data?.message || 'Error al actualizar estado');
            return data;
        })
        .then(data => {
            updateIncidentColumnCounters();
        })
        .catch(err => {
            console.error(err);
            // Revert DOM position
            if (card && originalParent) {
                if (originalNext) originalParent.insertBefore(card, originalNext);
                else originalParent.appendChild(card);
            }
            updateIncidentColumnCounters();
            alert('No se pudo actualizar el estado de la incidencia.');
        });
    }

    function updateIncidentColumnCounters() {
        let totalCount = 0;
        let countsByStatus = {
            abierta: 0,
            en_proceso: 0,
            resuelta: 0
        };

        document.querySelectorAll('[data-incident-col]').forEach(col => {
            const colId = col.getAttribute('data-incident-col');
            const list = col.querySelector('.space-y-3');
            const counter = col.querySelector('span.rounded-full');
            if (list) {
                const cards = list.querySelectorAll('[id^="inc-card-"]');
                const count = cards.length;
                totalCount += count;
                if (colId && countsByStatus.hasOwnProperty(colId)) {
                    countsByStatus[colId] = count;
                }
                if (counter) counter.textContent = count;
                if (count === 0 && !list.querySelector('p')) {
                    const p = document.createElement('p');
                    p.className = 'text-center py-6 text-slate-400 dark:text-slate-500 text-xs italic';
                    p.textContent = 'Sin incidencias en esta columna';
                    list.appendChild(p);
                }
            }
        });

        const tabBadge = document.getElementById('incidents-tab-badge');
        if (tabBadge) {
            tabBadge.textContent = totalCount;
            if (totalCount > 0) {
                tabBadge.classList.remove('hidden');
            } else {
                tabBadge.classList.add('hidden');
            }
        }

        const subnavTodas = document.getElementById('subnav-inc-count-todas');
        if (subnavTodas) subnavTodas.textContent = totalCount;
        const subnavAbierta = document.getElementById('subnav-inc-count-abierta');
        if (subnavAbierta) subnavAbierta.textContent = countsByStatus.abierta;
        const subnavEnProceso = document.getElementById('subnav-inc-count-en_proceso');
        if (subnavEnProceso) subnavEnProceso.textContent = countsByStatus.en_proceso;
        const subnavResuelta = document.getElementById('subnav-inc-count-resuelta');
        if (subnavResuelta) subnavResuelta.textContent = countsByStatus.resuelta;

        const kpiCount = document.getElementById('kpi-incidents-count');
        if (kpiCount) {
            kpiCount.textContent = totalCount;
        }
    }

    // =========================================================================
    // PUNTO 17: GESTIÓN DE ARCHIVOS ADJUNTOS (TAREAS E INCIDENCIAS)
    // =========================================================================
    function loadAttachments(attachableType, attachableId) {
        const listId = attachableType === 'Task' ? 'taskAttachmentsList' : 'incidentAttachmentsList';
        const countId = attachableType === 'Task' ? 'taskAttachmentsCount' : 'incidentAttachmentsCount';
        const listEl = document.getElementById(listId);
        const countEl = document.getElementById(countId);
        if (!listEl) return;

        listEl.innerHTML = '<p class="text-[11px] text-slate-400 italic">Cargando adjuntos...</p>';

        fetch(`/attachments?attachable_type=${attachableType}&attachable_id=${attachableId}`, {
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (!data.success || !data.attachments || data.attachments.length === 0) {
                listEl.innerHTML = '<p class="text-[11px] text-slate-400 dark:text-slate-500 italic">No hay archivos adjuntos.</p>';
                if (countEl) countEl.textContent = '';
                return;
            }

            if (countEl) countEl.textContent = `(${data.attachments.length})`;

            listEl.innerHTML = data.attachments.map(att => `
                <div class="flex items-center justify-between gap-2 p-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs">
                    <div class="flex items-center gap-2 min-w-0 flex-1">
                        <i data-lucide="file" class="w-4 h-4 text-indigo-500 shrink-0"></i>
                        <span class="truncate font-medium text-slate-700 dark:text-slate-200" title="${escapeHtml(att.original_name)}">
                            ${escapeHtml(att.original_name)}
                        </span>
                        <span class="text-[10px] text-slate-400 shrink-0">(${escapeHtml(att.formatted_size)})</span>
                    </div>
                    <div class="flex items-center gap-1 shrink-0">
                        <a href="/attachments/${att.id}/download" class="p-1 text-slate-500 hover:text-indigo-600 transition" title="Descargar archivo">
                            <i data-lucide="download" class="w-3.5 h-3.5"></i>
                        </a>
                        <button type="button" onclick="deleteAttachment(${att.id}, '${attachableType}', ${attachableId})" class="p-1 text-slate-500 hover:text-red-600 transition" title="Eliminar archivo">
                            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                        </button>
                    </div>
                </div>
            `).join('');

            if (window.lucide) {
                const rootEl = attachableType === 'Task' ? document.getElementById('taskModal') : document.getElementById('incidentModal');
                if (rootEl) lucide.createIcons({ root: rootEl });
            }
        })
        .catch(err => {
            console.error(err);
            listEl.innerHTML = '<p class="text-[11px] text-red-500">Error al cargar archivos adjuntos.</p>';
        });
    }

    function uploadTaskAttachment() {
        if (!currentTaskModalId) {
            alert('Guarda primero la tarea antes de adjuntar archivos.');
            return;
        }
        const fileInput = document.getElementById('task_attachment_file');
        if (!fileInput || !fileInput.files || fileInput.files.length === 0) {
            alert('Selecciona un archivo para adjuntar.');
            return;
        }

        const formData = new FormData();
        formData.append('attachable_type', 'Task');
        formData.append('attachable_id', currentTaskModalId);
        formData.append('file', fileInput.files[0]);

        const btn = document.getElementById('btnUploadTaskAttachment');
        if (btn) btn.disabled = true;

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

        fetch('/attachments', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (btn) btn.disabled = false;
            if (data.success) {
                fileInput.value = '';
                loadAttachments('Task', currentTaskModalId);
            } else {
                alert(data.error || 'Error al subir el archivo.');
            }
        })
        .catch(err => {
            if (btn) btn.disabled = false;
            console.error(err);
            alert('Error de red al subir archivo adjunto.');
        });
    }

    // =========================================================================
    // GESTIÓN DE ARCHIVOS ADJUNTOS EN INCIDENCIAS (CREAR Y EDITAR)
    // =========================================================================
    let existingIncidentAttachments = [];
    let pendingRemoveIncidentAttachmentIds = [];

    function formatFileSize(bytes) {
        if (!bytes || bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + (sizes[i] || 'MB');
    }

    function handleIncidentFileSelected(input) {
        const preview = document.getElementById('incidentSelectedFilePreview');
        const nameEl = document.getElementById('incidentSelectedFileName');
        const sizeEl = document.getElementById('incidentSelectedFileSize');

        if (!input || !input.files || input.files.length === 0) {
            clearSelectedIncidentFile();
            return;
        }

        const file = input.files[0];
        if (nameEl) nameEl.textContent = file.name;
        if (sizeEl) sizeEl.textContent = formatFileSize(file.size);
        if (preview) preview.classList.remove('hidden');

        if (window.lucide && preview) {
            lucide.createIcons({ root: preview });
        }
    }

    function clearSelectedIncidentFile(e) {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        const fileInput = document.getElementById('incident_attachment_file');
        if (fileInput) fileInput.value = '';

        const preview = document.getElementById('incidentSelectedFilePreview');
        if (preview) preview.classList.add('hidden');

        const nameEl = document.getElementById('incidentSelectedFileName');
        if (nameEl) nameEl.textContent = '';
        const sizeEl = document.getElementById('incidentSelectedFileSize');
        if (sizeEl) sizeEl.textContent = '';
    }

    function resetIncidentModalAttachments() {
        clearSelectedIncidentFile();
        existingIncidentAttachments = [];
        pendingRemoveIncidentAttachmentIds = [];
        syncIncidentPendingRemoveInputs();

        const countEl = document.getElementById('incidentAttachmentsCount');
        if (countEl) countEl.textContent = '';

        const listEl = document.getElementById('incidentAttachmentsList');
        if (listEl) listEl.innerHTML = '';

        const existingSection = document.getElementById('incidentExistingFilesSection');
        if (existingSection) existingSection.classList.add('hidden');
    }

    function loadIncidentAttachments(incidentId) {
        const listEl = document.getElementById('incidentAttachmentsList');
        const countEl = document.getElementById('incidentAttachmentsCount');
        const existingSection = document.getElementById('incidentExistingFilesSection');

        if (!listEl) return;

        pendingRemoveIncidentAttachmentIds = [];
        syncIncidentPendingRemoveInputs();
        listEl.innerHTML = '<p class="text-[11px] text-slate-400 italic">Cargando archivos asociados...</p>';

        fetch(`/attachments?attachable_type=Incident&attachable_id=${incidentId}`, {
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (!data.success || !data.attachments || data.attachments.length === 0) {
                existingIncidentAttachments = [];
                if (existingSection) existingSection.classList.add('hidden');
                if (countEl) countEl.textContent = '';
                listEl.innerHTML = '';
                return;
            }

            existingIncidentAttachments = data.attachments;
            if (existingSection) existingSection.classList.remove('hidden');
            renderIncidentExistingAttachments();
        })
        .catch(err => {
            console.error('Error al cargar adjuntos de incidencia:', err);
            listEl.innerHTML = '<p class="text-[11px] text-red-500">Error al cargar archivos adjuntos.</p>';
        });
    }

    function renderIncidentExistingAttachments() {
        const listEl = document.getElementById('incidentAttachmentsList');
        const countEl = document.getElementById('incidentAttachmentsCount');
        const existingSection = document.getElementById('incidentExistingFilesSection');
        if (!listEl) return;

        if (existingIncidentAttachments.length === 0) {
            if (existingSection) existingSection.classList.add('hidden');
            if (countEl) countEl.textContent = '';
            listEl.innerHTML = '';
            return;
        }

        if (existingSection) existingSection.classList.remove('hidden');
        const activeCount = existingIncidentAttachments.filter(att => !pendingRemoveIncidentAttachmentIds.includes(att.id)).length;
        if (countEl) countEl.textContent = activeCount > 0 ? `(${activeCount})` : '';

        listEl.innerHTML = existingIncidentAttachments.map(att => {
            const isMarkedForRemoval = pendingRemoveIncidentAttachmentIds.includes(att.id);

            if (isMarkedForRemoval) {
                return `
                    <div class="flex items-center justify-between gap-2 p-2 rounded-xl bg-red-50/80 dark:bg-red-950/40 border border-red-200/80 dark:border-red-900/60 text-xs transition">
                        <div class="flex items-center gap-2 min-w-0 flex-1">
                            <i data-lucide="trash-2" class="w-3.5 h-3.5 text-red-500 shrink-0"></i>
                            <span class="truncate line-through text-slate-400 dark:text-slate-500 font-medium" title="${escapeHtml(att.original_name)}">
                                ${escapeHtml(att.original_name)}
                            </span>
                            <span class="text-[9px] px-1.5 py-0.5 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 font-semibold rounded shrink-0">
                                Se eliminará al guardar
                            </span>
                        </div>
                        <div class="flex items-center gap-1 shrink-0">
                            <button type="button" onclick="cancelRemoveIncidentAttachment(${att.id}, event)"
                                class="px-2 py-0.5 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 rounded-lg transition"
                                title="Deshacer eliminación">
                                Deshacer
                            </button>
                        </div>
                    </div>
                `;
            }

            return `
                <div class="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs transition hover:border-slate-300 dark:hover:border-slate-600">
                    <div class="flex items-center gap-2 min-w-0 flex-1">
                        <i data-lucide="file" class="w-3.5 h-3.5 text-red-500 shrink-0"></i>
                        <span class="truncate font-medium text-slate-700 dark:text-slate-200" title="${escapeHtml(att.original_name)}">
                            ${escapeHtml(att.original_name)}
                        </span>
                        <span class="text-[10px] text-slate-400 shrink-0 font-mono">(${escapeHtml(att.formatted_size || formatFileSize(att.file_size))})</span>
                    </div>
                    <div class="flex items-center gap-1 shrink-0">
                        <a href="/attachments/${att.id}/download" target="_blank"
                            class="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition"
                            title="Descargar archivo">
                            <i data-lucide="download" class="w-3.5 h-3.5"></i>
                        </a>
                        <button type="button" onclick="markIncidentAttachmentForRemoval(${att.id}, event)"
                            class="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition"
                            title="Eliminar este archivo">
                            <i data-lucide="trash-2" class="w-3.5 h-3.5 text-red-500"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');

        if (window.lucide) {
            lucide.createIcons({ root: listEl });
        }
    }

    function markIncidentAttachmentForRemoval(attId, event) {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        if (!pendingRemoveIncidentAttachmentIds.includes(attId)) {
            pendingRemoveIncidentAttachmentIds.push(attId);
        }
        syncIncidentPendingRemoveInputs();
        renderIncidentExistingAttachments();
    }

    function cancelRemoveIncidentAttachment(attId, event) {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        pendingRemoveIncidentAttachmentIds = pendingRemoveIncidentAttachmentIds.filter(id => id !== attId);
        syncIncidentPendingRemoveInputs();
        renderIncidentExistingAttachments();
    }

    function syncIncidentPendingRemoveInputs() {
        const container = document.getElementById('incidentPendingRemoveInputs');
        if (!container) return;
        container.innerHTML = pendingRemoveIncidentAttachmentIds.map(id =>
            `<input type="hidden" name="remove_attachment_ids[]" value="${id}">`
        ).join('');
    }

    function deleteAttachment(id, type, attachableId) {
        openDeleteConfirm({
            title: '¿Eliminar archivo adjunto?',
            message: 'El archivo adjunto se eliminará de forma permanente.',
            confirmText: 'Eliminar archivo',
            isPermanent: true,
            permanentText: 'Advertencia: El archivo se eliminará definitivamente del almacenamiento.',
            onConfirm: () => {
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

                fetch('/attachments/' + id, {
                    method: 'DELETE',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken,
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        loadAttachments(type, attachableId);
                    } else {
                        alert(data.error || 'No se pudo eliminar el archivo adjunto.');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('Error de red al eliminar el archivo adjunto.');
                });
            }
        });
    }

    // Initialize Mobile Sub-nav states on load
    document.addEventListener('DOMContentLoaded', () => {
        if (window.lucide) {
            window.lucide.createIcons();
        }

        if (window.innerWidth < 1024) {
            @if($activeView === 'calendario')
                const urlParams = new URLSearchParams(window.location.search);
                const calTab = urlParams.get('cal_subview') || sessionStorage.getItem('cal_mobile_active_tab') || 'calendar';
                const filter = urlParams.get('task_filter');
                if (calTab === 'list' || filter) {
                    selectMobileCalView(filter || 'list');
                } else {
                    selectMobileCalView('calendar');
                }
            @elseif($activeView === 'kanban')
                const savedCol = sessionStorage.getItem('kanban_mobile_active_col') || 'todos';
                filterMobileKanban(savedCol);
            @elseif($activeView === 'incidencias')
                const savedInc = sessionStorage.getItem('inc_mobile_active_col') || 'todas';
                filterMobileIncidents(savedInc);
            @endif
        }
    });
</script>

<style>
/* Scroll vertical independiente para columnas de Kanban */
.kanban-scrollable {
    overflow-y: auto !important;
    overscroll-behavior-y: contain;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: thin;
    scrollbar-color: rgba(148, 163, 184, 0.6) transparent;
}
.kanban-scrollable::-webkit-scrollbar {
    width: 6px;
}
.kanban-scrollable::-webkit-scrollbar-track {
    background: transparent;
}
.kanban-scrollable::-webkit-scrollbar-thumb {
    background-color: rgba(148, 163, 184, 0.5);
    border-radius: 9999px;
}
.kanban-scrollable::-webkit-scrollbar-thumb:hover {
    background-color: rgba(100, 116, 139, 0.8);
}
.dark .kanban-scrollable::-webkit-scrollbar-thumb {
    background-color: rgba(71, 85, 105, 0.6);
}
.dark .kanban-scrollable::-webkit-scrollbar-thumb:hover {
    background-color: rgba(148, 163, 184, 0.7);
}

/* Optimización de rendimiento para selects en el modal Agregar Tarea */
#taskModal {
    will-change: opacity;
}
#taskModal .task-modal-card {
    contain: layout style;
}
#taskModal select {
    color-scheme: light dark;
    transition: none !important;
}

/* Fila inferior de tarea: oculta completamente sin reservar espacio en escritorio, expandible en hover */
@media (hover: hover) and (pointer: fine) and (min-width: 768px) {
    .task-bottom-row-expandable {
        display: none !important;
    }
    .group:hover .task-bottom-row-expandable,
    .group:focus-within .task-bottom-row-expandable {
        display: flex !important;
        animation: taskBottomRowFade 0.15s ease-out;
    }
    .task-actions-hover {
        opacity: 0 !important;
        pointer-events: none !important;
        transition: opacity 0.15s ease-in-out;
    }
    .group:hover .task-actions-hover,
    .group:focus-within .task-actions-hover {
        opacity: 1 !important;
        pointer-events: auto !important;
    }
}

@keyframes taskBottomRowFade {
    from {
        opacity: 0;
        transform: translateY(-2px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (min-width: 1024px) {
    html.cal-split-active #cal-view-calendar {
        width: 58.333333% !important; /* lg:w-7/12 */
    }
    html.cal-split-active #cal-view-list {
        display: flex !important; /* visible in split mode */
    }
}

#cal-view-calendar.cal-view-full #calendar-container {
    min-height: 680px;
}

/* Renderizado personalizado de tarjetas de eventos en FullCalendar */
.fc .fc-daygrid-day-events {
    margin-bottom: 2px;
}
.fc .fc-daygrid-event-harness {
    margin-bottom: 4px;
}
.fc .fc-daygrid-event {
    background: transparent !important;
    border: none !important;
    padding: 0 !important;
    margin: 1px 2px !important;
    box-shadow: none !important;
    white-space: normal !important;
}
.fc .fc-daygrid-event:hover {
    background: transparent !important;
}
.fc .fc-event-main {
    padding: 0 !important;
    width: 100%;
}
.cal-event-card {
    position: relative;
    width: 100%;
    border-radius: 0 8px 8px 0;
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
    padding: 5px 6px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
    transition: transform 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    cursor: pointer;
    overflow: hidden;
    box-sizing: border-box;
}
.cal-event-card:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.08), 0 2px 4px -2px rgba(0, 0, 0, 0.05);
}
.cal-event-title {
    font-size: 11px;
    font-weight: 700;
    line-height: 1.25;
    color: #1e293b;
    margin-bottom: 4px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    word-break: break-word;
}
.dark .cal-event-title {
    color: #f8fafc;
}
.cal-event-badges {
    display: flex;
    align-items: center;
    gap: 4px;
    flex-wrap: wrap;
}
.cal-badge {
    display: inline-flex;
    align-items: center;
    font-size: 9.5px;
    font-weight: 700;
    line-height: 1.15;
    padding: 1.5px 5.5px;
    border-radius: 5px;
    white-space: nowrap;
    letter-spacing: -0.01em;
}

@media (max-width: 1023px) {
    .cal-panel-mobile-hidden {
        display: none !important;
    }
    .kanban-col-mobile-hidden {
        display: none !important;
    }
    .incident-col-mobile-hidden {
        display: none !important;
    }
}

/* Eliminación de bordes o contornos en modo oscuro en las tareas de los tres contenedores de Resumen */
html.dark #contenedor-todas-tareas .all-tasks-item,
html.dark #contenedor-periodicas .periodic-task-item,
html.dark #contenedor-tareas-vencidas .overdue-task-item {
    border-color: transparent !important;
    box-shadow: none !important;
}

/* Altura uniforme y scroll vertical interno en los tres contenedores principales del panel de tareas (Escritorio) */
@media (min-width: 1024px) {
    #contenedor-todas-tareas,
    #contenedor-periodicas,
    #contenedor-tareas-vencidas {
        height: 650px;
    }
}

</style>
@endpush
